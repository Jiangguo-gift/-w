/* ═══════════════════════════════════════════════════════════
   ovhero.js —— 驾驶舱全景「一屏总览 + 阅读队列」呈现层
   2026-09-24 本人 指令：驾驶舱全景改为上方汇总数据 + 下方可展开阅读队列
   规则：
   ① 不动侧栏、不动按钮组件、不动其他分区
   ② 在 #m_over 前插一块「区级总览」，把驾驶舱 ▇▇个模块聚成 ▇▇张数字卡 + 阅读队列
   ③ 每条阅读项点击后调用 OS.reveal(id) 跳到源模块（保留原有跳转能力）
   ═══════════════════════════════════════════════════════════ */
(function () {

  /* 驾驶舱 ▇▇个模块（顺序对应侧栏 ▇▇–▇▇） */
  const OV_IDS = ['m_over', 'm_notice', 'alert', 'deck', 'm_pend', 'advice', 'fb_ov'];

  /* 每个模块的编号 / 简称，用于阅读队列条目里显示来源 */
  const LBL = {
    m_over:   { n: '▇▇', t: '工作台业务模块总览' },
    m_notice: { n: '▇▇', t: '重要信息同步' },
    alert:    { n: '▇▇', t: '今日更新动态总览' },
    deck:     { n: '▇▇', t: '自运行工作流进展' },
    m_pend:   { n: '▇▇', t: '待反馈确认信息同步' },
    advice:   { n: '▇▇', t: '系统自运行优化建议' },
    fb_ov:    { n: '▇▇', t: '此模块优化反馈' }
  };

  /* 驾驶舱 ▇▇个模块按业务语义显式分到 ▇▇ 组阅读队列
     —— 不用状态 st 隐式推导，避免文案与状态错位 */
  const GROUP_OF = {
    m_over:   'new',   /* ▇▇ 模块健康度 → 今日实时状态 */
    m_notice: 'new',   /* ▇▇ 结论汇总   → 今日新增结论 */
    alert:    'new',   /* ▇▇ 今日动态   → 今日新增变更 */
    deck:     'new',   /* ▇▇ 工作流进展 → 今日新增动作 */
    advice:   'stale', /* ▇▇ 系统建议   → 等你拍板已积压 */
    m_pend:   'stale', /* ▇▇ 全站待她一句 → 长期未读汇总 */
    fb_ov:    'todo'   /* ▇▇ 反馈入口   → 待沉淀（等你反馈） */
  };

  /* 把 SUM.now 里的富文本压成一句短摘要 */
  function abstract(html, max) {
    if (!html) return '';
    const txt = String(html).replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
    if (!max || txt.length <= max) return txt;
    return txt.slice(0, max - 1) + '…';
  }

  /* 状态标签：根据 st 映射成"未读 / 在读 / 待定 / 待接通" */
  function tagOf(sum) {
    if (!sum)              return { k: '待接通', tone: 'todo' };
    if (sum.st === 'go')   return { k: '未读',   tone: 'unread' };
    if (sum.st === 'watch')return { k: '在读',   tone: 'reading' };
    if (sum.st === 'wait') return { k: '待定',   tone: 'wait' };
    return { k: '未读', tone: 'unread' };
  }

  /* 组装阅读队列的三组条目 */
  function queue() {
    const SUM = (window.MOD && window.MOD.SUM) || {};
    const groups = { new: [], stale: [], todo: [] };
    OV_IDS.forEach(id => {
      const s = SUM[id];
      const lbl = LBL[id] || { n: '?', t: id };
      const tag = tagOf(s);
      const item = {
        id: id,
        n: lbl.n,
        from: lbl.t,
        title: s && s.now ? abstract(s.now, 78) : '内容还在搭建中，等数据接通后自动填充',
        tag: tag,
        act: s && s.act && s.act[0] ? abstract(s.act[0], 26) : ''
      };
      const bucket = GROUP_OF[id] || 'todo';
      groups[bucket].push(item);
    });
    return groups;
  }

  /* 组装 ▇▇张顶部汇总卡的数据 —— 直接读队列分组，数值口径清晰 */
  function stats() {
    const q = queue();
    const total = q.new.length + q.stale.length + q.todo.length;
    return {
      today: { n: q.new.length,   u: '条', d: '今日新增内容',       hint: '本区 ▇▇个日更模块的最新结论与动作' },
      inbox: { n: total,          u: '条', d: '本区未读合计',       hint: '本区 ▇▇个模块目前全部处于未读状态' },
      done:  { n: 0,              u: '条', d: '今日已确认或已采纳', hint: '骨架搭建期间暂为 ▇▇，接通「已定过的决策记录」后自动填数' },
      stale: { n: q.stale.length, u: '条', d: '长期未读积压',       hint: '等你拍板 / 汇总入口暂未接通，超期需处理' }
    };
  }

  /* 顶部 ▇▇张数字卡的 HTML */
  function renderStats(st) {
    const cards = [
      { key: 'today', tone: 'today', ...st.today },
      { key: 'inbox', tone: 'inbox', ...st.inbox },
      { key: 'done',  tone: 'done',  ...st.done  },
      { key: 'stale', tone: 'stale', ...st.stale }
    ];
    return `<div class="ovhero__stats">
      ${cards.map(c => `
        <div class="ovhero__stat" data-tone="${c.tone}">
          <div class="ovhero__stat_tag">${c.d}</div>
          <div class="ovhero__stat_row">
            <b class="ovhero__stat_n">${c.n}</b><span class="ovhero__stat_u">${c.u}</span>
          </div>
          <div class="ovhero__stat_hint">${c.hint}</div>
        </div>`).join('')}
    </div>`;
  }

  /* 阅读队列一条 */
  function renderItem(it) {
    return `<li class="ovhero__item" data-go="${it.id}">
      <span class="ovhero__it_from">编号 ${it.n} · ${it.from}</span>
      <span class="ovhero__it_t">${it.title}</span>
      <span class="ovhero__it_meta">
        <span class="ovhero__it_tag" data-tone="${it.tag.tone}">${it.tag.k}</span>
        ${it.act ? `<span class="ovhero__it_act">${it.act}</span>` : ''}
        <span class="ovhero__it_go" aria-hidden="true">→</span>
      </span>
    </li>`;
  }

  /* 阅读队列的一组 */
  function renderGroup(name, tone, items, opened) {
    if (!items.length) return `
      <details class="ovhero__group ovhero__group--empty" data-tone="${tone}">
        <summary>
          <span class="ovhero__gname">${name}</span><b class="ovhero__gn">▇▇</b>
          <span class="ovhero__gempty">暂无</span>
        </summary>
      </details>`;
    return `
      <details class="ovhero__group" data-tone="${tone}"${opened ? ' open' : ''}>
        <summary>
          <span class="ovhero__gname">${name}</span><b class="ovhero__gn">${items.length}</b>
        </summary>
        <ul class="ovhero__list">${items.map(renderItem).join('')}</ul>
      </details>`;
  }

  function html() {
    const st = stats();
    const q = queue();
    /* 分类 chips：与 Ⅱ/Ⅲ/Ⅳ 区保持同一呈现节奏，帮她按主题快速切入 */
    const CHIPS = [
      { k: '模块健康度',     to: 'm_over'   },
      { k: '结论汇总',       to: 'm_notice' },
      { k: '今日动态',       to: 'alert'    },
      { k: '工作流进展',     to: 'deck'     },
      { k: '等你一句',       to: 'm_pend'   },
      { k: '驾驶舱建议',     to: 'advice'   },
      { k: '本区反馈',       to: 'fb_ov'    }
    ];
    const chipsHtml = `<div class="zh__chips" role="tablist" aria-label="按主题跳转">
      ${CHIPS.map(c => `<button class="zh__chip" data-go="${c.to}">${c.k}</button>`).join('')}
    </div>`;
    return `
      <section class="ovhero" id="ovhero" aria-label="驾驶舱全景总览">
        <div class="ovhero__head">
          <div class="ovhero__eyebrow zh__eyebrow" data-zone="ov">Ⅰ 驾驶舱全景</div>
          <h2 class="ovhero__title">工作台运行状态一屏总览</h2>
          <p class="ovhero__sub">上方看四个总量指标，判断工作台自身状态；下方按主题展开阅读队列，<b>点每一条都能跳去源模块</b>看细节。</p>
        </div>
        ${renderStats(st)}
        ${chipsHtml}
        <div class="ovhero__queue">
          <div class="ovhero__qhead">
            <h3 class="ovhero__qtitle">阅读队列</h3>
            <div class="ovhero__tabs" role="tablist">
              <button class="ovhero__tab is-on" data-tab="all">全部</button>
              <button class="ovhero__tab" data-tab="mine">我负责的</button>
              <button class="ovhero__tab" data-tab="join">我参与的</button>
            </div>
          </div>
          ${renderGroup('今日新增',  'new',   q.new,   true)}
          ${renderGroup('长期积压',  'stale', q.stale, true)}
          ${renderGroup('待沉淀',    'todo',  q.todo,  false)}
        </div>
      </section>`;
  }

  function mount() {
    const container = document.getElementById('sections');
    if (!container) return;
    /* 避免重复挂载 */
    if (document.getElementById('ovhero')) return;
    const first = container.querySelector('#m_over');
    const panel = document.createElement('div');
    panel.innerHTML = html();
    const el = panel.firstElementChild;
    if (first && first.parentNode === container) {
      container.insertBefore(el, first);
    } else {
      /* 兜底：如果找不到 m_over（比如结构变了），插到最前面 */
      container.insertBefore(el, container.firstChild);
    }
    wire(el);
  }

  function wire(root) {
    /* 阅读条 / 分类 chip 两类点击都走同一路由 */
    root.addEventListener('click', e => {
      const goEl = e.target.closest('.ovhero__item, .zh__chip');
      if (goEl) {
        const id = goEl.dataset.go;
        if (id && window.OS && window.OS.reveal) {
          window.OS.reveal(id);
        } else if (id) {
          const el = document.getElementById(id);
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        return;
      }
      /* 三个 tab（全部 / 我负责的 / 我参与的）—— 当前 P1 阶段先只切视觉状态，
         内容分区等 P2 数据接通后再落。切换时不刷新条目，避免用户误以为数据丢了。 */
      const tab = e.target.closest('.ovhero__tab');
      if (tab) {
        root.querySelectorAll('.ovhero__tab').forEach(b => b.classList.remove('is-on'));
        tab.classList.add('is-on');
      }
    });
  }

  /* 等 renderSections() 跑完再挂载。render.js 在 boot 里同步渲染 sections，
     所以这里用 DOMContentLoaded + 一次 setTimeout 兜底即可。 */
  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true });
    } else fn();
  }

  ready(() => {
    /* render.js 是同步渲染，但 boot() 内有异步收尾，稍等一帧再挂 */
    requestAnimationFrame(() => {
      mount();
      /* 再兜一次，防止某些补丁在 boot 后重新覆盖了 #sections */
      setTimeout(mount, 200);
    });
  });

  window.OVHERO = { mount, stats, queue };
})();
