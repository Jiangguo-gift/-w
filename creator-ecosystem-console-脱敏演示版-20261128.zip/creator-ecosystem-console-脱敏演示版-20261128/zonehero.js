/* ═══════════════════════════════════════════════════════════
   zonehero.js —— Ⅱ/Ⅲ/Ⅳ 三区「一屏总览 + 分类标签 + 阅读队列」呈现层
   2026-09-24 本人 HO-0924-▇▇：驾驶舱做过的「上方汇总数据 +
   下方阅读队列 + 可跳转 + 核心信息提炼」推广到每个区。
   规则：
   ① 不动侧栏、不动按钮组件、不动其他分区
   ② Ⅰ 区继续用 ovhero.js（已线上稳定），本文件只挂 Ⅱ/Ⅲ/Ⅳ
   ③ 每个 zone hero 在该区第一个模块前插一块：
      · 眉标 + 大标题 + 一句话导读
      · ▇▇张汇总数字卡（口径按区语义定，来源即本区模块数量）
      · 一排分类标签（chips），点选即滚到对应模块
      · 阅读队列，按语义分 ▇▇~▇▇ 组，每条可点击跳源模块
   ④ 阅读队列每条来源仍读 window.MOD.SUM[id]（结论条口径统一）
   ⑤ 点击任意 chip 或阅读条 → 走 OS.reveal(id)，保留原有跳转能力
   ═══════════════════════════════════════════════════════════ */
(function () {

  /* ─── 每个区的完整配置 ─── */
  const ZONES = {
    mind: {
      first: 'memory',
      eyebrow: 'Ⅱ 认知与学习',
      title:   '外部输入与思维迭代一屏总览',
      sub:     '上方看四个总量指标，判断规则与口径层库存与缺口；下方按主题展开阅读队列，<b>点每一条都能跳去源模块</b>看细节。⛔ 这一区不复述业务数字。',
      ids: ['memory','m_ext','m_chg','pattern','premise','m_lrn','quick','fb_mind'],
      lbl: {
        memory:  { n: '▇▇', t: '记忆库总目录' },
        m_ext:   { n: '▇▇', t: '外部原料 · 采纳建议' },
        m_chg:   { n: '▇▇', t: '今日记忆库变更' },
        pattern: { n: '▇▇', t: '你的思维模式' },
        premise: { n: '▇▇', t: '前提纠错 · 待复核' },
        m_lrn:   { n: '▇▇', t: '对规则与口径做自查缺口' },
        quick:   { n: '▇▇', t: '灵感速记 · 可采纳' },
        fb_mind: { n: '▇▇', t: '本区反馈入口' }
      },
      /* chips 用简短业务化标签替代模块编号，帮她按主题快速切入 */
      chips: [
        { k: '记忆分册',       to: 'memory'  },
        { k: '向外看的原料',   to: 'm_ext'   },
        { k: '今天记了什么',   to: 'm_chg'   },
        { k: '你今天怎么想',   to: 'pattern' },
        { k: '哪条前提可能错', to: 'premise' },
        { k: '「规则与口径的漏洞」',     to: 'm_lrn'   },
        { k: '速记 · 采纳',     to: 'quick'   }
      ],
      /* 阅读队列分组：显式分派，避免状态推断错位 */
      groupMap: {
        m_ext:   'in',    /* 外部新入料 */
        quick:   'in',
        m_chg:   'in',
        premise: 'wait',  /* 等你二次拍板 */
        m_lrn:   'gap',   /* 系统自查缺口 */
        pattern: 'gap',
        memory:  'ref',   /* 长期底座（只读） */
        fb_mind: 'todo'   /* 反馈入口 */
      },
      groups: [
        { key: 'in',   name: '今日新增学习', tone: 'new'   },
        { key: 'wait', name: '等你二次确认', tone: 'stale' },
        { key: 'gap',  name: '系统自查缺口', tone: 'todo'  },
        { key: 'ref',  name: '长期底座 / 反馈', tone: 'ref' }
      ],
      /* 汇总卡：读队列分桶数量得数，口径清晰、可解释 */
      stats: (q, ids) => {
        const rulesCal = (() => {
          const F = (window.MIND && window.MIND.FACT) || {};
          const r = F.rules || 62, c = F.cal || 35;
          return { r, c };
        })();
        return [
          { key: 'today', tone: 'today', n: q.in.length,   u: '条', d: '今日新增学习',   hint: '外部原料 + 今日记忆库变更 + 速记合计' },
          { key: 'wait',  tone: 'stale', n: q.wait.length, u: '条', d: '等你二次确认',   hint: '被推翻的前提 / 降级的判断，等你拍板' },
          { key: 'gap',   tone: 'inbox', n: q.gap.length,  u: '处', d: '「规则与口径的漏洞」',     hint: '规则可能过期 / 概念不一致 / 结论缺佐证' },
          { key: 'base',  tone: 'done',  n: rulesCal.r + ' · ' + rulesCal.c, u: '条', d: '规则 · 口径底座', hint: '本地 Obsidian 导出，不实时同步' }
        ];
      }
    },

    sys: {
      first: 'state',
      eyebrow: 'Ⅲ 高阶交互系统',
      title:   '模块之间怎么协作 · 待你拍板的事 · 系统自查一屏总览',
      sub:     '上方看四个总量指标，判断模块之间的信息流是否顺畅；下方按主题展开阅读队列，<b>点每一条都能跳去源模块</b>看细节。⛔ 这一区不呈现业务名词与数字。',
      ids: ['state','confirm','call','cap','fb_sys'],
      lbl: {
        state:   { n: '▇▇', t: '模块之间怎么协作' },
        confirm: { n: '▇▇', t: '已定过的决策 · 待你拍板的事' },
        call:    { n: '▇▇', t: '我能装的技能 · 常用指令模板' },
        cap:     { n: '▇▇', t: '系统自查发现的问题 · 建议做法' },
        fb_sys:  { n: '▇▇', t: '本区反馈入口' }
      },
      chips: [
        { k: '模块之间怎么协作', to: 'state'   },
        { k: '已定过的决策',     to: 'confirm' },
        { k: '可装技能清单',     to: 'call'    },
        { k: '自查问题 · 建议做法', to: 'cap'  }
      ],
      groupMap: {
        state:   'run',
        call:    'run',
        confirm: 'wait',
        cap:     'gap',
        fb_sys:  'todo'
      },
      groups: [
        { key: 'run',  name: '已经在跑的协作与技能',   tone: 'new'   },
        { key: 'wait', name: '等你拍板的事',           tone: 'stale' },
        { key: 'gap',  name: '系统自查出的待处理问题', tone: 'todo'  },
        { key: 'todo', name: '反馈入口',              tone: 'ref'   }
      ],
      stats: (q, ids) => [
        { key: 'run',   tone: 'today', n: q.run.length,  u: '格', d: '已经在跑的协作与技能', hint: '模块协作总览 + 可装技能清单' },
        { key: 'wait',  tone: 'stale', n: q.wait.length, u: '件', d: '等你拍板的事',        hint: '你没定我不会往下走的事项' },
        { key: 'gap',   tone: 'inbox', n: q.gap.length,  u: '处', d: '系统自查出的待处理问题', hint: '自查发现哪里协作卡住、要怎么补' },
        { key: 'edge',  tone: 'done',  n: 0,             u: '件', d: '今日已定的决策',       hint: '骨架搭建期间暂为 ▇▇，接通决策日志后自动填数' }
      ]
    },

    biz: {
      first: 'eco',
      eyebrow: 'Ⅳ 业务工作区',
      title:   '本周业务落地一屏总览',
      sub:     '上方看四个总量指标，判断今天业务在哪里；下方按主题展开阅读队列，<b>点每一条都能跳去源模块</b>看细节。业绩金额只在这一区呈现。',
      ids: ['eco','base','cust','run','plays','m_data','m_brun','fb_biz'],
      lbl: {
        eco:    { n: '▇▇', t: '外部大盘 · 外部信息' },
        base:   { n: '▇▇', t: '目标 · 业绩达成' },
        cust:   { n: '▇▇', t: '客户 · 商机需求' },
        run:    { n: '▇▇', t: '本周策略回顾' },
        plays:  { n: '▇▇', t: '策略资料库' },
        m_data: { n: '▇▇', t: '底仓数据能力' },
        m_brun: { n: '▇▇', t: '自运行工作反馈' },
        fb_biz: { n: '▇▇', t: '本区反馈入口' }
      },
      chips: [
        { k: '外面在发生什么', to: 'eco'   },
        { k: '业绩自主判断',   to: 'base'  },
        { k: '外面要什么',     to: 'cust'  },
        { k: '本周怎么打',     to: 'run'   },
        { k: '拿什么打',       to: 'plays' },
        { k: '数据入口',       to: 'm_data'},
        { k: '今天替她跑了什么', to: 'm_brun' }
      ],
      groupMap: {
        base:   'now',   /* 今天先动 */
        cust:   'now',
        m_brun: 'now',
        run:    'week',  /* 本周策略 */
        plays:  'week',
        eco:    'ext',   /* 外部与数据 */
        m_data: 'ext',
        fb_biz: 'todo'
      },
      groups: [
        { key: 'now',  name: '今天先动',        tone: 'new'   },
        { key: 'week', name: '本周策略与打法',   tone: 'stale' },
        { key: 'ext',  name: '外部与数据入口',   tone: 'todo'  },
        { key: 'todo', name: '反馈入口',        tone: 'ref'   }
      ],
      stats: (q, ids) => [
        { key: 'now',  tone: 'today', n: q.now.length,  u: '件', d: '今天先动',          hint: '业绩自主判断 + 商机 + 自运行' },
        { key: 'week', tone: 'stale', n: q.week.length, u: '件', d: '本周策略 / 打法',   hint: '本周策略回顾 + 策略资料库' },
        { key: 'ext',  tone: 'inbox', n: q.ext.length,  u: '格', d: '外部与数据入口',    hint: '外部大盘信息 + 底仓数据能力' },
        { key: 'seg',  tone: 'done',  n: 8,             u: '格', d: '业务模块总数',      hint: '本区共 ▇▇个模块，业绩金额只在本区' }
      ]
    }
  };

  /* ─── 通用辅助 ─── */

  function abstract(html, max) {
    if (!html) return '';
    const txt = String(html).replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
    if (!max || txt.length <= max) return txt;
    return txt.slice(0, max - 1) + '…';
  }

  function tagOf(sum) {
    if (!sum)              return { k: '待接通', tone: 'todo' };
    if (sum.st === 'go')   return { k: '未读',   tone: 'unread' };
    if (sum.st === 'watch')return { k: '在读',   tone: 'reading' };
    if (sum.st === 'wait') return { k: '待定',   tone: 'wait' };
    return { k: '未读', tone: 'unread' };
  }

  /* 组装一个 zone 的阅读队列（按 groupMap 显式分桶） */
  function queueOf(cfg) {
    const SUM = (window.MOD && window.MOD.SUM) || {};
    const groups = {};
    cfg.groups.forEach(g => { groups[g.key] = []; });
    cfg.ids.forEach(id => {
      const s = SUM[id];
      const lbl = cfg.lbl[id] || { n: '?', t: id };
      const tag = tagOf(s);
      const item = {
        id: id,
        n: lbl.n,
        from: lbl.t,
        title: s && s.now ? abstract(s.now, 78) : '内容还在搭建中，等数据接通后自动填充',
        tag: tag,
        act: s && s.act && s.act[0] ? abstract(s.act[0], 26) : ''
      };
      const bucket = cfg.groupMap[id] || cfg.groups[cfg.groups.length - 1].key;
      (groups[bucket] || groups[cfg.groups[0].key]).push(item);
    });
    return groups;
  }

  /* ─── 渲染 ─── */

  function renderStats(cards) {
    return `<div class="ovhero__stats zh__stats">
      ${cards.map(c => `
        <div class="ovhero__stat" data-tone="${c.tone}">
          <div class="ovhero__stat_tag">${c.d}</div>
          <div class="ovhero__stat_row">
            <b class="ovhero__stat_n">${c.n}</b><span class="ovhero__stat_u">${c.u}</span>
          </div>
          <div class="ovhero__stat_hint">${c.hint}</div>
        </div>`).join('')}
    </div>`;
  }

  function renderChips(chips) {
    if (!chips || !chips.length) return '';
    return `<div class="zh__chips" role="tablist" aria-label="按主题跳转">
      ${chips.map(c => `<button class="zh__chip" data-go="${c.to}">${c.k}</button>`).join('')}
    </div>`;
  }

  function renderItem(it) {
    return `<li class="ovhero__item" data-go="${it.id}">
      <span class="ovhero__it_from">编号 ${it.n} · ${it.from}</span>
      <span class="ovhero__it_t">${it.title}</span>
      <span class="ovhero__it_meta">
        <span class="ovhero__it_tag" data-tone="${it.tag.tone}">${it.tag.k}</span>
        ${it.act ? `<span class="ovhero__it_act">${it.act}</span>` : ''}
        <span class="ovhero__it_go" aria-hidden="true">→</span>
      </span>
    </li>`;
  }

  function renderGroup(g, items) {
    if (!items || !items.length) {
      return `<details class="ovhero__group ovhero__group--empty" data-tone="${g.tone}">
        <summary>
          <span class="ovhero__gname">${g.name}</span><b class="ovhero__gn">▇▇</b>
          <span class="ovhero__gempty">暂无</span>
        </summary>
      </details>`;
    }
    const opened = g.tone !== 'ref';  /* 反馈入口一组默认收起 */
    return `<details class="ovhero__group" data-tone="${g.tone}"${opened ? ' open' : ''}>
      <summary>
        <span class="ovhero__gname">${g.name}</span><b class="ovhero__gn">${items.length}</b>
      </summary>
      <ul class="ovhero__list">${items.map(renderItem).join('')}</ul>
    </details>`;
  }

  function htmlOf(zoneKey, cfg) {
    const q = queueOf(cfg);
    const cards = cfg.stats(q, cfg.ids);
    return `
      <section class="ovhero zh" id="zh_${zoneKey}" data-zone="${zoneKey}" aria-label="${cfg.eyebrow} 一屏总览">
        <div class="ovhero__head">
          <div class="ovhero__eyebrow zh__eyebrow" data-zone="${zoneKey}">${cfg.eyebrow}</div>
          <h2 class="ovhero__title">${cfg.title}</h2>
          <p class="ovhero__sub">${cfg.sub}</p>
        </div>
        ${renderStats(cards)}
        ${renderChips(cfg.chips)}
        <div class="ovhero__queue">
          <div class="ovhero__qhead">
            <h3 class="ovhero__qtitle">阅读队列</h3>
            <div class="ovhero__tabs" role="tablist">
              <button class="ovhero__tab is-on" data-tab="all">全部</button>
              <button class="ovhero__tab" data-tab="mine">我负责的</button>
              <button class="ovhero__tab" data-tab="join">我参与的</button>
            </div>
          </div>
          ${cfg.groups.map(g => renderGroup(g, q[g.key])).join('')}
        </div>
      </section>`;
  }

  function mountOne(zoneKey) {
    const cfg = ZONES[zoneKey];
    if (!cfg) return;
    if (document.getElementById('zh_' + zoneKey)) return;
    const container = document.getElementById('sections');
    if (!container) return;
    const anchor = container.querySelector('#' + cfg.first);
    if (!anchor) return;
    const panel = document.createElement('div');
    panel.innerHTML = htmlOf(zoneKey, cfg);
    const el = panel.firstElementChild;
    container.insertBefore(el, anchor);
    wire(el);
  }

  function wire(root) {
    root.addEventListener('click', e => {
      /* 阅读条 / chip 两类点击都走同一路由 */
      const goEl = e.target.closest('.ovhero__item, .zh__chip');
      if (goEl) {
        const id = goEl.dataset.go;
        if (id && window.OS && window.OS.reveal) {
          window.OS.reveal(id);
        } else if (id) {
          const t = document.getElementById(id);
          if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        return;
      }
      /* 三个 tab 视觉切换（数据分桶等 P2 接通反馈系统后再落） */
      const tab = e.target.closest('.ovhero__tab');
      if (tab) {
        root.querySelectorAll('.ovhero__tab').forEach(b => b.classList.remove('is-on'));
        tab.classList.add('is-on');
      }
    });
  }

  function mountAll() {
    ['mind', 'sys', 'biz'].forEach(mountOne);
  }

  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true });
    } else fn();
  }

  ready(() => {
    requestAnimationFrame(() => {
      mountAll();
      /* 兜底：若某段补丁在 boot 后又重刷 #sections，200ms 后再挂一次 */
      setTimeout(mountAll, 220);
    });
  });

  window.ZONEHERO = { mount: mountAll, mountOne, queueOf, ZONES };
})();
