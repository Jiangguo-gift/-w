/* ═══════════════════════════════════════════════════════════
   sply.hot.js —— 内热资料索引（飞书多维表格快照）

   来源：INTERNAL-ID / INTERNAL-ID / INTERNAL-ID
   同步：2026-10-11；▇▇条资料记录，页面按实际链接数自动计数。
   只做可调用索引，不改写源文档；政策数字与适用范围以原文最新版本为准。
   ═══════════════════════════════════════════════════════════ */
window.SPLYHOT = (function () {
  const SOURCE = {
    date: '2026-10-11',
    name: '内热资料多维表格',
    url: 'https://docs.internal.example/base/INTERNAL-ID?table=INTERNAL-ID&view=INTERNAL-ID'
  };

  const GROUPS = [
    {
      k: '政策规则', call: '报政策、核准入门槛、判断授信与分层权益时先从这里回原文。',
      rows: [
        { k: '授信资料', docs: [
          ['2026 年星图业务预借款规则 V1.0', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['2026 年渠道服务商千川业务预借款规则 V1.0', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['2026 年代理商 AD 竞价授信与付款担保规则 V1.0', 'https://docs.internal.example/wiki/INTERNAL-ID'],
          ['2026 年代理商品牌广告账期规则 V1.0', 'https://docs.internal.example/wiki/INTERNAL-ID'],
          ['2026 年渠道代理商本地推竞价广告授信规则 V1.2', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['2026 年生态业务资金政策培训文档', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['2026 渠道授信提报系统指南', 'https://docs.internal.example/wiki/INTERNAL-ID'],
          ['千川代理商资金方案对比', 'https://docs.internal.example/wiki/INTERNAL-ID']
        ], note: '覆盖预借款、账期、付款担保、提报系统和融资方案。' },
        { k: '风控合规合集', docs: [
          ['合作伙伴管理规范－汇总解读版', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['▇▇ 年月度熔断机制与行业虚客治理 SOP v2.0', 'https://docs.internal.example/wiki/INTERNAL-ID'],
          ['生态渠道｜合规百宝箱', 'https://docs.internal.example/wiki/INTERNAL-ID']
        ] },
        { k: '代理商合作规则', docs: [
          ['2026 巨量营销代理商与千川服务商合作规则', 'https://docs.internal.example/wiki/INTERNAL-ID'],
          ['2026 巨量本地推代理商合作规则', 'https://docs.internal.example/wiki/INTERNAL-ID'],
          ['2026 巨量星图代理商合作规则', 'https://docs.internal.example/wiki/INTERNAL-ID'],
          ['2026 星图任务服务商合作规则', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['2026 星图撮合服务商合作规则', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['2026 星图 MCN 机构合作规则', 'https://docs.internal.example/docx/INTERNAL-ID']
        ] },
        { k: '代理商管理规范', docs: [
          ['合作伙伴管理规范－汇总解读版', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['▇▇ 年月度熔断、单端口管控与行业治理 SOP', 'https://docs.internal.example/wiki/INTERNAL-ID?from=INTERNAL-ID']
        ] },
        { k: '2026 年 Q4 代理商分层权益试点政策解读', docs: [
          ['千川／本地推渠道经理政策解读', 'https://docs.internal.example/wiki/INTERNAL-ID?from=INTERNAL-ID']
        ] },
        { k: '2026 年 Q4 千川服务商分层权益试点', docs: [
          ['千川服务商分层权益试点方案 V1.0', 'https://docs.internal.example/wiki/INTERNAL-ID']
        ], note: '2026/10/1–12/31；年度星级 × 季度 L 级双轨分层。' },
        { k: '2026 年 Q4 本地推服务商分层权益试点', docs: [
          ['本地推服务商分层权益试点方案 V1.0', 'https://docs.internal.example/wiki/INTERNAL-ID']
        ], note: '2026/10/1–10/31；分行业星级评选与权益积分兑换。' }
      ]
    },
    {
      k: '流程链接', call: '遇到关户、申诉、报备、客销变更、询价或招商下单时按事项直达。',
      rows: [
        { k: '客户身份作废', docs: [['CRM 关户／解封／废弃流程', 'https://docs.internal.example/docs/INTERNAL-ID']] },
        { k: '代理商清退流程', docs: [['代理商续约管理系统操作指南', 'https://docs.internal.example/docx/INTERNAL-ID']] },
        { k: '封户申诉', docs: [
          ['关联风险处置申诉材料与流程', 'https://docs.internal.example/docx/INTERNAL-ID'],
          ['AD 账户封停违规申诉流程', 'https://docs.internal.example/wiki/INTERNAL-ID']
        ] },
        { k: '政务客户免建档流程', docs: [['兜底功能白名单申请流程', 'https://docs.internal.example/docx/INTERNAL-ID']] },
        { k: 'PR 审核', docs: [
          ['公司A对外物料审核规范', 'https://docs.internal.example/wiki/INTERNAL-ID'],
          ['生态业务－渠道市场公关审核 SOP', 'https://docs.internal.example/docx/INTERNAL-ID']
        ], note: '公关申请需提前 ▇▇个工作日。' },
        { k: '跨年订单报备', docs: [['生态业务跨年订单执行流程', 'https://docs.internal.example/wiki/INTERNAL-ID']] },
        { k: 'AD 账户申诉', docs: [['AD 账户封停违规申诉流程', 'https://docs.internal.example/wiki/INTERNAL-ID']] },
        { k: '更改系统客户信息', docs: [
          ['流程提报入口', 'https://corp.internal.example/flowportal/submitapproval?appId=INTERNAL-ID'],
          ['电子签管理后台申请查询工具权限', 'https://docs.internal.example/docx/INTERNAL-ID']
        ] },
        { k: '客销关系变更', docs: [['全域经营－客销变更 SOP', 'https://docs.internal.example/docx/INTERNAL-ID']] },
        { k: '品专询价', docs: [['搜索品专询价操作指引', 'https://docs.internal.example/docx/INTERNAL-ID']] },
        { k: '对公验证免验', docs: [['对公验证－人工验证申请流程', 'https://docs.internal.example/wiki/INTERNAL-ID']] },
        { k: '招商打包', docs: [
          ['商机系统使用指南（销售版）', 'https://docs.internal.example/docx/INTERNAL-ID?refer_index=2&refer_type=citati'],
          ['招商项目打包／下单／结算全流程', 'https://docs.internal.example/wiki/INTERNAL-ID']
        ] },
        { k: '品牌风险单报备', docs: [['品牌广告风险单报备流程', 'https://docs.internal.example/wiki/INTERNAL-ID']], note: '按原文模板准备代理、客户、广告主 ID、投放周期、产品类型、金额与背景。' },
        { k: '本地推非积分判罚申诉', docs: [['本地推非积分判罚申诉流程指引', 'https://docs.internal.example/wiki/INTERNAL-ID']], note: '接到处置通知后 ▇▇个自然日内提交。' }
      ]
    },
    {
      k: '产品与运营', call: '做大促、素材优化、机构CA专项、报白或日常学习安排时调用。',
      rows: [
        { k: '电商大小促运营机制', docs: [['2025 各节点运营机制－千川组', 'https://docs.internal.example/docx/INTERNAL-ID']] },
        { k: '一级与二级行业优质素材消耗占比', docs: [['渠道《素材灵眼》创意生态行情表', 'https://docs.internal.example/sheets/INTERNAL-ID?sheet=INTERNAL-ID']] },
        { k: '学习日历', docs: [['生态业务渠道与互动学习安排', 'https://docs.internal.example/wiki/INTERNAL-ID?sheet=INTERNAL-ID']], note: '源表标注每日 18:00 更新。' },
        { k: '白名单报白合集', docs: [['报白合集共享视图', 'https://docs.internal.example/share/INTERNAL-ID/view/INTERNAL-ID']] },
        { k: '机构CA信息', docs: [['机构CA专项－渠道 All in ONE（对内）', 'https://docs.internal.example/wiki/INTERNAL-ID']] },
        { k: 'AI 非优排查及整改建议', docs: [['创意专项－AI 非优排查与整改建议（仅对内）', 'https://docs.internal.example/wiki/INTERNAL-ID']] },
        { k: '优质素材工作台', docs: [['优质素材工作台－九术看板', 'https://site.internal.example/']], note: '按周筛选个人对应代理商的优质素材数据。' }
      ]
    },
    {
      k: '小组资料沉淀', call: '做 C 组经营盘点、代理情况核对、大促推进与业绩预估时调用。',
      rows: [
        { k: '云图等级汇总', docs: [['▇▇ 年全域 C 组云图汇总', 'https://docs.internal.example/sheets/INTERNAL-ID?sheet=INTERNAL-ID']] },
        { k: '代理商 API 接入情况', docs: [['全域 C 组 API 事项', 'https://docs.internal.example/sheets/INTERNAL-ID?sheet=INTERNAL-ID']] },
        { k: '大促完成情况', docs: [
          ['C 组 ▇▇ 年大促节点膨胀整理与 ▇▇ 年续签意向', 'https://docs.internal.example/sheets/INTERNAL-ID?sheet=INTERNAL-ID'],
          ['▇▇ 年 C 组星级与 H1 大促情况整理', 'https://docs.internal.example/wiki/INTERNAL-ID']
        ] },
        { k: '业绩预估', docs: [['C 组代理 Q4 业绩预估', 'https://docs.internal.example/sheets/INTERNAL-ID?sheet=INTERNAL-ID']] }
      ]
    },
    {
      k: '工具模板', call: '需要活动 SOP、标准模板或批量生成经营报告时调用。',
      rows: [
        { k: '活动 SOP', docs: [['通用场景标准化 SOP／模板库', 'https://docs.internal.example/wiki/INTERNAL-ID?table=INTERNAL-ID&view=INTERNAL-ID']] },
        { k: '经营数据报告生成', docs: [['经营数据报告生成器', 'https://site.internal.example/']], note: '选择周期后可生成单代理或全部代理商报告，并打开飞书文档。' }
      ]
    },
    {
      k: '行业分类', call: '统一行业标签、做行业拆分或校验归类时调用。',
      rows: [
        { k: '行业分类', docs: [['广告行业标签 v4.0（公示版）', 'https://docs.internal.example/sheets/INTERNAL-ID?sheet=INTERNAL-ID']] }
      ]
    }
  ];

  return { SOURCE, GROUPS };
})();
