/* ═══════════════════════════════════════════════════════════
   rul.js —— 判断规则与口径（页面直接读仓库导出的数据文件）

   这一块对应她 2026-09-16 21:23 的落法：
     「把仓库里的判断规则和口径导成一份数据文件，让页面直接读」→ 就这么做

   为什么非做不可：
     原来页面上写的"一百多条规则 / 几十条口径"是我一条条**手抄进 JS** 的 ——
     她仓库改了，页面不会动，于是页面上的数字会慢慢变成假的。

   现在的链路（三步，页面上也照实写出来）：
     本地 Obsidian（权威）→ tools/export_rules.py 导出 → data/rules.data.js → 这一块直接读
   ⚠️ 实话：不是实时同步。导出是我每次收尾时跑的一步，
      所以页面上永远显示"导出于什么时候 / 源文件是几号的 / 已经旧了几天"。

   ⛔ 三条硬规矩：
     ▇▇. 条数、章节、日期全部来自导出文件，这个文件里我一个数字都不许手写；
     ▇▇. 仓库编号（R-xxx 那种）**不摆到可见文案上**（她说过页面上不要看我的字段名），
        但搜索框输编号能命中 —— 编号只挂在 data 属性里给她查；
     ▇▇. 抓不到结构化字段的条目，照实标"这条是从正文摘的"，不许润色成规则。
   ═══════════════════════════════════════════════════════════ */
window.RUL = (function () {

  const RKEY = 'cec.rul.v1';
  const D = (typeof window !== 'undefined' && window.RULDATA) || null;

  const esc = s => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  /* 源文件的"最近更新"在仓库里写成一长串（还带编号），只取日期，别把编号漏到页面上 */
  function dateOf(s) { const m = /(\d{4}-\d{2}-\d{2})/.exec(String(s || '')); return m ? m[1] : ''; }
  function ageOf(s) {
    const d = dateOf(s); if (!d) return null;
    const t = new Date(d + 'T00:00:00'), now = new Date(); now.setHours(0, 0, 0, 0);
    return Math.max(0, Math.round((now - t) / 86400000));
  }
  function ageTxt(s) {
    const n = ageOf(s);
    if (n === null) return '';
    return n === 0 ? '就是今天的' : (n === 1 ? '已旧 ▇▇ 天' : '已旧 ' + n + ' 天');
  }

  function load() { try { return JSON.parse(localStorage.getItem(RKEY) || '{}') || {}; } catch (e) { return {}; } }
  function save(v) { try { localStorage.setItem(RKEY, JSON.stringify(v)); } catch (e) {} }

  /* 搜索命中：规则连编号一起搜（编号不显示，但能搜到） */
  function hitRule(r, q) {
    if (!q) return true;
    return [r.id, r.title, r.sec, r.cond, r.act, r.why, r.sum, r.conf, r.fail]
      .filter(Boolean).join(' ').toLowerCase().indexOf(q) >= 0;
  }
  function hitTerm(t, q) {
    if (!q) return true;
    return [t.term, t.def, t.use, t.mix, t.warn, t.sum]
      .filter(Boolean).join(' ').toLowerCase().indexOf(q) >= 0;
  }

  /* 章节名里带编号系列（例："工具路由类（R-100 系列）"），可见文案要洗掉 */
  function secName(s) {
    return String(s || '未归类')
      .replace(/[（(]\s*R-\d+\s*系列[^）)]*[）)]/g, '')
      .replace(/[（(][^）)]*R-\d+[^）)]*[）)]/g, '')
      .replace(/R-\d+\s*~\s*R-\d+/g, '')
      .replace(/\s{2,}/g, ' ')
      .replace(/^[〇一二三四五六七八九十]+、\s*/, '')
      .trim() || '未归类';
  }

  function fallback() {
    return `<div class="rul rul--none" data-mod="m-rul" id="rul">
      <div class="rul__hd">
        <span class="rul__tag">规则与口径</span>
        <div class="rul__hdx"><b>这一块现在读不到数据文件。</b>
          <em>它要读的是 <code>data/rules.data.js</code>（从你本地 Obsidian 的判断规则库与口径词典导出的那一份）。
          读不到通常是两种情况：这一版部署漏了那个文件，或者导出没跑。
          <b>我不拿手抄的数字冒充它</b> —— 所以这里宁可空着，也不给你一个可能是假的条数。</em></div>
      </div>
    </div>`;
  }

  function render() {
    if (!D || !D.rules) return fallback();
    const st = load(), q = (st.q || '').trim().toLowerCase();
    const M = D.meta || {};

    const RS = D.rules.filter(r => hitRule(r, q));
    const TS = D.terms.filter(t => hitTerm(t, q));

    /* 按章节分组（顺序照仓库里的出现顺序，不重排 —— 重排会让她找不到熟悉的位置） */
    const order = [], byS = {};
    RS.forEach(r => {
      const k = r.sec || '';
      if (!byS[k]) { byS[k] = []; order.push(k); }
      byS[k].push(r);
    });

    const openS = st.open || {};
    const redT = TS.filter(t => t.red), normT = TS.filter(t => !t.red);

    return `<div class="rul" data-mod="m-rul" id="rul">

      <div class="rul__hd">
        <span class="rul__tag">规则与口径 · 页面直接读你的仓库</span>
        <div class="rul__hdx">
          <b>${M.ruleCount} 条判断规则 · ${M.termCount} 条口径，全部是从你本地仓库导出来的，不是我手抄进代码的。</b>
          <em>你 09-16 让我"把仓库里的判断规则和口径导成一份数据文件，让页面直接读"—— 这一块就是那件活的产物。
          以后你在 Obsidian 里改了规则，<b>我重跑一次导出，这一页跟着变</b>，页面上的条数永远是真的。</em>
        </div>
      </div>

      <div class="rul__meta">
        <div class="rulm"><span>判断规则</span><b>${M.ruleCount}</b><em>源文件 ${dateOf(M.ruleUpdated) || '—'} 更新 · ${ageTxt(M.ruleUpdated)}</em></div>
        <div class="rulm"><span>口径</span><b>${M.termCount}</b><em>源文件 ${dateOf(M.termUpdated) || '—'} 更新 · 口径数据截止 ${M.termCut || '—'}</em></div>
        <div class="rulm"><span>归类章节</span><b>${(M.sections || []).length}</b><em>照仓库里的分类，我不重排</em></div>
        <div class="rulm rulm--warn"><span>这一份导出于</span><b>${(M.exportedAt || '').slice(5)}</b><em>⚠️ 不是实时同步：仓库改完要我重跑一次导出</em></div>
      </div>

      <div class="rul__how">
        <span class="rul__hk">这一页的数从哪来（三步，缺一步页面就该空着）</span>
        <ol>
          <li><b>你的本地 Obsidian</b> 是权威源：判断规则库 ${M.ruleLines} 行、口径词典 ${M.termLines} 行</li>
          <li><b>我跑一次导出</b>（<code>tools/export_rules.py</code>，只读不写你的仓库）→ 生成数据文件</li>
          <li><b>页面读那个文件</b>：条数、章节、日期全部现取；<b>我在任何地方都不再手写这些数字</b></li>
        </ol>
        <p class="rul__hf">编号（你仓库里那套 R 开头的号）我没摆在页面上 —— 你说过不想在页面上看我的字段名。
        <b>但搜索框里输编号能命中</b>，你想按号查照样查得到。</p>
      </div>

      <div class="rul__srch">
        <input class="rul__q" type="search" value="${esc(st.q || '')}"
          placeholder="搜一个词就行：待结算 / 折旧 / 拜访 / 报价 / 分母 / 也可以直接输仓库编号" />
        <span class="rul__qn">${q ? `命中 <b>${RS.length}</b> 条规则 · <b>${TS.length}</b> 条口径` : `共 <b>${D.rules.length}</b> 条规则 · <b>${D.terms.length}</b> 条口径`}</span>
        ${q ? '<button class="rul__clr" data-rclr="▇▇">清空搜索</button>' : ''}
      </div>

      <div class="rul__sec">
        <div class="rul__h"><span class="rul__n">口径 · 同一个词只能有一种算法</span>
          <em>这一册最值钱的地方是<b>"哪两个数不许混"</b> —— 混过一次的代价你比我清楚</em></div>
        ${redT.length ? `<div class="rul__red">
          <span>⛔ 红线口径（${redT.length} 条）</span>
          ${redT.map(t => `<div class="rult is-red">
            <b class="rult__t">${esc(t.term)}</b>
            ${t.def ? `<p class="rult__d"><span>算法</span>${esc(t.def)}</p>` : ''}
            ${t.warn ? `<p class="rult__w">${esc(t.warn)}</p>` : ''}
            ${!t.def && t.sum ? `<p class="rult__s"><span>正文摘的</span>${esc(t.sum)}</p>` : ''}
          </div>`).join('')}
        </div>` : ''}
        <div class="rul__tl">${normT.map(t => `<div class="rult">
          <b class="rult__t">${esc(t.term)}</b>
          ${t.def ? `<p class="rult__d"><span>算法</span>${esc(t.def)}</p>` : ''}
          ${t.use ? `<p class="rult__u"><span>用在哪</span>${esc(t.use)}</p>` : ''}
          ${t.mix ? `<p class="rult__m"><span>别跟它混</span>${esc(t.mix)}</p>` : ''}
          ${t.warn ? `<p class="rult__w">${esc(t.warn)}</p>` : ''}
          ${!t.def && t.sum ? `<p class="rult__s"><span>这条正文不是"定义"写法，摘给你看</span>${esc(t.sum)}</p>` : ''}
          ${!t.def && !t.sum && t.tblOnly ? `<p class="rult__s"><span>这条在仓库里是一张对照表</span>页面不复制表格，也不替你概括 —— 要看去仓库原文</p>` : ''}
        </div>`).join('')}</div>
      </div>

      <div class="rul__sec">
        <div class="rul__h"><span class="rul__n rul__n--r">判断规则 · 条件 → 动作</span>
          <em>点章节名展开。每条都写清<b>什么时候触发、我该做什么</b>；有失效条件的一并带出来</em></div>
        <div class="rul__gl">${order.map(k => {
          const list = byS[k], on = q ? 1 : !!openS[k];
          return `<div class="rulg${on ? ' is-open' : ''}" data-rsec="${esc(k)}">
            <button class="rulg__h" data-rsx="${esc(k)}">
              <b>${esc(secName(k))}</b><span class="rulg__n">${list.length} 条</span>
              <i class="rulg__c">${on ? '收起' : '展开'}</i>
            </button>
            ${on ? `<div class="rulg__l">${list.map(r => `<div class="rulr" data-rid="${esc(r.id)}" title="仓库编号 ${esc(r.id)}">
              <b class="rulr__t">${esc(r.title)}</b>
              ${r.cond ? `<p class="rulr__c"><span>什么时候</span>${esc(r.cond)}</p>` : ''}
              ${r.act ? `<p class="rulr__a"><span>就这么做</span>${esc(r.act)}</p>` : ''}
              ${r.why ? `<p class="rulr__y"><span>为什么</span>${esc(r.why)}</p>` : ''}
              ${!r.cond && !r.act && r.sum ? `<p class="rulr__s"><span>这条在仓库里是段正文，摘前两句</span>${esc(r.sum)}</p>` : ''}
              <div class="rulr__f">
                ${r.conf ? `<span class="rulr__k">把握：${esc(r.conf)}</span>` : ''}
                ${r.fail ? `<span class="rulr__x">什么情况失效：${esc(r.fail)}</span>` : ''}
              </div>
            </div>`).join('')}</div>` : ''}
          </div>`;
        }).join('')}</div>
      </div>

      <p class="rul__ft">这一页你可以直接改：在 Obsidian 里改规则或口径正文，跟我说一句"重导规则"，下一次刷新页面就是新的。
      <b>你删掉的规则页面也会跟着消失</b> —— 这就是"页面直接读仓库"的意思。</p>
    </div>`;
  }

  function repaint() {
    document.querySelectorAll('.rul').forEach(box => {
      const holder = box.parentElement; if (!holder) return;
      const focus = document.activeElement && document.activeElement.classList.contains('rul__q');
      const pos = focus ? document.activeElement.selectionStart : null;
      const tmp = document.createElement('div');
      tmp.innerHTML = render();
      holder.replaceChild(tmp.firstElementChild, box);
      if (focus) {
        const i = document.querySelector('.rul__q');
        if (i) { i.focus(); try { i.setSelectionRange(pos, pos); } catch (e) {} }
      }
    });
  }

  let tmr = null;
  function wire() {
    document.addEventListener('click', e => {
      const h = e.target.closest('.rulg__h');
      if (h) {
        const st = load(); st.open = st.open || {};
        const k = h.dataset.rsx;
        st.open[k] = !st.open[k];
        save(st); repaint(); return;
      }
      const c = e.target.closest('.rul__clr');
      if (c) { const st = load(); st.q = ''; save(st); repaint(); return; }
    });
    document.addEventListener('input', e => {
      const i = e.target.closest('.rul__q');
      if (!i) return;
      const st = load(); st.q = i.value; save(st);
      clearTimeout(tmr); tmr = setTimeout(repaint, 220);   /* 防抖：边打字边重绘会把光标弄丢 */
    });
  }

  return { render, wire, DATA: D };
})();

(function () {
  const go = () => { try { RUL.wire(); } catch (e) { console.warn('rul', e); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go);
  else go();
})();
