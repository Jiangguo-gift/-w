/* ═══════════════════════════════════════════════════════════
   渲染层 · 原生 DOM，无框架
   v1：模块登记 + 页内编辑 + 视图筛选 + 命令面板 + 智能推荐
   ═══════════════════════════════════════════════════════════ */

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const cut = (s, n = 26) => { s = String(s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n) + '…' : s; };

const ST = { run: '在跑', part: '部分', gap: '空缺', open: '未开', off: '闲置' };
const dot = st => `<span class="dot dot--${st}" title="${ST[st] || ''}"></span>`;
const gapAttr = st => `data-gap="${st === 'gap' ? 1 : 0}"`;
const tag = (t, k = '') => `<span class="tag${k ? ' tag--' + k : ''}">${t}</span>`;

/* ── 视图骨架 ─────────────────────────────
   v8：不再是 ▇▇ 节一路滚到底，而是四大分区 × ▇▇个视图，一次只显示一个。
   分区与视图的定义全部搬到 os.js（OS.SECS），这里只取用，
   避免同一份目录在两个文件里各写一遍、改一处漏一处。 */
const SECS = OS.SECS;

/* ── 通用组件 ─────────────────────────── */
/* ── 信息分层 ─────────────────────────────
   2026-09-12 v6：上一版 ▇▇万字全部同一层级铺开，等于没有重点。
   现在强制三层：
     L1 结论  —— 一句话 + 关键数字，永远可见
     L2 证据  —— 表格、明细、长文，精简模式收起
     L3 溯源  —— 落点路径、依据链接，点开才有
   peek() 负责 L2。精简模式下整体收起，完整模式下全开。
   注意：本文件下方已有一个历史 fold()（问答式折叠，.fold/.fold__b/.sign），
   两者共存，不要重名——上一版就是因为重名把旧折叠按钮整片压没了。 */
let PK_SEQ = 0;
function peek(body, label = '看证据', n = '') {
  const i = ++PK_SEQ;
  return `<div class="pk" data-pk="${i}">
    <button class="pk__t" type="button" data-pkt="${i}">
      <i class="pk__x">▸</i><span>${label}</span>${n !== '' ? `<b class="pk__n">${n}</b>` : ''}
    </button>
    <div class="pk__b">${body}</div>
  </div>`;
}

/* 一句话结论条 —— 每个 block 的 L1。这是精简模式下唯一保证可见的文字 */
function lead(txt, st) {
  return `<p class="lead${st ? ` lead--${st}` : ''}">${txt}</p>`;
}

/* ── 主次分级 ────────────────────────────
   上一版 ▇▇个模块全是同一个视觉重量，等于没有重点。
   这里把模块分两档：
     主模块  —— 回答「现在什么状态 / 我该动哪一下」，永远摊开
     次模块  —— 证据、清单、明细，精简模式下只留一句结论，点开才看
   GIST 是次模块收起时露出的那一句。它必须是结论，不是目录。 */
const GIST = {
  /* ▇▇ 驾驶舱 */
  'm-recent':     '最近 ▇▇ 天全部是我在写，<b>你一条原始素材都没进来</b>——这是当前最该改的一件事',
  'm-evo':        'v1→v7 七个版本，<b>每一版都是被你的裁决逼出来的</b>，没有一版是我自己想改的；v7 把五张业务看板和五个数据源收进了 ▇▇',
  /* ▇▇ 系统状态 */
  'm-sixdir':     '六目录已用 Bases 视图搭好，<b>不搬文件</b>——搬了会把 Obsidian 链接全打断',
  'm-threelayer': 'raw→wiki→规则三层里，<b>raw 层是空的</b>，所以后两层全靠我从对话里扒',
  'm-inbox':      '收件箱 ▇▇条。<b>它空不是因为干净，是因为没通道</b>',
  'm-layers':     'L0/L1/L2/L3 四层都有文件，<b>但 L1 事实层最薄</b>——判断多、事实少',
  /* ▇▇ 「外部大盘」 */
  'm-insight':    '这一节现在几乎是空的。<b>我没有拿搜来的公开资讯冒充你的行业判断</b>（等 Q-030）',
  'm-trend':      '趋势观察 ▇▇条。规格已定：只存你的判断，每周 ≤▇▇条，<b>我不代写</b>',
  /* ▇▇ 业务基本盘 */
  'm-industry':   '▇▇个行业专题里，<b>我的机构/客户/业绩占比三列全是「—」</b>——打标数据还没接进来',
  'm-rhythm':     '七个节奏里<b>只有周报那条真的在跑</b>，日频三条链全部卡在没有入料口',
  'm-aicap':      '你的业务动作有一半我接得上，<b>接不上的那半都卡在同一件事：拿不到原始素材</b>',
  'm-frames':     '八个业务框架已全部入库，<b>但只有周报框架被真实用过</b>',
  'm-assets':     '知识库资产按四层归位完毕，<b>审核类和学习中心两块还是壳</b>',
  /* ▇▇ 能力进阶 */
  'm-skills':     '▇▇个技能你裁决「都留着不动」，<b>清理建议已作废</b>，这一版不再提',
  'm-plugins':    '社区插件只装了 ▇▇个，<b>而且都跟这套系统无关</b>；audio-recorder 还没装',
  'm-commands':   '高阶指令已成册，<b>每天 10:00 三问是唯一固定动作</b>，其余都按需触发',
  'm-optimize':   '六个 skill 模板已按「角色/输入/工作流/硬约束/输出/验收」重写，变量统一 {{}}',
  /* ▇▇ 协作机制 */
  'm-routing':    '我收到请求后的实际决策链，<b>三个红格子是硬停</b>——我不会绕过去自行决断',
  'm-acts':       '我能自己动手的、必须先问你的、我根本做不了的，三类划清了',
  /* ▇▇ 确认 */
  'm-feedback':   '关于这一页本身，<b>我有三件事拿不准</b>，想听你的'
};
const SECOND = new Set(Object.keys(GIST));

function block(id, title, hint, note, body) {
  const m = MODS[id];
  const sec = SECOND.has(id);
  /* 次模块：结论常驻，证据收进 peek；主模块：原样摊开 */
  const inner = sec
    ? lead(GIST[id]) + peek((note ? `<p class="block__note">${note}</p>` : '') + body, '看这块的依据')
    : (note ? `<p class="block__note">${note}</p>` : '') + body;
  return `<div class="block${sec ? ' block--2nd' : ''}" data-mod="${id}">
    <div class="block__h"><h3>${title}</h3>${hint ? `<span class="hint">${hint}</span>` : ''}</div>
    <div class="modbar">
      <div class="modbar__st" data-st-for="${id}"></div>
      <button class="mbtn" data-annot="${id}">批注 <span class="mbtn__c" data-annot-c="${id}"></span></button>
      ${(m ? m.links : []).map((l, i) => `<a class="mbtn${l.mode === 'new' ? ' mbtn--new' : ''}"
        href="${obsURI(l)}" title="${esc(l.f)}${l.mode === 'new' ? '（还不存在，点了就新建）' : ''}"
        >${l.mode === 'new' ? '＋ ' : ''}${esc(l.t)} ↗</a>`).join('')}
    </div>
    <div class="annot" data-annot-box="${id}">
      <div class="annot__k">我的批注</div>
      <textarea placeholder="这一块哪里不对、该补什么、口径要改成什么 —— 写在这里"></textarea>
      <div class="annot__row">
        <button class="annot__send" data-annot-send="${id}">提交给 Aime</button>
        <span class="annot__h">提交后直接进我的收件箱，不用导出补丁</span>
      </div>
    </div>
    ${inner}
  </div>`;
}
function table(cols, rows) {
  return `<table class="tbl"><thead><tr>${cols.map(c =>
    `<th${c.w ? ` style="width:${c.w}"` : ''}${c.num ? ' class="num"' : ''}>${c.t}</th>`).join('')}</tr></thead>
    <tbody>${rows.join('')}</tbody></table>`;
}
function cells(list, cls = 'grid--▇▇') {
  return `<div class="grid ${cls}">${list.map(c => `<div class="cell">
    <div class="cell__k"><span>${c.k}</span>${c.st ? dot(c.st) : ''}</div>
    <div class="cell__v">${c.v}${c.u ? `<small>${c.u}</small>` : ''}</div>
    <div class="cell__d">${c.d}</div></div>`).join('')}</div>`;
}
function fold(t, meta, inner, open = false) {
  return `<div class="fold${open ? ' is-open' : ''}">
    <button class="fold__b"><span class="sign">${open ? '−' : '+'}</span><span>${t}</span>
    <span class="meta">${meta || ''}</span></button>
    <div class="fold__c">${inner}</div></div>`;
}

/* ── OV 驾驶舱 ────────────────────────── */
function dcard(o) {
  const m = MODS[o.id] || { links: [] };
  const links = m.links.map(l =>
    `<a class="dcard__a" href="${obsURI(l)}" title="${esc(l.f)}${l.mode === 'new' ? '（还不存在，点了就新建）' : ''}">${l.mode === 'new' ? '＋' : '↗'} ${esc(cut(l.t, 14))}</a>`).join('');
  return `<div class="dcard dcard--${o.w}" data-mod="${o.id}" data-gap="${o.gap ? 1 : 0}">
    <div class="dcard__h">
      <span class="dcard__t">${o.t}</span>
      ${links || `<span class="dcard__m">${o.m || ''}</span>`}
    </div>
    <div class="dchart" id="${o.c}" style="height:${o.h}px"></div>
    ${o.lg ? `<div class="dlg">${o.lg.map(x =>
      `<span class="dlg__i"><i class="dlg__s" style="background:${x.c}"></i>${x.t}${x.n != null ? ` <b class="dlg__n">${x.n}</b>` : ''}</span>`).join('')}</div>` : ''}
    <div class="dcard__f">${o.f1 || o.f}${o.f1 && o.f ? peek(`<div class="fmore">${o.f}</div>`, '为什么') : ''}</div>
  </div>`;
}

function secDeck(d) {
  const q = d.queue, h = d.growth.health;
  /* 智能推荐条：按当前页面状态实时算，放在驾驶舱第一屏 */
  const dayRun = d.rhythm.rows.filter(r => r.cyc === '每日' && r.st === 'run').length;
  const dayAll = d.rhythm.rows.filter(r => r.cyc === '每日').length;
  const S = 'var(--signal)', R = 'var(--run)', O = 'var(--open)', I = 'var(--ink)', I4 = 'var(--ink-4)';

  /* 批次横幅 —— 这一版是被你的裁决驱动的，不是我自己想的，所以放在最上面 */
  const vb = d.verdictBatch;
  let out = `<div class="next" id="next"></div>
  <div class="batch" data-mod="d-batch">
    <div class="batch__l">
      <div class="batch__k">VERDICT BATCH</div>
      <div class="batch__v">${vb.n}<small>条</small></div>
      <div class="batch__d">${vb.stamp}</div>
    </div>
    <div class="batch__r">
      <p>${vb.note}</p>
      <p class="batch__kill">${vb.kill}</p>
      <div class="batch__acts">
        <button class="chip" data-jumpv="confirm">看 ▇▇条怎么落的 ↘</button>
        <button class="chip" data-go2="gate-Q-035">最堵的那条 Q-035 ↘</button>
      </div>
    </div>
  </div>`;

  /* 指标条 —— 七个数，全部实测，没有一个是业绩 */
  const kpis = [
    { k: '仓库笔记', v: MIND.FACT.notes, u: '篇', tone: '',
      d: '约 ▇▇KB。<b>规则与口径层独占大头</b>，规则比原料厚得多' },
    { k: '判断规则', v: h.total, u: '条', tone: 'run',
      d: `已验证 ${h.verified} · 反面教材 ${h.counter}。<b>其中 ▇▇条待归类</b>（R-504~▇▇）` },
    { k: '口径条目', v: MIND.FACT.cal, u: '条', tone: 'run',
      d: '结算 / 在途 / 待结算池 / 报价……<b>全库最硬的一格</b>' },
    { k: '空目录', v: 5, u: '个', tone: 'signal',
      d: '机构档案 · 拜访 · 方案 · 收件箱 · 附件，<b>全是原料层</b>' },
    { k: '日频链条', v: `${dayRun}/${dayAll}`, u: '在跑', tone: 'signal',
      d: '三条日频动作全断，<b>落点都在空目录上</b>' },
    { k: '本轮已裁决', v: d.verdictBatch.n, u: '条', tone: 'run',
      d: '<b>09-12 一天两批。</b>其中 ▇▇条直接推翻了我自己的判断' },
    { k: '仍待你裁决', v: q.open, u: '条', tone: 'signal',
      d: `其中 <b>${q.hot} 条标红</b>。<b>Q-035（Q3 收口盯哪个数）是现在最硬的堵点</b>，它不定，季度收口的分母就是两个` }
  ];
  out += `<div class="kstrip">${kpis.map(x => `<div class="kstrip__i" data-tone="${x.tone}">
    <div class="kstrip__k">${x.k}</div>
    <div class="kstrip__v">${x.v}<small>${x.u}</small></div>
    <div class="kstrip__d">${x.d}</div></div>`).join('')}</div>`;

  /* 九张图分两档：先看三张主图，其余六张收起 —— 九张等权铺开等于没有重点 */
  out += `<div class="dgrid">`;

  out += dcard({ id: 'd-dirs', w: 6, h: 268, c: 'c-dirs', gap: 1,
    t: '十二个目录的实际填充',
    lg: [{ c: I, t: '≥▇▇篇' }, { c: 'var(--ink-3)', t: '▇▇–▇▇篇' }, { c: S, t: '一篇都没有', n: 5 }],
    f1: '<b>▇▇个目录一篇都没有</b>，且全部落在原料层',
    f: '<b>五条红虚线是这张图的全部信息量。</b>它们全部集中在原料层和现场层——<em>系统不缺产线，缺投料口</em>。' });

  out += dcard({ id: 'd-rulehealth', w: 3, h: 268, c: 'c-rulehealth',
    t: '规则库健康度', m: `${h.verified} / ${h.total}`,
    f1: `<b>${h.verified}/${h.total} 这个数要打折看</b>——真被打脸修正过的只有 ${h.fixed} 条`,
    f: `多数"已验证"是从飞书文档搬来的，<em>没被真实业务验证过</em>。<br>⚠️ 按 Q-023 新生效的验证闸重核后，<b>这个百分比会掉下来——那才是真实值</b>。` });

  out += dcard({ id: 'd-queue', w: 3, h: 268, c: 'c-queue', gap: 1,
    lg: [{ c: S, t: '待裁决', n: q.open }, { c: R, t: '已归档', n: q.filed },
         { c: I4, t: '已否决', n: q.denied }, { c: S, t: '其中标红', n: q.hot }],
    t: '待复核队列全景', m: `共 ${q.open + q.filed + q.denied} 条`,
    f1: `09-12 两批共裁 ▇▇条；<b>未裁实测 ${q.open} 条</b>，其中 ${q.hot} 条真正挡路`,
    f: q.note });

  out += `</div>`;

  /* ── 其余六张：收起，点开才看 ───────── */
  let more = `<div class="dgrid">`;

  more += dcard({ id: 'd-pyramid', w: 4, h: 268, c: 'c-pyramid', gap: 1,
    t: '原料 → 整理 → 规则',
    f1: '<b>金字塔是倒的</b>：规则 ▇▇篇，原料 ▇▇篇',
    f: '正常的知识系统应该是 raw 最宽、规则最窄。<b>你现在正好倒过来</b>——规则 ▇▇篇、原料 ▇▇篇。规则没原料喂，只能靠搬别人的文档长。' });

  more += dcard({ id: 'd-rulecats', w: 3, h: 250, c: 'c-rulecats', gap: 1,
    t: '规则库七类构成',
    f1: '<b>只剩「拜访策略」一类是 ▇▇</b>，归因类本轮填上 ▇▇条（待验证）',
    f: '<b>「客户增减投归因」这个空了三天的类，本轮填上了 ▇▇条</b>——来自你裁决留下的 v0 五问链（Q-025）。<em>但三条都标待验证：搬进来不等于验过。</em><br>⛔ 只剩<b>拜访策略</b>还是 ▇▇，它的原料目录 40- 也还是空的——<em>不是没总结，是没素材</em>。' });

  more += dcard({ id: 'd-rhythm', w: 5, h: 250, c: 'c-rhythm', gap: 1,
    t: '七个周期节奏 · 跑没跑',
    lg: [{ c: R, t: '在跑' }, { c: O, t: '半跑' }, { c: S, t: '断了' }],
    f1: '<b>跑得动的全是周/季，断掉的全是日频</b>——落点都在空目录',
    f: '<b>跑得动的全是「周 / 季」，断掉的全是「日」。</b>日频三条动作有个共同点：<em>落点都在空目录</em>。不是自律问题，是写第一篇的摩擦最大。' });

  more += dcard({ id: 'd-supply', w: 4, h: 250, c: 'c-supply', gap: 1,
    t: '达人名单容量 vs 口径', m: '竖线 = 目标 / 口径',
    f1: '<b>「结构上限 ▇▇」已作废</b>；AI 创作者按打标表 ▇▇ 定案',
    f: '⚠️ <b>原来那句「结构上限 ▇▇、全员激活也达不成」已作废</b>——你裁决补 ▇▇人进名单，我那个结论默认了名单不可变。AI 创作者按打标表 <b>▇▇</b> 定案。<em>补人之前分母仍按 ▇▇ 算。</em>' });

  more += dcard({ id: 'd-boards', w: 5, h: 230, c: 'c-boards',
    t: '▇▇条入口 × ▇▇个板块',
    lg: [{ c: I, t: '稳定入口（已镜像）', n: 39 }, { c: O, t: '每日内容流（不镜像）', n: 83 }],
    f1: '<b>▇▇条动态流只有入口、没有沉淀</b>，判断跟着流水一起冲走了',
    f: '<b>▇▇条动态流只有入口，没有沉淀。</b>不镜像内容是对的，但你从趋势里得出的判断也一起没了——这正是六目录里<em>灵感库缺失</em>的后果。' });

  more += dcard({ id: 'd-skills', w: 4, h: 230, c: 'c-skills', gap: 1,
    t: 'Aime 技能池 ▇▇个', m: '按业务贴合度',
    f1: '<b>清理建议被你整条否了，▇▇个一个不动</b>——你是对的',
    f: '⚠️ <b>我的清理建议被你整条否了，▇▇个一个不动。</b>你是对的：留着成本近乎为零，误删一个偶尔要用的成本很高。<em>重叠让我调用时犹豫，那是我的问题，不该你买单。</em>' });

  more += `</div>`;
  out += `<div class="dmore" data-mod="d-more">${peek(more, '再看 ▇▇张结构图', 6)}</div>`;

  /* 五段闭环 */
  const segs = d.loop.segs;
  out += `<div class="flowstrip" data-mod="d-loop">
    <div class="flowstrip__l">
      <div class="flowstrip__k">CLOSED LOOP</div>
      <div class="flowstrip__v">五段闭环<br>断在<em>第一段</em></div>
      <div class="flowstrip__d">存 / 判 / 确 / 长 四段都已成形，<b>唯独「采」是 ▇▇ 手动</b>。这也是上面那五个空目录的同一件事。</div>
    </div>
    <div class="flowstrip__r">${segs.map(g => `<div class="fseg ${g.weak ? 'fseg--weak' : ''}" data-gap="${g.weak ? 1 : 0}">
      <div class="fseg__c">${g.c}</div>
      <div class="fseg__n">${g.n}</div>
      <div class="fseg__t">${g.weak ? '断点' : '成形'}</div>
      <div class="fseg__bar"><i style="width:${g.weak ? 18 : 100}%"></i></div>
      <div class="fseg__d">${g.d.replace(/<\/?b>/g, '')}</div>
    </div>`).join('')}</div>
  </div>`;

  out += `<div id="verdict" class="masthead__verdict"></div>`;

  /* v8：能力迭代 / 主动建议 / 灵感库 已拆成侧栏里三个独立视图，不再挤在这一页 */
  out += `<div class="jumpstrip">
    <button class="jumpstrip__i" data-jumpv="evo"><b>系统能力迭代</b><span>v1→v8 每一版都是被你逼出来的 →</span></button>
    <button class="jumpstrip__i" data-jumpv="advice"><b>主动建议与思考</b><span>三条我自己推出来的，可采纳可驳回 →</span></button>
    <button class="jumpstrip__i" data-jumpv="spark"><b>灵感库</b><span>随手记，我按标签落目录 →</span></button>
  </div>`;
  return out;
}

/* ── ▇▇ 系统状态 ──────────────────────── */
function secState(d) {
  let out = '';

  out += block('m-layers', '四层结构填充度', 'AIME.md §▇▇', d.layers.note,
    table(
      [{ t: '层' }, { t: '目录', w: '120px' }, { t: '篇', num: 1, w: '46px' }, { t: 'KB', num: 1, w: '54px' }, { t: '内容' }],
      d.layers.rows.map(r => `<tr ${gapAttr(r.st)}>
        <td class="nm">${dot(r.st)}${r.n}</td><td class="pth">${r.p}</td>
        <td class="num">${r.c}</td><td class="num">${r.kb}</td><td>${r.d}</td></tr>`)
    ));

  const mx = d.dirs.max;
  out += block('m-dirs', '十二个目录的实际填充', '横条 = 笔记数', d.dirs.note,
    `<div class="bars">${d.dirs.rows.map(r => {
      const empty = r.c === 0;
      const pct = Math.max(r.c / mx * 100, 4);
      return `<div class="barrow" ${gapAttr(empty ? 'gap' : 'run')}>
        <div class="bar">
          <span class="bar__l">${r.n}</span>
          <span class="bar__t${empty ? ' is-empty' : ''}">${empty ? '' :
            `<span class="bar__f${r.c <= 2 ? ' is-thin' : ''}" style="width:${pct}%"></span>`}</span>
          <span class="bar__n${empty ? ' is-empty' : ''}">${empty ? '空' : r.c + ' 篇'}</span>
        </div>
        <div class="bar__note">${r.note}</div>
      </div>`;
    }).join('')}</div>`);

  out += block('m-recent', '系统这两天学到了什么', '学习日志 ▇▇篇', d.recent.note,
    table([{ t: '日期', w: '64px' }, { t: '性质', w: '54px' }, { t: '事件' }],
      d.recent.rows.map(r => `<tr><td class="pth">${r.d}</td>
        <td>${tag(r.k, r.k === '校准' ? 'run' : (r.k === '搬运' ? 'open' : ''))}</td>
        <td>${r.t}</td></tr>`))
    + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${d.recent.insight}</p>`);

  /* Q-021 裁定：六目录做成 Bases 视图，不搬文件。这是系统结构，不是业务内容，所以留在 ▇▇ */
  out += block('m-sixdir', '六目录 × 现有目录 映射', 'Q-021：做视图，不搬文件', d.sixdir.note,
    table([{ t: '六目录', w: '108px' }, { t: '映射到现有', w: '190px' }, { t: '现状', num: 1, w: '86px' }, { t: '判断' }],
      d.sixdir.rows.map(r => `<tr ${gapAttr(r.st)}>
        <td class="nm">${dot(r.st)}${r.n}</td><td class="pth" style="white-space:normal">${r.map}</td>
        <td class="num">${r.c}</td><td>${r.d}</td></tr>`)));

  out += block('m-threelayer', '三层数据流 · 倒金字塔', 'raw / wiki / agent.md', d.threelayer.note,
    table([{ t: '层', w: '132px' }, { t: '映射', w: '190px' }, { t: '篇', num: 1, w: '46px' }, { t: '判断' }],
      d.threelayer.rows.map(r => `<tr ${gapAttr(r.st)}>
        <td class="nm">${dot(r.st)}${r.n}</td><td class="pth" style="white-space:normal">${r.map}</td>
        <td class="num">${r.c}</td><td>${r.d}</td></tr>`))
    + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${d.threelayer.insight}</p>`);

  return out;
}

/* ── ▇▇ 「外部大盘」 ──────────────────────── */
/* ⛔ 按 2026-09-12 指令：这一节只留外部生态。
   行业覆盖（m-industry）与达人名单容量（m-supply）已整块搬去 ▇▇ 业务基本盘。 */
function secEco(d) {
  let out = '';

  out += `<div class="movedbar" data-mod="m-ecoscope">
    <div class="movedbar__k">这一节不承载什么</div>
    <div class="movedbar__b"><b>行业覆盖结构</b>、<b>达人名单容量</b>、<b>业务动作 × AI 能力对账</b>三块已于 2026-09-12 整块搬进
      <a href="#base" data-to="base">▇▇ 业务基本盘 ↓</a>。<br>
      这一节从此<em>只看外部</em>：市场在发生什么、别人在怎么玩、哪种达人形态在起量。
      <b>它现在几乎是空的——这是真实状况</b>，我没有拿搜来的公开资讯把它填满冒充你的行业判断。要不要建外部管道，见 ▇▇ 节 Q-030。</div>
  </div>`;

  out += block('m-trend', '市场趋势入料口', '▇▇条动态流', d.trend.note,
    table([{ t: '板块', w: '180px' }, { t: '链接数', num: 1, w: '66px' }, { t: '内容' }],
      d.trend.rows.map(r => `<tr><td class="nm">${r.n}</td><td class="num">${r.c}</td><td>${r.d}</td></tr>`))
    + `<div class="grid grid--▇▇" style="margin-top:16px">
        <div class="cell" data-gap="▇▇"><div class="cell__k"><span>问题</span>${dot('gap')}</div>
          <div class="cell__d" style="margin-top:▇▇">${d.trend.problem}</div></div>
        <div class="cell"><div class="cell__k"><span>建议动作</span>${dot('open')}</div>
          <div class="cell__d" style="margin-top:▇▇">${d.trend.proposal}</div></div>
      </div>`);

  out += TOOLS.ecoBlocks();
  return out;
}

/* ── ▇▇ 业务基本盘 ────────────────────── */
/* ⭐ 2026-09-12 起：所有跟业务、跟业绩相关的内容只能出现在这一节。
   行业覆盖 / 达人名单容量 从 ▇▇ 迁入；AI 能力对账由 TOOLS.baseBlocks() 带入。 */
function secBase(d) {
  let out = '';

  out += `<div class="movedbar movedbar--own" data-mod="m-basescope">
    <div class="movedbar__k">这一节承载什么</div>
    <div class="movedbar__b">按你 2026-09-12 的指令，<b>凡是「我的」——我的行业、我的名单、我的节奏、我的框架、我的客户归因——一律只在这一节出现</b>，
      其他章节不再沿用、不再重复、不做镜像。<br>
      <b>本轮新增（10-14 九术刷新）</b>：经营盘面、订单状态漏斗、四个数据底仓入口与四条 Q4 策略动作，全部放在这一节最前面。
      业绩金额从此<b>在 ▇▇ 内部允许出现</b>（此前只允许在周报看板），但每一个数字必须标明「来自哪张看板 + 数据截止日」，无来源数字不得进入。<br>
      <b>本轮新增（09-13）</b>：最前面加了一块<b>「本周策略回顾」固定框架</b>——按你 09-13 给的五个板块写死，每周同一批问题、只换数字和结论。要改框架在那一块底部直接提交。<br>
      顺序是：<em>Q4 策略回顾（固定五板块）→ 经营总判断 → 四条当前动作 → 口径对照 → 看板入口 → 四个数据源 → 行业覆盖 → 名单容量 → 周期节奏 → AI 能力 → 业务框架 → 工具 → 知识库资产</em>。</div>
  </div>`;

  /* ── 2026-09-12 新增：业务模块总览 + 数据底仓 + 策略汇总 ──
     ⚠️ 本周策略回顾（REVIEW）不在这里，它在折叠层之外、这一页最上方常驻显示 —— 见 renderSections() */
  out += `<div class="bzsec__h" style="margin-top:4px;margin-bottom:20px">
    <h3>业务推进区 · 看板 / 数据源 / 动作</h3>
    <p>这一页最上面的<b>「Q4 策略回顾」给结论</b>；这里往下是<b>每天要动手的地方</b>——经营总判断、数据校准、四条策略动作、口径对照、看板入口与四个数据底仓。结论在上、执行在下，不重复。</p>
  </div>`;
  out += BIZ.boardBlocks();

  out += `<div class="bzsec__h" style="margin-top:34px;margin-bottom:20px">
    <h3>结构底盘 · 覆盖 / 容量 / 节奏 / 框架</h3>
    <p>上面是<b>数在哪、说明什么、该动哪一下</b>；下面这几块是<b>我这套系统的结构对账</b>——哪些行业我有覆盖、名单有多大、七个节奏跑没跑。两者不重复。</p>
  </div>`;

  out += block('m-industry', '▇▇个行业专题 × 我的覆盖', '从 ▇▇ 迁入 · 工作台 ▇▇ 板块', d.industries.note,
    cells(d.industries.stats.map(s => ({ k: s.k, v: s.v, d: s.d })), 'grid--▇▇')
    + `<div style="height:16px"></div>`
    + table([{ t: '行业' }, { t: '形态', w: '90px' }, { t: '我的机构', num: 1, w: '76px' }, { t: '我的客户', num: 1, w: '76px' }, { t: '业绩占比', num: 1, w: '76px' }, { t: '打开过', w: '70px' }],
      d.industries.rows.map(r => `<tr ${gapAttr(r.st)}>
        <td class="nm">${dot(r.st)}${r.n}</td><td class="dim">${r.f}</td>
        <td class="num dim">—</td><td class="num dim">—</td><td class="num dim">—</td>
        <td class="dim">—</td></tr>`))
    + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${tag('推断', 'infer')} ${d.industries.infer}</p>`);

  out += block('m-supply', '达人供给结构 · 五个名单', '名单容量，非业绩', d.supply.note,
    cells(d.supply.pool, 'grid--▇▇')
    + `<div style="height:16px"></div>`
    + table([{ t: '名单' }, { t: '在册', num: 1, w: '56px' }, { t: '对照', w: '110px' }, { t: '结构判断' }],
      d.supply.rows.map(r => `<tr ${gapAttr(r.st)}>
        <td class="nm">${dot(r.st)}${r.n}</td><td class="num">${r.c}</td>
        <td class="pth">${r.cap}</td><td>${r.d}</td></tr>`))
    + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${d.supply.verdict}</p>`);

  out += block('m-rhythm', '七个周期节奏 · 跑没跑', '场景路由 + 实测', d.rhythm.note,
    table([{ t: '周期', w: '52px' }, { t: '动作' }, { t: '时长', w: '46px' }, { t: '走什么' }, { t: '产出落哪' }, { t: '现状' }],
      d.rhythm.rows.map(r => `<tr ${gapAttr(r.st)}>
        <td>${tag(r.cyc, r.cyc === '每日' ? 'signal' : '')}</td>
        <td class="nm">${dot(r.st)}${r.n}</td><td class="num dim">${r.min}</td>
        <td class="dim" style="font-size:12px">${r.route}</td>
        <td class="pth" style="white-space:normal">${r.land}</td>
        <td style="font-size:12.5px">${r.real}</td></tr>`))
    + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${d.rhythm.insight}</p>`);

  out += TOOLS.baseBlocks();
  /* 用户大纲里「知识库资产」是业务基本盘的第四小项，不是能力项 —— 2026-09-12 从 ▇▇ 迁入 */
  out += TOOLS.secAssets();
  return out;
}

/* ── ▇▇ 能力进阶 ──────────────────────── */
function secCap(d) {
  let out = '';

  out += block('m-skills', 'Aime 技能池 ▇▇个 · 治理', '按业务贴合度分组', d.skills.note,
    table([{ t: '分组', w: '150px' }, { t: '数', num: 1, w: '40px' }, { t: '技能' }, { t: '判断', w: '280px' }],
      d.skills.groups.map(g => `<tr ${gapAttr(g.st)}>
        <td class="nm">${dot(g.st)}${g.n}</td><td class="num">${g.c}</td>
        <td class="pth" style="white-space:normal;font-size:11px">${g.items}</td>
        <td style="font-size:12.5px">${g.d}</td></tr>`))
    + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${d.skills.verdict}</p>`);

  const p = d.plugins;
  out += block('m-plugins', 'Obsidian 插件实况', '读 .obsidian/ 真实配置', p.note,
    `<div class="grid grid--▇▇">
      <div class="cell" data-gap="▇▇">
        <div class="cell__k"><span>已装社区插件</span>${dot('off')}</div>
        <div class="cell__v">▇▇<small>个</small></div>
        <div class="cell__d">${p.installed.map(i => `<span class="pth">${i.n}</span> — ${i.d}`).join('<br>')}
        <br><br><b>两个都跟这套系统无关。</b></div>
      </div>
      <div class="cell">
        <div class="cell__k"><span>已开核心插件</span>${dot('run')}</div>
        <div class="cell__d" style="margin-top:▇▇">${p.coreOn}</div>
        <div class="cell__d" style="margin-top:10px;border-top:1px solid var(--rule);padding-top:10px">${p.bases}</div>
      </div>
    </div>
    <div style="height:16px"></div>`
    + table([{ t: '没开但该开的核心插件', w: '160px' }, { t: '为什么' }],
      p.coreOff.map(c => `<tr ${gapAttr(c.st)}><td class="nm">${dot(c.st)}<span class="pth">${c.n}</span></td><td>${c.why}</td></tr>`))
    + `<div style="height:16px"></div>`
    + table([{ t: '值得考虑的社区插件', w: '160px' }, { t: '优先', w: '54px' }, { t: '理由' }],
      p.community.map(c => `<tr><td class="nm pth">${c.n}</td>
        <td>${tag(c.pri, c.pri === '高' ? 'signal' : '')}</td><td>${c.why}</td></tr>`))
    + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${p.warn}</p>`);

  out += block('m-commands', '「常用指令模板」', '可直接改，改完复制', d.commands.note,
    `<div class="cmds">${d.commands.items.map((c, i) => `<div class="cmd">
      <div class="cmd__h"><div class="cmd__t"><span class="star">${'★'.repeat(c.star)}</span>${esc(c.t)}</div>
      <button class="btn btn--solid" data-copy="${i}">复制</button></div>
      <div class="cmd__b" id="cmd${i}">${esc(c.body)}</div></div>`).join('')}</div>`);

  const h = d.growth.health;
  out += block('m-growth', '自生长三道闸 + 规则库健康度', 'Q-023 已裁决 · 即日生效', d.growth.note,
    `<div class="grid grid--▇▇">${d.growth.gates.map(g => `<div class="cell">
      <div class="cell__k"><span>${g.n}</span>${tag(d.growth.live ? '生效中' : '候选', d.growth.live ? 'run' : 'infer')}</div>
      <div class="cell__d" style="margin-top:▇▇;font-size:13px;color:var(--ink)"><b>${g.rule}</b></div>
      <div class="cell__d">${g.why}</div></div>`).join('')}</div>
    <div style="height:20px"></div>`
    + cells([
      { k: '规则总数', v: h.total, u: '条', d: '已验证 ' + h.verified + ' · 待验证 ' + h.pending + ' · 已修正 ' + h.fixed },
      { k: '反面教材', v: h.counter, u: '条', d: '周报侧 ▇▇ + 达人侧 ▇▇' },
      { k: '我的推断被否决', v: h.denied, u: '条', d: '这是系统真正在学的证据' },
      { k: '空缺规则类', v: 1, u: '类', d: '只剩拜访策略（增减投归因本轮已填实）', st: 'gap' }
    ], 'grid--▇▇')
    + `<div style="height:16px"></div>`
    + table([{ t: '规则分类', w: '190px' }, { t: '条数', num: 1, w: '56px' }, { t: '' }],
      h.cats.map(c => `<tr ${gapAttr(c.st)}><td class="nm">${dot(c.st)}${c.n}</td>
        <td class="num">${c.c}</td><td class="dim">${c.c === 0 ? '⛔ 空' : ''}</td></tr>`))
    + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${h.note}</p>`);

  return out;
}

/* ── ▇▇ 协作机制 ──────────────────────── */
function secMech(d) {
  let out = '';

  out += block('m-loop', '五段闭环 · 采 → 存 → 判 → 确 → 长', '', d.loop.note,
    `<div class="loop">${d.loop.segs.map(s => `<div class="loop__seg" data-weak="${s.weak}" ${gapAttr(s.weak ? 'gap' : 'run')}>
      <div class="loop__c">${s.c}</div><div class="loop__n">${s.n}</div>
      <div class="loop__d">${s.d}</div></div>`).join('')}</div>`);

  out += block('m-routing', '调用思考 · 我收到请求后的决策链', '红格 = 硬停', d.routing.note,
    `<div class="chain">${d.routing.steps.map((s, i) => `<div class="chain__step" data-stop="${s.stop || 0}">
      <div class="chain__n">${String(i + 1).padStart(2, '0')}</div>
      <div><div class="chain__t">${s.t}</div><div class="chain__d">${s.d}</div></div></div>`).join('')}</div>`);

  out += block('m-optimize', '机制层的四个真问题', '', d.optimize.note,
    table([{ t: '问题', w: '190px' }, { t: '现象' }, { t: '建议动作' }],
      d.optimize.rows.map(r => `<tr data-gap="▇▇"><td class="nm">${dot('gap')}${r.p}</td>
        <td>${r.d}</td><td>${r.fix}</td></tr>`)));

  out += TOOLS.actBlock();
  return out;
}

/* ── ▇▇ 裁决落地与待办 ────────────────── */
const VST = {
  done: { t: '已落地', k: 'run' },
  act:  { t: '待我动手', k: 'open' },
  hold: { t: '仍卡住', k: 'signal' }
};

function secConfirm(d) {
  let out = '';

  /* ① 2026-09-12 裁决落地台账 —— 只读，不是待办清单 */
  const g = d.gates.items;
  const n = k => g.filter(x => x.st === k).length;
  out += block('m-gates', `2026-09-12 裁决落地台账 · ${g.length} 条`, '你裁了什么 / 我改了什么 / 还剩什么', d.gates.note,
    cells([
      { k: '已落地', v: n('done'), u: '条', st: 'run',  d: '口径、规则、机制已改完，无需你再动作' },
      { k: '待我动手', v: n('act'), u: '条', st: 'open', d: '方向已定，剩下是执行——已进行动队列' },
      { k: '仍卡住', v: n('hold'), u: '条', st: 'gap',  d: 'Q-020 入料口（→ 已由 Q-029 承接）· Q-004 考核结构，都在等你' },
      { k: '被推翻的旧判断', v: 3, u: '条', st: 'gap',  d: '结构上限 ▇▇ · 技能池清理 · 先开拜访纪要' }
    ], 'grid--▇▇')
    + `<div style="height:20px"></div>`
    + peek(`<div class="lgz">${g.map(x => {
        const s = VST[x.st] || VST.act;
        return `<div class="lgz__r lgz__r--${x.st}" id="gate-${x.id}" ${gapAttr(x.st === 'hold' ? 'gap' : 'run')}>
        <div class="lgz__top">
          <span class="lgz__id">${x.id}</span>
          <span class="lgz__q">${x.q}</span>
          <span class="lgz__st">${tag(s.t, s.k === 'run' ? 'run' : (s.k === 'open' ? 'open' : 'signal'))}</span>
        </div>
        <div class="lgz__pick">→ ${x.pick}</div>
        <div class="lgz__d">
          <div class="lgz__dr"><i>我据此改了</i><span>${x.did}</span></div>
          <div class="lgz__dr"><i>带来什么</i><span>${x.eff}</span></div>
          ${x.left ? `<div class="lgz__dr lgz__dr--left"><i>还剩什么</i><span>${x.left}</span></div>` : ''}
          <div class="lgz__dr"><i>落在哪</i><span class="pth">${x.land}</span></div>
        </div>
      </div>`;
      }).join('')}</div>
      <p class="block__note" style="margin-top:18px;margin-bottom:▇▇">${d.gates.foot}</p>`,
      '逐条看这 ▇▇条裁决', g.length));

  /* ② 下一批待裁决 —— 这里才是可点的闸门 */
  out += block('m-pending', `下一批待你定 · ${d.pending.items.length} 条`, '点一下就提交，我这边直接收到', d.pending.note,
    d.pending.items.map(x => `<div class="gate${x.hot ? ' gate--hot' : ''}" id="gate-${x.id}" data-gate="${x.id}" data-gap="▇▇">
      <div class="gate__h">
        <div class="gate__id">${x.id}</div>
        <div>
          <div class="gate__q">${x.q}</div>
          <div class="gate__w">${x.w}</div>
          <div class="gate__opts">${x.opts.map(o => `<button class="opt" data-opt="${esc(o)}">${o}</button>`).join('')}</div>
          <textarea class="gate__note" placeholder="补充说明（可留空）——这一栏比选项更有用"></textarea>
        </div>
        <div>${x.hot ? tag('优先', 'signal') : ''}</div>
      </div></div>`).join('')
    + `<div style="margin-top:24px;display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn--solid" id="exportBtn" style="font-size:11.5px;padding:8px 16px">看我提交过什么</button>
        <button class="btn" id="clearBtn" style="font-size:11.5px;padding:8px 16px">清空我的选择</button>
      </div>`);

  out += block('m-feedback', '这一页本身要你反馈', '我拿不准的三件事', d.feedback.note,
    d.feedback.rows.map((r, i) => fold(r.q, '', `<p>${r.d}</p>`, i === 0)).join(''));

  return out;
}

/* ═══════════════════════════════════════════════════════════
   装配
   ═══════════════════════════════════════════════════════════ */
const BUILDERS = {
  /* 一 · 驾驶舱总览 */
  deck:    secDeck,
  evo:     d => TOOLS.blkEvo(d),
  advice:  d => GRILL.render() + TOOLS.blkAdvice(d),
  spark:   d => TOOLS.blkInbox(d),
  /* 二 · 认知与学习（v8 新增，来自 mind.js）*/
  pattern: d => MIND.secPattern(d),
  memory:  d => MIND.secMemory(d),
  premise: d => MIND.secPremise(d),
  /* 三 · 工作台高阶交互系统 */
  state:   secState,
  cap:     secCap,
  mech:    secMech,
  confirm: secConfirm,
  /* 四 · 业务工作区（业绩数字只允许出现在这里）*/
  eco:     secEco,
  base:    secBase
};

const K = { gates: 'cec.gates', edits: 'cec.edits', annots: 'cec.annots', edit: 'cec.editmode', filter: 'cec.filter', dens: 'cec.dens', folds: 'cec.folds' };
const ORIG = {};                 // data-ek → 原始纯文本
let EDITS  = {};                 // data-ek → { mod, ctx, before, after }
let ANNOTS = {};                 // modId  → 批注文本

/* ── 去内部代码（2026-09-13 本人指令） ──────────────────
   她的原话：「你后面每个总结跟动作要结合我的框架目标跟逻辑给到具体的信息
   跟需要我理解的动作，而不是一堆只有你能看懂的类似这种的代码（R-304/R-305）」

   R-xxx 是我规则库里的编号、E-xx 是我常错清单的编号 —— 对她零信息量。
   所以在页面渲染完之后统一扫一遍文本节点，把这些编号翻成人话或直接抹掉。
   ⚠️ 只动文本节点，不动标签和属性；Q-xxx 保留（那是她自己在用的题号）。 */
function noJargonText(s) {
  if (!/[RE]-\d/.test(s)) return s;
  /* R-413~▇▇ → ▇▇条规则 */
  s = s.replace(/R-(\d+)\s*~\s*R?-?(\d+)/g, (m, a, b) => {
    const n = Number(b) - Number(a) + 1;
    return n > 1 ? n + ' 条规则' : '一条规则';
  });
  s = s.replace(/常错清单\s*E-\d+/g, '我的常错清单');
  s = s.replace(/[（(]\s*E-\d+\s*[)）]/g, '');
  s = s.replace(/\bE-\d+/g, '');
  /* （已立 R-305）→（已立成规则）；（R-533 / R-534）→ 整块删掉 */
  s = s.replace(/[（(]\s*(已立|已记|已写成|见|参见|按)?\s*R-\d+(?:\s*[\/、,，]\s*(?:R-\d+|我的常错清单))*\s*[)）]/g,
    (m, p) => (p ? '（已立成规则）' : ''));
  s = s.replace(/(按|走|据|依|见|参|照)\s*R-\d+(?:\s*[\/、]\s*R-\d+)*/g, '$▇▇既有规则');
  s = s.replace(/(已立|已写成|立)\s*R-\d+(?:\s*[\/、]\s*R-\d+)*/g, '已立成规则');
  s = s.replace(/最新\s*R-\d+/g, '');
  s = s.replace(/(新增|修正)\s*R-\d+(?:\s*[\/、]\s*R-\d+)*/g, '$▇▇规则');
  s = s.replace(/长出\s*R-\d+(?:\s*[\/、]\s*R-\d+)*/g, '长出新规则');
  /* 兜底：R-538 这类紧跟中文说明的，直接去掉编号留说明 */
  s = s.replace(/R-\d+\s*(?=[\u4e00-\u9fa5])/g, '');
  s = s.replace(/R-\d+(?:\s*[\/、]\s*R-\d+)*/g, '既有规则');
  /* 清残：空括号、连着的分隔符、多余空格 */
  s = s.replace(/[（(]\s*[)）]/g, '')
       .replace(/·\s*·/g, '·')
       .replace(/^\s*[·，、]\s*/, '')
       .replace(/[ \u3000]{2,}/g, ' ');
  return s;
}

function noJargon(root) {
  const host = root || document.body;
  const w = document.createTreeWalker(host, NodeFilter.SHOW_TEXT, null);
  const hit = [];
  let n;
  while ((n = w.nextNode())) {
    if (!n.nodeValue || !/[RE]-\d/.test(n.nodeValue)) continue;
    const p = n.parentNode;
    if (p && /^(SCRIPT|STYLE|TEXTAREA)$/.test(p.tagName)) continue;
    hit.push(n);
  }
  hit.forEach(t => { t.nodeValue = noJargonText(t.nodeValue); });
  return hit.length;
}

function mount() {
  // 单一事实源：顶部速览的两个数直接从底层对象推导，
  // 防止「表里 ▇▇、图里 ▇▇」这种同一页两个数的低级冲突
  DATA.meta.facts.forEach(f => {
    if (f.k === '仍待裁决') f.v = String(DATA.queue.open);
    if (f.k === '本轮裁决') f.v = String(DATA.verdictBatch.n);
    if (f.k === '判断规则') f.v = String(DATA.growth.health.total);
    if (f.k === '空目录')   f.v = String(DATA.dirs.rows.filter(r => r.c === 0).length);
  });

  renderSections();
  OS.boot();               // 侧栏 / Hero / 指令栏 / 视图路由

  const hot = (DATA.pending.items || []).filter(i => i.hot);
  const b0 = hot[0];
  const mb = $('#mastBlock');
  if (mb) mb.innerHTML = b0 ? `
    <div class="blocker__k">最该先定的一件</div>
    <div class="blocker__id">${b0.id}</div>
    <div class="blocker__q">${b0.q}</div>
    <div class="blocker__m">这件不定，<b>Q3 的追踪和汇报要做两套</b>——两个口径的数都得跟。</div>
    <button class="blocker__go" data-jumpv="confirm">去定这件 →</button>
    <div class="blocker__f">另外还有 <b>${DATA.queue.open - 1}</b> 件等你定，其中 ${hot.length - 1} 件同样卡着别的事</div>` : '';
  const fs = $('#footStamp');
  if (fs) fs.textContent = DATA.meta.stamp + ' · ' + DATA.meta.scanNote;


  // 含闸门的模块与章节打标，供「只看待决策」用
  $$('.gate').forEach(g => {
    g.closest('.block')?.setAttribute('data-has-gate', '1');
    g.closest('.sec')?.setAttribute('data-has-gate', '1');
  });

  keyEditables();
  buildPalette();
  wire();
  TOOLS.wire();
  BIZ.wire();
  MIND.wire();
  PLAIN.wire();
  FB.wire();
  try { NEBULA.wire(); } catch (e) {}
  restore();
  refresh();
  /* 系统自指图表（倒金字塔 / 规则库饼图 / 周期节奏 / 目录填充 / 名单容量）已按
     2026-09-13 指令整体下线：它们说明的是我这套系统自己的状态，对她理解模块没有帮助。
     charts.js 仍在，但页面上没有挂载点，所以这里必须容错。 */
  try { CEC_CHARTS.boot(); } catch (e) {}
  try { MIND.chart(); } catch (e) {}
  OS.badges();
  /* 页面上一律不出现我内部的规则编号 / 常错清单编号 */
  noJargon();
  try {
    const mo = new MutationObserver(ms => {
      let need = 0;
      ms.forEach(m => { if (m.addedNodes && m.addedNodes.length) need = 1; });
      if (!need) return;
      clearTimeout(mo._t);
      mo._t = setTimeout(() => noJargon(), 80);
    });
    mo.observe(document.body, { childList: true, subtree: true });
  } catch (e) {}
  /* 渲染过程中内容高度反复变化，浏览器会做 scroll anchoring 把视口往下顶，
     全部装配完之后强制回顶，否则一进来看到的是半截驾驶舱 */
  window.scrollTo(0, 0);
  setTimeout(() => window.scrollTo(0, 0), 120);
}

function renderSections() {
  /* v11（2026-09-13 本人指令）：每页只有模块卡四块 + 真内容区。
     过程说明、版本变更、系统自指图表已全部下线，不再渲染 BUILDERS。 */
  $('#sections').innerHTML = SECS.map(s => `<section class="sec" id="${s.id}">
    <div class="sec__head">
      <div class="sec__n">${s.n}</div>
      <div class="sec__t"><h2>${s.t}</h2></div>
    </div>
    ${MOD.render(s.id)}
  </section>`).join('');
}

/* ── 给可编辑元素编号 ─────────────────── */
const EDITABLE = 'td, .cell__v, .cell__d, .block__note, .bar__note, .loop__d, .chain__t, .chain__d, .cmd__b, .kstrip__v, .kstrip__d, .dcard__f, .fseg__d';

function ctxOf(el) {
  if (el.tagName === 'TD') {
    const tr = el.closest('tr'), tbl = el.closest('table');
    const idx = [...tr.children].indexOf(el);
    const head = tbl?.querySelector('thead tr')?.children[idx]?.textContent.trim() || '第' + (idx + 1) + '列';
    const first = tr.children[0]?.textContent.trim() || '';
    return `${cut(first, 18)} › ${cut(head, 12)}`;
  }
  const near = (sel) => el.closest('.cell, .barrow, .loop__seg, .chain__step, .cmd, .dcard, .kstrip__i, .fseg')?.querySelector(sel)?.textContent.trim();
  if (el.classList.contains('kstrip__v') || el.classList.contains('kstrip__d'))
    return '指标 · ' + cut(el.closest('.kstrip__i')?.querySelector('.kstrip__k')?.textContent || '', 10);
  if (el.classList.contains('dcard__f'))
    return '图注 · ' + cut(el.closest('.dcard')?.querySelector('.dcard__t')?.textContent || '', 16);
  if (el.classList.contains('fseg__d'))
    return '闭环 · ' + cut(el.closest('.fseg')?.querySelector('.fseg__n')?.textContent || '', 10);
  if (el.classList.contains('block__note')) return '模块说明';
  if (el.classList.contains('cell__v') || el.classList.contains('cell__d')) return cut(near('.cell__k') || '数据格', 18);
  if (el.classList.contains('bar__note')) return cut(near('.bar__l') || '目录', 18);
  if (el.classList.contains('loop__d')) return cut(near('.loop__n') || '闭环段', 18);
  if (el.classList.contains('chain__t') || el.classList.contains('chain__d')) return cut(near('.chain__t') || '决策步', 18);
  if (el.classList.contains('cmd__b')) return cut(near('.cmd__t') || '指令', 22);
  return '内容';
}

function keyEditables() {
  $$('[data-mod]').forEach(mod => {
    const id = mod.dataset.mod;
    let i = 0;
    $$(EDITABLE, mod).forEach(el => {
      if (el.closest('.gate') || el.closest('.annot') || el.closest('.modbar') || el.closest('.next')) return;
      if (!el.textContent.trim()) return;
      const k = `${id}:${i++}`;
      el.dataset.ek = k;
      el.dataset.emod = id;
      ORIG[k] = el.textContent.replace(/\s+/g, ' ').trim();
    });
  });
}

/* ── 交互 ─────────────────────────────── */
let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('is-on');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('is-on'), 1900);
}

function wire() {
  /* 批次横幅上的两个跳转（章节 id 或元素 id 都支持） */
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-go2]');
    if (!b) return;
    const id = b.dataset.go2;
    const el = (window.OS && OS.reveal) ? OS.reveal(id) : $('#' + id);
    if (!el) return;
    window.scrollTo({ top: Math.max(el.getBoundingClientRect().top + window.scrollY - 76, 0), behavior: 'smooth' });
    el.classList.remove('is-flash'); void el.offsetWidth; el.classList.add('is-flash');
  });

  /* 折叠 */
  document.addEventListener('click', e => {
    const b = e.target.closest('.fold__b');
    if (!b) return;
    const f = b.parentElement;
    f.classList.toggle('is-open');
    b.querySelector('.sign').textContent = f.classList.contains('is-open') ? '−' : '+';
  });

  /* 复制指令 */
  $$('[data-copy]').forEach(b => b.addEventListener('click', () => {
    const txt = $('#cmd' + b.dataset.copy).textContent;
    navigator.clipboard?.writeText(txt).then(
      () => { b.textContent = '已复制'; toast('指令已复制，直接发我'); setTimeout(() => b.textContent = '复制', 1600); },
      () => toast('复制失败，请手动选中')
    );
  }));

  /* 闸门 */
  $$('.gate').forEach(g => {
    g.querySelectorAll('.opt').forEach(o => o.addEventListener('click', () => {
      const on = o.classList.contains('is-on');
      g.querySelectorAll('.opt').forEach(x => x.classList.remove('is-on'));
      if (!on) o.classList.add('is-on');
      saveGates(); refresh();
    }));
    g.querySelector('.gate__note').addEventListener('input', () => { saveGates(); refresh(); });
  });

  /* 页内编辑 */
  document.addEventListener('input', e => {
    const el = e.target.closest?.('[data-ek]');
    if (!el || !document.body.classList.contains('edit-on')) return;
    const k = el.dataset.ek;
    const now = el.textContent.replace(/\s+/g, ' ').trim();
    if (now === ORIG[k]) { delete EDITS[k]; el.classList.remove('is-edited'); }
    else { EDITS[k] = { mod: el.dataset.emod, ctx: ctxOf(el), before: ORIG[k], after: now }; el.classList.add('is-edited'); }
    saveEdits(); refresh();
  });

  /* 批注 */
  $$('[data-annot]').forEach(b => b.addEventListener('click', () => {
    const box = $(`[data-annot-box="${b.dataset.annot}"]`);
    box.classList.toggle('is-open');
    b.classList.toggle('is-on', box.classList.contains('is-open'));
    if (box.classList.contains('is-open')) box.querySelector('textarea').focus();
  }));
  $$('[data-annot-box]').forEach(box => box.querySelector('textarea').addEventListener('input', e => {
    const id = box.dataset.annotBox;
    const v = e.target.value.trim();
    if (v) ANNOTS[id] = v; else delete ANNOTS[id];
    localStorage.setItem(K.annots, JSON.stringify(ANNOTS));
    refresh();
  }));

  /* 编辑模式 */
  $('#editToggle').addEventListener('click', () => setEdit(!document.body.classList.contains('edit-on')));

  /* 视图筛选 */
  $$('#filters button').forEach(b => b.addEventListener('click', () => setFilter(b.dataset.f)));
  $('#filterExit').addEventListener('click', () => setFilter('all'));

  /* 密度开关 —— 精简 / 完整 */
  $$('#dens button').forEach(b => b.addEventListener('click', () => setDens(b.dataset.d)));

  /* 紧凑台账：整行可点，展开这一条的落地明细 */
  document.addEventListener('click', e => {
    const top = e.target.closest('.lgz__top, .lgz__pick');
    if (!top) return;
    top.closest('.lgz__r').classList.toggle('is-on');
  });

  /* 折叠：单块展开状态存本地，精简模式下手动展开的块下次还记得 */
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-pkt]');
    if (!t) return;
    const box = t.closest('.pk');
    const on = box.classList.toggle('is-open');
    const key = foldKey(box);
    if (on) FOLDS[key] = 1; else delete FOLDS[key];
    localStorage.setItem(K.folds, JSON.stringify(FOLDS));
    if (on) setTimeout(() => window.CEC_CHARTS && CEC_CHARTS.resizeAll && CEC_CHARTS.resizeAll(), 260);
  });

  /* 补丁抽屉 */
  $('#patchBtn').addEventListener('click', openDrawer);
  $('#exportBtn')?.addEventListener('click', openDrawer);
  $('#drawerX').addEventListener('click', () => $('#drawer').classList.remove('is-open'));
  $('#patchCopy').addEventListener('click', () => {
    navigator.clipboard?.writeText($('#patchText').textContent).then(
      () => toast('已复制'), () => toast('复制失败，请手动选中'));
  });
  $('#patchDl').addEventListener('click', () => {
    const blob = new Blob([$('#patchText').textContent], { type: 'text/markdown;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `控制台补丁-${DATA.meta.stamp}.md`;
    a.click(); URL.revokeObjectURL(a.href);
    toast('已下载备用文件');
  });
  $('#patchReset').addEventListener('click', resetAll);
  $('#clearBtn')?.addEventListener('click', () => {
    localStorage.removeItem(K.gates);
    $$('.gate').forEach(g => {
      g.querySelectorAll('.opt').forEach(x => x.classList.remove('is-on'));
      g.querySelector('.gate__note').value = '';
    });
    refresh(); toast('闸门选择已清空');
  });

  /* 聚焦 */
  $$('[data-focus]').forEach(b => b.addEventListener('click', e => {
    e.preventDefault(); e.stopPropagation();
    const id = b.dataset.focus, sec = $('#' + id);
    const on = sec.classList.contains('is-focus');
    $$('.sec').forEach(s => s.classList.remove('is-focus'));
    document.body.classList.toggle('focus-on', !on);
    if (!on) { sec.classList.add('is-focus'); window.scrollTo({ top: 0 }); toast('聚焦 ' + id + ' —— 再点 ◎ 或按 Esc 退出'); }
    if (window.CEC_CHARTS) CEC_CHARTS.retheme();
  }));

  $('#expandAll')?.addEventListener('click', () => {
    setDens('full');
    toast('已切到完整模式 —— 所有证据摊开');
  });

  /* Tweaks */
  $('#tweaksToggle').addEventListener('click', () => $('#tweaks').classList.toggle('is-open'));
  $$('.seg').forEach(seg => seg.querySelectorAll('button').forEach(b => b.addEventListener('click', () => {
    seg.querySelectorAll('button').forEach(x => x.classList.remove('is-on'));
    b.classList.add('is-on');
    applyTweak(seg.dataset.tweak, b.dataset.v);
  })));

  /* 导航：v8 起由 os.js 的视图路由接管（侧栏点击 / 数字键 / hash） */

  /* 命令面板 + 快捷键 */
  $('#palBtn').addEventListener('click', openPal);
  $('#palIn').addEventListener('input', filterPal);
  $('#pal').addEventListener('click', e => { if (e.target.id === 'pal') closePal(); });
  /* 命令面板「搜不到 → 反馈补索引」路径（她 2026-10-08：搜索问题统一汇入右上角反馈）
     ① 点击后直接进入右上角「我的反馈」，不再要求跳到另一个输入框二次提交
     ② 所有搜索问题共用一个 topic：同批再次反馈会覆盖为最新内容，不额外占满 ▇▇个槽位 */
  const fbHandler = () => {
    const q = ($('#palIn')?.value || '').trim();
    const text = q
      ? `搜索词：${q}\n问题：没有找到想要的结果，或结果不准确。\n期望：补充命令面板索引 / alias 别名，并同步更新口径词典与反馈处理台账。`
      : '导航栏搜索框存在问题：没有搜到想要的内容，或结果不准确。请补充命令面板索引 / alias 别名，并同步更新口径词典与反馈处理台账。';
    closePal();

    if (window.FB && typeof FB.submit === 'function') {
      const queued = FB.submit({
        kind: 'search',
        view: '导航搜索',
        topic: 'search-box-feedback',
        topicName: '搜索框问题',
        text
      });
      /* 无论新增成功还是本批已满，都打开抽屉，让她立即看到当前状态并统一交办。 */
      if (typeof FB.open === 'function') FB.open();
      if (queued) FB.toast(`已放入右上角「我的反馈」· 本批 ${FB.list().length}/${FB.MAX}，确认后统一交办给 Aime`);
      return;
    }

    /* 极端兜底：反馈模块没加载时才回填到工作台输入框，避免内容丢失。 */
    const cmd = $('#cmdIn');
    if (cmd) { cmd.value = text; cmd.focus(); }
  };
  $('#palFbBtn')?.addEventListener('click', fbHandler);
  $('#palFbLink')?.addEventListener('click', fbHandler);
  document.addEventListener('keydown', onKey);
}

/* ── 快捷键 ───────────────────────────── */
function onKey(e) {
  const typing = /^(INPUT|TEXTAREA)$/.test(e.target.tagName) || e.target.isContentEditable;
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openPal(); return; }
  if (e.key === 'Escape') {
    if ($('#pal').classList.contains('is-open')) return closePal();
    if ($('#drawer').classList.contains('is-open')) return $('#drawer').classList.remove('is-open');
    if (document.body.classList.contains('focus-on')) {
      document.body.classList.remove('focus-on'); $$('.sec').forEach(s => s.classList.remove('is-focus'));
      if (window.CEC_CHARTS) CEC_CHARTS.retheme(); return;
    }
    if (document.body.classList.contains('edit-on')) return setEdit(false);
  }
  if ($('#pal').classList.contains('is-open')) {
    if (!/^(ArrowDown|ArrowUp|Enter)$/.test(e.key)) return;
    const vis = $$('.pal__i:not([hidden])');
    if (!vis.length) return;
    let i = vis.findIndex(x => x.classList.contains('is-sel'));
    if (e.key === 'Enter') { e.preventDefault(); vis[Math.max(i, 0)].click(); return; }
    e.preventDefault();
    i = e.key === 'ArrowDown' ? Math.min(i + 1, vis.length - 1) : Math.max(i - 1, 0);
    vis.forEach(x => x.classList.remove('is-sel'));
    const sel = vis[i]; sel.classList.add('is-sel');
    const box = $('#palList');
    const top = sel.offsetTop, bot = top + sel.offsetHeight;
    if (top < box.scrollTop) box.scrollTop = top;
    else if (bot > box.scrollTop + box.clientHeight) box.scrollTop = bot - box.clientHeight;
    return;
  }
  if (typing) return;
  if (e.key === 'e') { setEdit(!document.body.classList.contains('edit-on')); }
  if (e.key === 'g') { setFilter(document.body.classList.contains('f-gap') ? 'all' : 'gap'); }
}

/* ── 编辑模式 / 筛选 ──────────────────── */
/* plaintext-only 能挡住粘贴富文本，Firefox 不支持则回退 true + 纯文本粘贴 */
const CE_MODE = (() => {
  const d = document.createElement('div');
  d.setAttribute('contenteditable', 'plaintext-only');
  return d.contentEditable === 'plaintext-only' ? 'plaintext-only' : 'true';
})();
if (CE_MODE === 'true') {
  document.addEventListener('paste', e => {
    const el = e.target.closest?.('[data-ek]');
    if (!el || !document.body.classList.contains('edit-on')) return;
    e.preventDefault();
    document.execCommand('insertText', false, (e.clipboardData || window.clipboardData).getData('text'));
  });
}

function setEdit(on) {
  document.body.classList.toggle('edit-on', on);
  $('#editToggle').classList.toggle('is-on', on);
  $('#editToggle').firstElementChild.textContent = on ? '编辑中' : '编辑模式';
  $$('[data-ek]').forEach(el => {
    if (on) el.setAttribute('contenteditable', CE_MODE);
    else el.removeAttribute('contenteditable');
  });
  localStorage.setItem(K.edit, on ? '1' : '0');
  if (on) toast('编辑模式：任意数字或文字点开就能改，改完记得提交');
}

/* ── 密度与折叠 ────────────────────────── */
let FOLDS = {};
/* 折叠块的身份用「所属模块 + 在块内的序号」标识，
   不用自增 id —— 那个每次渲染都会变，存了也认不出来 */
function foldKey(box) {
  const mod = box.closest('[data-mod]');
  const m = mod ? mod.dataset.mod : 'x';
  const sibs = mod ? [...mod.querySelectorAll('.pk')] : [box];
  return m + ':' + sibs.indexOf(box);
}

function setDens(d) {
  document.body.classList.toggle('dens-full', d === 'full');
  $$('#dens button').forEach(b => b.classList.toggle('is-on', b.dataset.d === d));
  localStorage.setItem(K.dens, d);
  /* 完整模式把所有折叠打开；精简模式回到「只开你手动开过的」 */
  $$('.pk').forEach(box => {
    box.classList.toggle('is-open', d === 'full' ? true : !!FOLDS[foldKey(box)]);
  });
  /* 历史问答折叠（.fold/.sign）跟着密度走，但不记忆——它本来就是随手翻的 */
  $$('.fold').forEach(f => {
    const on = d === 'full';
    f.classList.toggle('is-open', on);
    const sg = f.querySelector('.sign'); if (sg) sg.textContent = on ? '−' : '+';
  });
  setTimeout(() => window.CEC_CHARTS && CEC_CHARTS.resizeAll && CEC_CHARTS.resizeAll(), 300);
}

function setFilter(f) {
  document.body.classList.remove('f-gap', 'f-decide', 'f-run');
  $$('#filters button').forEach(b => b.classList.toggle('is-on', b.dataset.f === f));
  $$('.is-filtered').forEach(x => x.classList.remove('is-filtered'));
  localStorage.setItem(K.filter, f);
  if (f === 'all') return;
  document.body.classList.add('f-' + f);

  const want = f === 'run' ? '0' : '1';
  if (f !== 'decide') {
    $$('.tbl').forEach(t => {
      if (!t.querySelector(`tbody tr[data-gap="${want}"]`)) t.classList.add('is-filtered');
    });
    $$('.grid').forEach(g => {
      if (!g.querySelector(`[data-gap="${want}"]`)) g.classList.add('is-filtered');
    });
    $$('.block').forEach(b => {
      // .lgz 里的台账行自己按 data-gap 逐条隐藏，只要还剩一条就不能把整块判死
      const alive = $$('.tbl:not(.is-filtered), .grid:not(.is-filtered), .loop, .bars, .gate, .lgz', b)
        .some(x => x.offsetParent !== null || x.classList.contains('gate')
                || (x.classList.contains('lgz') && $$('.lgz__r', x).some(c => c.offsetParent !== null)));
      if (!alive) b.classList.add('is-filtered');
    });
    $$('.sec').forEach(s => {
      if (!$$('.block:not(.is-filtered)', s).length) s.classList.add('is-filtered');
    });
  }
  const label = { gap: '只看空缺 —— 已隐藏所有在跑的行', decide: '只看待决策 —— 只留重要事项确认里的闸门', run: '只看在跑 —— 已隐藏所有空缺' }[f];
  $('#filterLabel').textContent = label;   // 红条已经说清楚了，不再额外弹 toast 重复一遍
  // 筛选会把整张卡片 display:none，容器宽高归零 → 切回来必须重画，否则图是空白
  if (window.CEC_CHARTS) CEC_CHARTS.retheme();
}

/* v3.1 起默认是「糖果昼」白底；只有显式存了 dark 才走糖果夜。
   主题的存储键带版本号（theme3），这样以前存过 paper/night/dark 的浏览器
   也会落到新的白底默认值上，不会有人打开还是黑的。 */
function normTheme(v) { return v === 'dark' ? 'dark' : (v === 'light' ? 'light' : 'aurora'); }
const TWK = k => 'cec.tw.' + (k === 'theme' ? 'theme4' : k);

function applyTweak(k, v) {
  const b = document.body;
  if (k === 'theme') {
    /* 极光 = candy-light + aurora（画风层只叠在白底上，夜间不叠） */
    v = normTheme(v);
    b.classList.toggle('candy-light', v !== 'dark');
    b.classList.toggle('aurora', v === 'aurora');
  }
  if (k === 'layout') {
    /* 四栏工作台 = body.shell（左图标轨 + 浮起导航 + 工作区 + 右上下文栏）；
       单栏长页 = 去掉 .shell，回到原来那一版，随时能退 */
    b.classList.toggle('shell', v !== 'page');
    setTimeout(() => {
      if (window.SHELL) { SHELL.heroes(); SHELL.paintDock(); }
      if (window.CEC_CHARTS && CEC_CHARTS.resizeAll) CEC_CHARTS.resizeAll();
    }, 300);
  }
  if (k === 'density') b.classList.toggle('density-tight', v === 'tight');
  if (k === 'motion')  b.classList.toggle('motion-off', v === 'off');
  if (k === 'gap') {
    b.classList.toggle('gap-on', v === 'on');
    if (v === 'on') toast('只亮没做的：空目录 / 空规则类 / 断掉的链条');
  }
  localStorage.setItem(TWK(k), v);
  if (k !== 'gap' && window.CEC_CHARTS) CEC_CHARTS.retheme();
}

function go(id) {
  /* v8：目标可能在另一个视图里，先切过去再滚 */
  const el = (window.OS && OS.reveal) ? OS.reveal(id) : $('#' + id);
  if (!el) return;
  window.scrollTo({ top: Math.max(el.offsetTop - 60, 0), behavior: 'smooth' });
  el.classList.remove('is-flash');
  void el.offsetWidth;
  el.classList.add('is-flash');
}

/* ═══════════════════════════════════════════════════════════
   刷新层 · 顶栏计数 / 模块状态条 / 智能推荐
   全部由当前页面状态实时推导，不写死
   ═══════════════════════════════════════════════════════════ */

function gateState() {
  const picks = {};
  let done = 0;
  DATA.pending.items.forEach(g => {
    const el = $(`.gate[data-gate="${g.id}"]`);
    const pick = el?.querySelector('.opt.is-on')?.dataset.opt || '';
    const note = el?.querySelector('.gate__note')?.value.trim() || '';
    picks[g.id] = { pick, note };
    if (pick) done++;
  });
  return { picks, done, total: DATA.pending.items.length };
}

function refresh() {
  const g = gateState();
  const nEdit = Object.keys(EDITS).length;
  const nAnnot = Object.keys(ANNOTS).length;
  const nGap = $$('tr[data-gap="▇▇"], .barrow[data-gap="▇▇"], .cell[data-gap="▇▇"], .loop__seg[data-gap="▇▇"]').length;

  const T = TOOLS.count();
  const nAll = nEdit + nAnnot + g.done + T.all;

  $('#kpiGate').textContent = `${g.done}/${g.total}`;
  $('#kpiGate').parentElement.classList.toggle('kpi--hot', g.done < g.total);
  $('#kpiEdit').textContent = nEdit + nAnnot + T.all;
  $('#kpiGap').textContent = nGap;
  $('#patchBtn').disabled = false;
  $('#patchBtn').innerHTML = nAll > 0
    ? `补丁 <span class="tbtn__kbd">${nAll}</span>` : '补丁';

  // 模块状态条
  $$('[data-mod]').forEach(b => {
    const id = b.dataset.mod;
    const items = $$('tr[data-gap], .barrow[data-gap], .cell[data-gap], .loop__seg[data-gap]', b)
      .filter(x => !x.classList.contains('gate'));
    const bad = items.filter(x => x.dataset.gap === '1').length;
    const eds = Object.values(EDITS).filter(e => e.mod === id).length;
    const box = $(`[data-st-for="${id}"]`);
    if (!box) return;
    const gs = $$('.gate', b);
    if (gs.length) {
      const left = gs.filter(x => !x.querySelector('.opt.is-on')).length;
      box.innerHTML = `<span class="modbar__track"><span class="modbar__fill${left ? '' : '--clean'}"
        style="width:${gs.length ? Math.round(left / gs.length * 100) || 100 : 100}%"></span></span>
        ${left ? `还剩 ${left}/${gs.length} 条没裁决` : `${gs.length} 条已全部裁决`}`;
      return;
    }
    const pct = items.length ? Math.round(bad / items.length * 100) : 0;
    box.innerHTML = items.length
      ? `<span class="modbar__track"><span class="modbar__fill${bad ? '' : '--clean'}" style="width:${bad ? pct : 100}%"></span></span>
         ${bad ? `${bad}/${items.length} 处空缺` : `${items.length} 项全在跑`}${eds ? ` · 已改 ${eds}` : ''}`
      : `<span class="modbar__track"><span class="modbar__fill--clean" style="width:100%"></span></span>无待办项${eds ? ` · 已改 ${eds}` : ''}`;
    const c = $(`[data-annot-c="${id}"]`);
    if (c) c.textContent = ANNOTS[id] ? '●' : '';
  });

  renderNext(g, nEdit + nAnnot);
}

function renderNext(g, nChanged) {
  const P = g.picks;
  const C = [];

  /* 2026-09-12 两批 ▇▇条裁完之后，真正挡住动作的只剩三条（见 DATA.pending）。
     这三条全部是「你不说我就停」的类型，我不拿推断值代替。 */
  if (!P['Q-035']?.pick) C.push({ w: 2, a: '定 Q3 收口盯哪个数', to: 'gate-Q-035',
    d: 'MMM 直连重算之后：整个在途池 <b>▇▇万</b>，但预计结算日落在 9 月内的只有 <b>▇▇笔 / ▇▇万</b>。两个数差 ▇▇倍，<b>它不定，这半个月的动作强度和上报口径就是两套</b>。' });
  if (!P['Q-037']?.pick) C.push({ w: 2, a: '断一下技能池那两条打架的裁决', to: 'gate-Q-037',
    d: 'Q-024 裁「▇▇个都留着」，同一天 S-03 又标「采纳：砍 ▇▇个重叠的」。<b>方向相反，我按 R-518 全部挂起，一个都没删。</b>在你断之前技能池维持 ▇▇个原样。' });
  if (!P['Q-034']?.pick) C.push({ w: 1, a: '刊例补到什么程度停手', to: 'gate-Q-034',
    d: '你已经把性质改了（R-516：无刊例是机构没整理，不是达人短板）。<b>但补到哪停没定</b>——这决定 Q4 要不要投人力去机构那边要表。' });
  C.push({ w: 1, a: '给外部趋势管道三个参数', to: 'eco',
    d: 'Q-030 你已裁「建管道」，<b>但源 / 频率 / 落点三件没给我</b>。挑源等于替你定「什么算行业信号」，这一步我不自己做，所以「外部大盘」现在仍然是空的。' });
  C.push({ w: 1, a: '把 R-504~R-518 归好类', to: 'memory',
    d: '这 ▇▇条误挂在「规则健康度」小节下，导致按类统计只有 ▇▇条、全文却是 ▇▇条。<b>我已补标题止血，但逐条归类要你点头</b>——归错类比不归更难查。' });
  C.push({ w: 1, a: '开 audio-recorder，▇▇ 分钟', to: 'cap',
    d: '核心插件，零风险，不依赖任何未决裁决。回程路上口述 ▇▇ 分钟 → 音频落进笔记 → 我拆成纪要。<em>这是目前唯一一个不用等你拍板就能推进的动作。</em>' });
  C.push({ w: 0, a: '建六个 Base 视图（Q-021 已定）', to: 'state',
    d: '你已裁「做视图不搬文件」，bases 核心插件本来就开着。<b>六个视图 ≈ ▇▇ 分钟，文件一个都不动，删掉不留痕。</b>这条我可以直接给你视图配置。' });
  if (nChanged > 0) C.push({ w: 2, a: `把 ${nChanged} 处改动发我`, to: 'PATCH',
    d: '你已经在页面上改了东西。点右上角「我的反馈」确认一下都提交了，我按它改仓库。' });
  if (g.done && g.done < g.total) C.push({ w: 1, a: `再清 ${g.total - g.done} 条待裁决`, to: 'confirm',
    d: '已裁决 ' + g.done + ' 条。剩下的每一条都在挂起状态，我不会用推断值代替。' });
  if (g.done === g.total) C.push({ w: 2, a: '这一批全定完了', to: 'PATCH',
    d: '这一批清空了，我这边已经收到。下一批我整理好会再放上来。' });

  C.sort((a, b) => b.w - a.w);
  const top = C.slice(0, 3);
  const nextEl = $('#next');
  if (!nextEl) return;      // v11：#next 挂在旧驾驶舱页里，模块卡改造后可能不存在
  nextEl.innerHTML = `
    <div class="next__h">
      <span class="next__k">Next</span>
      <span class="next__t">下一步这三件事</span>
      <span class="next__s">按当前状态实时算 · 你一勾选就会变</span>
    </div>
    <div class="next__list">${top.map((c, i) => `<div class="next__i" data-w="${c.w}">
      <div class="next__n">${String(i + 1).padStart(2, '0')}</div>
      <div class="next__a">${c.a}</div>
      <div class="next__d">${c.d}</div>
      <button class="next__go" data-go="${c.to}">跳到这里 →</button>
    </div>`).join('')}</div>`;
  $$('#next [data-go]').forEach(b => b.addEventListener('click', () => {
    if (b.dataset.go === 'PATCH') return openDrawer();
    go(b.dataset.go);
  }));
}

/* ═══════════════════════════════════════════════════════════
   命令面板
   ═══════════════════════════════════════════════════════════ */
let PAL = [];
function buildPalette() {
  PAL = [];
  SECS.forEach(s => PAL.push({ kind: '章节', t: `${s.n} ${s.t}`, sub: '', to: s.id }));
  Object.keys(MODS).forEach(id => {
    const el = $(`[data-mod="${id}"]`);
    PAL.push({ kind: '模块', t: MODS[id].t, sub: el?.closest('.sec')?.id || '', to: id, isMod: 1 });
  });
  DATA.pending.items.forEach(gt => PAL.push({ kind: '待裁决', t: `${gt.id} ${gt.q}`, sub: gt.hot ? '优先' : '', to: 'gate-' + gt.id }));
  DATA.commands.items.forEach((c, i) => PAL.push({ kind: '指令', t: c.t, sub: '★'.repeat(c.star), to: 'cmd' + i, isCmd: i }));
  DATA2.advice.items.forEach(a => PAL.push({ kind: '建议', t: `${a.id} ${a.t}`, sub: a.pri + '优先', to: 'm-advice', isMod: 1 }));
  DATA2.tpl.items.forEach(t => PAL.push({ kind: '模版', t: `${t.id} ${t.n}`, sub: t.freq, to: 'm-tpl', isMod: 1 }));
  DATA.gates.items.forEach(v => PAL.push({ kind: '裁决', t: `${v.id} ${v.q}`, sub: (VST[v.st] || {}).t || '', to: 'gate-' + v.id }));
  /* 2026-09-12 第二批：五张业务看板 + 五个数据源 直接进命令面板 */
  BIZ.BOARDS.forEach(b => PAL.push({ kind: '看板', t: b.n, sub: b.grp + ' · ' + b.stamp, url: b.url }));
  BIZ.SOURCES.forEach(x => PAL.push({ kind: '数据源', t: x.n, sub: x.kind, url: x.url }));
  BIZ.MOVES.forEach(m => {
    const ok = /^✅/.test((m.ev || {}).mkt || '');
    PAL.push({ kind: '策略', t: m.t, sub: m.p + ' · ' + (ok ? '结论' : '待验证（缺市场佐证）') + ' · ' + m.src, to: 'm-bizmoves', isMod: 1 });
  });
  (BIZ.EVD || []).forEach(e => PAL.push({ kind: '标准', t: e.k + ' ' + e.n, sub: '策略证据链 · ' + (e.k === 'L2' ? '▇▇条里只有 ▇▇条有' : e.k === 'L3' ? '▇▇条里 ▇▇条有' : '待你认'), to: 'm-bizevd', isMod: 1 }));
  /* 09-16 23:32：协作机制三段式 —— 链路「输入→判断→调用→落地→回写」▇▇步与「系统改进建议通道」 ▇▇条直接进命令面板 */
  ((window.COOP || {}).CHAIN || []).forEach(c => PAL.push({
    kind: '链路', t: c.n + ' ' + c.k,
    sub: (c.st === 'on' ? '通了' : c.st === 'half' ? '通，但有洞' : '还没连') +
         ' · ' + (c.who === 'you' ? '卡在你' : c.who === 'me' ? '卡在我' : '不卡谁'),
    to: 'm-cpchain', isMod: 1 }));
  ((window.COOP || {}).OPP || []).forEach(o => PAL.push({
    kind: '优化', t: o.t.replace(/<[^>]+>/g, ''),
    sub: (o.lv === 'now' ? '值得马上做' : o.lv === 'next' ? '下一批' : '先别装') + ' · 可采纳',
    to: 'm-cpopp', isMod: 1 }));
  PAL.push({ kind: '工具', t: '客户增减投归因推演器', sub: '四步出草稿', to: 'm-attrib', isMod: 1 });
  PAL.push({ kind: '工具', t: '行动队列', sub: '采纳的建议都在这', to: 'QUEUE', isQ: 1 });

  $('#palList').innerHTML = PAL.map((p, i) => `<div class="pal__i" data-i="${i}" data-kind="${p.kind}">
    <span class="pal__kind">${p.kind}</span>
    <span class="pal__t">${esc(p.t)}</span>
    <span class="pal__sub">${esc(p.sub)}</span></div>`).join('');

  $$('.pal__i').forEach(el => el.addEventListener('click', () => {
    const p = PAL[+el.dataset.i];
    closePal();
    if (p.url) { window.open(p.url, '_blank', 'noopener'); return; }
    if (p.isQ) { TOOLS.openQ(); return; }
    if (p.isCmd !== undefined) {
      go('cmd' + p.isCmd);
      const txt = $('#cmd' + p.isCmd).textContent;
      navigator.clipboard?.writeText(txt).then(() => toast('指令已复制，直接发我'), () => {});
      return;
    }
    if (p.isMod) {
      const b = $(`[data-mod="${p.to}"]`);
      if (!b) return;
      const v = OS.viewOf(b); if (v) OS.show(v, { noscroll: 1 });
      setTimeout(() => window.scrollTo({ top: Math.max(b.offsetTop - 76, 0), behavior: 'smooth' }), 40);
      b.classList.remove('is-flash'); void b.offsetWidth; b.classList.add('is-flash');
      return;
    }
    go(p.to);
  }));
}
function openPal() {
  $('#pal').classList.add('is-open');
  $('#palIn').value = ''; filterPal();
  $('#palIn').focus();
}
function closePal() { $('#pal').classList.remove('is-open'); }
function filterPal() {
  const q = $('#palIn').value.trim().toLowerCase();
  let first = null;
  $$('.pal__i').forEach(el => {
    const p = PAL[+el.dataset.i];
    const hit = !q || (p.kind + ' ' + p.t + ' ' + p.sub).toLowerCase().includes(q);
    el.hidden = !hit;
    el.classList.remove('is-sel');
    if (hit && !first) first = el;
  });
  if (first) first.classList.add('is-sel');
  $('#palEmpty').hidden = !!first;
}

/* ═══════════════════════════════════════════════════════════
   补丁抽屉
   ═══════════════════════════════════════════════════════════ */
function buildPatch() {
  const g = gateState();
  const L = ['# 系统控制台 · 修改补丁', '',
    `生成：${new Date().toLocaleString('zh-CN')}　|　控制台数据基准：${DATA.meta.stamp}（${DATA.meta.scanNote}）`, '',
    '> 用途：把这份补丁整段发给 Aime。我会逐条落到仓库对应文件；**未裁决的条目保持挂起，不用推断值代替**。', ''];

  const eks = Object.entries(EDITS);
  L.push('---', '', `## 一、页内字段改动（${eks.length} 处）`, '');
  if (!eks.length) L.push('（无）', '');
  else {
    const byMod = {};
    eks.forEach(([k, v]) => { (byMod[v.mod] = byMod[v.mod] || []).push(v); });
    Object.entries(byMod).forEach(([mod, list]) => {
      const m = MODS[mod];
      L.push(`### ${m ? m.t : mod}`);
      if (m && m.links.length) L.push(`落点：${m.links.map(l => '`' + l.f + '`').join(' / ')}`);
      L.push('', '| 位置 | 原值 | 改成 |', '| --- | --- | --- |');
      list.forEach(v => L.push(`| ${v.ctx} | ${v.before.replace(/\|/g, '\\|')} | **${v.after.replace(/\|/g, '\\|')}** |`));
      L.push('');
    });
  }

  const ans = Object.entries(ANNOTS);
  L.push('---', '', `## 二、模块批注（${ans.length} 条）`, '');
  if (!ans.length) L.push('（无）', '');
  else ans.forEach(([mod, txt]) => {
    const m = MODS[mod];
    L.push(`### ${m ? m.t : mod}`);
    if (m && m.links.length) L.push(`落点：${m.links.map(l => '`' + l.f + '`').join(' / ')}`);
    L.push('', '> ' + txt.split('\n').join('\n> '), '');
  });

  L.push('---', '', `## 三、新一批闸门裁决（${g.done}/${g.total}）`, '');
  DATA.pending.items.forEach(gt => {
    const s = g.picks[gt.id];
    if (!s.pick && !s.note) return;
    L.push(`### ${gt.id} ${gt.q.replace(/<[^>]+>/g, '')}`);
    L.push(`- 我的选择：${s.pick ? `**${s.pick}**` : '（未选）'}`);
    if (s.note) L.push(`- 补充：${s.note}`);
    L.push('');
  });
  if (!g.done && !DATA.pending.items.some(x => g.picks[x.id].note)) L.push('（无）', '');

  TOOLS.patch().forEach(x => L.push(x));

  const T = TOOLS.count();
  const rest = DATA.pending.items.filter(x => !g.picks[x.id].pick).map(x => x.id);
  L.push('---', '',
    `本次共 **${eks.length} 处字段改动 · ${ans.length} 条批注 · ${g.done} 条裁决 · ${T.adv} 条建议处置 · ${T.q} 条行动 · ${T.idea} 条灵感${T.at ? ' · ▇▇ 份归因草稿' : ''}**。`, '');
  if (rest.length) L.push(`仍未裁决并保持挂起：${rest.join(' / ')}`, '');
  L.push('落点索引（我按这个改）：', '');
  const touched = new Set([...eks.map(([, v]) => v.mod), ...ans.map(([m]) => m)]);
  if (g.done) touched.add('m-pending');
  if (T.adv) touched.add('m-advice');
  if (T.idea) touched.add('m-inbox');
  if (T.at) touched.add('m-attrib');
  if (!touched.size) L.push('- （本次没有涉及仓库文件）');
  else [...touched].forEach(m => {
    const x = MODS[m];
    if (x) L.push(`- ${x.t} → ${x.links.map(l => '`' + l.f + '`').join(' / ')}`);
  });
  return L.join('\n');
}

function openDrawer() {
  const g = gateState();
  const n = Object.keys(EDITS).length + Object.keys(ANNOTS).length + g.done + TOOLS.count().all;
  $('#patchText').textContent = buildPatch();
  $('#patchHint').innerHTML = n
    ? `共 <b>${n}</b> 项。复制整段发我即可——<b>这一页写不进你的本地磁盘</b>，所以要走这一步。`
    : `现在还没有任何改动。<b>怎么用：</b>顶栏点「编辑模式」（或按 <b>E</b>）→ 任意数字、说明、指令正文点开就能改 → 每个模块的「批注」写下要我做什么 → ▇▇ 节勾选闸门 → 回这里复制发我。<br><br>想直接改仓库原文，点每个模块上那排 <b>↗</b> 按钮，会用 Obsidian 打开对应笔记。`;
  $('#drawer').classList.add('is-open');
}

function resetAll() {
  if (!confirm('清空所有页内改动、批注和闸门选择？这一步不可撤销。')) return;
  [K.gates, K.edits, K.annots,
   'cec.t.advice', 'cec.t.queue', 'cec.t.ideas', 'cec.t.attrib', 'cec.t.tplvars'].forEach(k => localStorage.removeItem(k));
  EDITS = {}; ANNOTS = {};
  $$('[data-ek]').forEach(el => {
    el.classList.remove('is-edited');
    if (ORIG[el.dataset.ek] !== undefined) el.textContent = ORIG[el.dataset.ek];
  });
  $$('[data-annot-box] textarea').forEach(t => t.value = '');
  $$('.gate').forEach(gg => {
    gg.querySelectorAll('.opt').forEach(x => x.classList.remove('is-on'));
    gg.querySelector('.gate__note').value = '';
  });
  $('#drawer').classList.remove('is-open');
  location.reload();
}

/* ═══════════════════════════════════════════════════════════
   存取
   ═══════════════════════════════════════════════════════════ */
function saveGates() {
  const o = {};
  $$('.gate').forEach(g => {
    const pick = g.querySelector('.opt.is-on');
    o[g.dataset.gate] = { pick: pick ? pick.dataset.opt : '', note: g.querySelector('.gate__note').value };
  });
  localStorage.setItem(K.gates, JSON.stringify(o));
}
function saveEdits() { localStorage.setItem(K.edits, JSON.stringify(EDITS)); }

function restore() {
  ['layout', 'theme', 'density', 'motion', 'gap'].forEach(k => {
    const v = localStorage.getItem(TWK(k));
    if (!v) return;
    const seg = $(`.seg[data-tweak="${k}"]`);
    const b = seg?.querySelector(`[data-v="${v}"]`);
    if (b) { seg.querySelectorAll('button').forEach(x => x.classList.remove('is-on')); b.classList.add('is-on'); }
    applyTweak(k, v);
  });
  try {
    const o = JSON.parse(localStorage.getItem(K.gates) || '{}');
    $$('.gate').forEach(g => {
      const s = o[g.dataset.gate]; if (!s) return;
      if (s.pick) g.querySelector(`.opt[data-opt="${s.pick}"]`)?.classList.add('is-on');
      if (s.note) g.querySelector('.gate__note').value = s.note;
    });
  } catch (e) { /* 忽略损坏的本地存储 */ }
  try {
    EDITS = JSON.parse(localStorage.getItem(K.edits) || '{}');
    Object.entries(EDITS).forEach(([k, v]) => {
      const el = $(`[data-ek="${k}"]`);
      if (!el) { delete EDITS[k]; return; }
      el.textContent = v.after;
      el.classList.add('is-edited');
    });
  } catch (e) { EDITS = {}; }
  try {
    ANNOTS = JSON.parse(localStorage.getItem(K.annots) || '{}');
    Object.entries(ANNOTS).forEach(([m, txt]) => {
      const box = $(`[data-annot-box="${m}"]`);
      if (!box) return;
      box.querySelector('textarea').value = txt;
      box.classList.add('is-open');
      $(`[data-annot="${m}"]`)?.classList.add('is-on');
    });
  } catch (e) { ANNOTS = {}; }

  // URL 参数优先于本地存储，方便把某个视角直接甩给别人：?edit=▇▇&f=gap&go=gate-Q-020
  const U = new URLSearchParams(location.search);
  if (U.get('edit') === '1' || localStorage.getItem(K.edit) === '1') setEdit(true);

  /* 密度：默认精简。整页一次能看完，想看证据再点开 */
  try { FOLDS = JSON.parse(localStorage.getItem(K.folds) || '{}'); } catch (e) { FOLDS = {}; }
  setDens(U.get('dens') || localStorage.getItem(K.dens) || 'lite');

  const f = U.get('f') || localStorage.getItem(K.filter);
  if (f && f !== 'all') setFilter(f);
  const target = U.get('go');
  if (target) setTimeout(() => go(target), 260);
}

mount();
