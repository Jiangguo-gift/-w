/* ═══════════════════════════════════════════════════════════
   nf2.js —— 模块协作全景动态看板 v2.1（2026-11-13 全量保真版）
   源头：飞书画板「销售第二大脑 · 跨区协同调用全景图（v2.1）」双层卡片版
   （diagrams/2026-11-13T110000/gen_svg_v21_full.py 为唯一文字权威源）
   要求（她 11-13 原话）：完全保留此版本文字内容及呈现样式，流转图动态可视化。
   做法：HTML+CSS ▇▇ 复刻暗色全景（双层卡/资产盒/双通道/▇▇ 流对照表/图例），
         内联 SVG 连线层做流动动画、脉冲巡览、筛选与点击联动。
   后续新链路：改本文件 LINKS/FLOWS 常量 + 重新部署；未确认链路进 PENDING。
   ═══════════════════════════════════════════════════════════ */
window.NF2 = (function () {

  const SYNC = {
    ver: 'v2.1', date: '2026-11-13',
    source: '飞书画板 · 销售第二大脑跨区协同调用全景图（v2.1）双层卡片版',
    rule: '静态站无运行时抓取：新链路由 Aime 在每次刷新/你发话时检索 PRD、学习日志与 Obsidian 规则库，确认后更新本看板并重新部署；未确认的只进「待验证候选」，不混入正式编号。'
  };

  /* ── 三列分区：标题与红线（逐字对齐源脚本 ZONES） ── */
  const ZONES = [
    { id: 'II', col: 0, title: 'Ⅱ 认知与学习 · 运行大脑与迭代源泉',
      redline: '⛔ 红线：不复述记忆库 · 不呈现业务信息，只输出「怎么判断」的能力',
      main: '#A78BFA', deep: '#6D5AA8', headFill: '#1A1430', headStroke: '#8569CB', headTxt: '#C4B5FC',
      subFill: '#221A3D', subStroke: '#6D5AA8', subTxt: '#B7A6E8', boxFill: '#171233', boxStroke: '#7C63C0' },
    { id: 'III', col: 1, title: 'Ⅲ 高阶交互 · 流通血管与调度中枢',
      redline: '⛔ 红线：不呈现具体内容与业务信息，只呈现调度与自运行状态',
      main: '#60A5FA', deep: '#3A5A8C', headFill: '#101C33', headStroke: '#5178C6', headTxt: '#A9C6F2',
      subFill: '#15233C', subStroke: '#3A5A8C', subTxt: '#93B4E4', boxFill: '#101D33', boxStroke: '#4A6FA5' },
    { id: 'IV', col: 2, title: 'Ⅳ 业务工作区 · 唯一业务信息承载区',
      redline: '⛔ 红线：禁止流水账，必须输出判断、动作与反推',
      main: '#4ADE80', deep: '#357A4C', headFill: '#0F2417', headStroke: '#509863', headTxt: '#9FDCB2',
      subFill: '#14301F', subStroke: '#357A4C', subTxt: '#8FD4A6', boxFill: '#0E2618', boxStroke: '#4C9462' }
  ];

  /* ── Ⅰ 驾驶舱总台（逐字对齐源脚本 ▇▇-▇▇行） ── */
  const COCKPIT = {
    title: 'Ⅰ 驾驶舱全景 · 总台仪表盘（▇▇ 运行总览与反馈收口）',
    desc: '只收系统级元信息：运行状态 · 信息调度 · 结果梳理 · 反馈全貌；只跳转不搬运，零业务数字',
    redline: '⛔ 红线：收到的只能是状态/调度/验收/反馈类元信息',
    cards: [
      { name: '运行状态', desc: '管道新鲜度 · 节拍 · 失败回执' },
      { name: '信息调度', desc: '模块流转 · 堵点 · 任务排队' },
      { name: '结果梳理', desc: '产出清单 · 验收状态 · 待办收口' },
      { name: '反馈全貌', desc: '建议采纳 · 纠错 · 待复核概览' }
    ]
  };

  /* ── 六张模块卡：v2.1 核心业务原文 + v2 职责说明 + 落点 + 原理（逐字） ── */
  const CARDS = [
    { node: 'n01', no: '▇▇', zone: 'II', title: '外部学习接入', badge: 'AI · 自动收', badgeKind: 'gold',
      v21: ['市场分析与行业研究 · 平台新能力 · 外部玩法',
            '思维模型原料 · 人工投喂通道',
            '事实/观点分离标注，逐条带来源与时效'],
      bullets: ['持续接入市场分析、行业研究与平台新能力',
                '外部玩法、思维模型原料统一进学习队列',
                '事实与观点分开标注，逐条带来源与时效'],
      landing: '模块落点：市场/行业研究 · 平台新能力 · 外部玩法',
      landing2: '思维模型原料 · 人工投喂通道',
      principle: '大脑进化从外部输入开始，不从旧记忆里长出来' },
    { node: 'n02', no: '▇▇', zone: 'II', title: '认知加工与判断进化', badge: '系统 · 能力进化', badgeKind: 'gold',
      v21: ['理解框架 · 信息处理方式 · 判断规则升级',
            '证据标准 · 口径词典 · 失效前提重算'],
      bullets: ['把原料加工成理解框架、处理方式与判断规则',
                '升级证据标准与口径词典，失效前提标记重算',
                '每次迭代只回答一个问题：系统哪里变聪明了'],
      landing: '模块落点：Ⅱ-A 偏好库 · Ⅱ-B 规则口径 · Ⅱ-C 记忆机制',
      landing2: 'Ⅱ-D 纠错与待验证',
      principle: '只升级「怎么判断」，不沉淀具体业务数字' },
    { node: 'n03', no: '▇▇', zone: 'III', title: '体系化资源调度', badge: '中央编排', badgeKind: 'dark',
      v21: ['任务拆解 · 跨模块编排数据/档案/技能/模板',
            '按 v5 唯一正文位流通 · 调度台账留痕'],
      bullets: ['任务先拆解，再跨模块编排数据、档案、技能',
                '按信息架构 v5 归属流通，一条内容一个正文位',
                '调度全程留痕：卡在谁、等什么、何时恢复可见'],
      landing: '模块落点：Ⅲ-A 调用边界 · Ⅲ-C 数据管道',
      principle: '血管只负责输送，不生产也不展示内容' },
    { node: 'n04', no: '▇▇', zone: 'III', title: '技能自运行与放行门', badge: '自运行 + 人工关口', badgeKind: 'red',
      v21: ['定时触发器 · 六大技能按节拍自发运行',
            '四类禁止自决走放行门 · 授权按需发起',
            '运行回执与失败原因全量回传'],
      bullets: ['定时任务与技能按节拍自发触发，运行状态可查',
                '四类禁止自决走放行门：口径、分母、分层、承诺',
                '登录授权按需发起，全程不存储账号凭据'],
      landing: '模块落点：Ⅲ-B 放行与承诺 · Ⅲ-D 体检',
      landing2: '运行回执与失败原因全量回传',
      principle: '系统自己跑，高影响动作只有人能点头' },
    { node: 'n05', no: '▇▇', zone: 'IV', title: '自主研判与落地推进', badge: 'AI 干活 + 验收', badgeKind: 'gold',
      v21: ['进展/缺口/风险自主研判 · 写作矩阵执行',
            '验收点：真样张先看、口径锁复核'],
      bullets: ['自主研判：进展、缺口、风险一次判清',
                '提炼工作进展与后续动作，不转述原始数据',
                '写作矩阵与技能包在此执行，交付必经人工验收'],
      landing: '模块落点：Ⅳ-B 业绩 · Ⅳ-C 客户 · Ⅳ-D 供给 · Ⅳ-E 执行',
      principle: '给判断和动作，不给流水账' },
    { node: 'n06', no: '▇▇', zone: 'IV', title: '进阶反推与优化建议', badge: 'AI 干活', badgeKind: 'gold',
      v21: ['机会空间与漏损反推 · 建议带真去处',
            '证据闸门：缺市场佐证降级待验证线索',
            '▇▇ 类写作产物唯一出口（人工验收后回写）'],
      bullets: ['反推机会空间与漏损：钱从哪挣、哪个环节在漏',
                '每条优化建议带采纳后的真去处与责任对象',
                '缺市场佐证只叫待验证线索，不写成结论'],
      landing: '模块落点：Ⅳ-A 情报 · Ⅳ-F 打法弹药；▇▇ 类写作产物唯一出口',
      landing2: '（人工验收后回写）',
      principle: '反推比汇总值钱，建议必须可执行' }
  ];

  /* ── 三列资产盒（逐字对齐源脚本 ASSET_BOXES） ── */
  const ASSETS = [
    { zone: 'II', title: '对外供给的认知资产',
      items: ['业务判断规则与口径锁', '四层证据标准与可说边界', '思维模型与分析框架',
              '协作偏好与对齐方式参数', '新能力注册（可触发任务清单）', '每次迭代留痕：系统哪里变聪明了'] },
    { zone: 'III', title: '可调度的六大技能',
      items: ['周报复盘 · 优质达人生态培育', '客户创意策划 · 巨量优质素材诊断', '机构CA决策 · 品牌竞媒追踪',
              '六大数据源管道（数据源权威表）', '模板库与档案库读写通道', '血管只输送不生产，卡点超期自动上浮'] },
    { zone: 'IV', title: '持续产生的业务信号',
      items: ['客户原话与拜访信号 · 商单与结算结果', '盘面异动与缺口变化 · 验收纠错', '待验证线索 · 前提坍塌',
              '打法验证结果与案例素材', '新任务 / 授权 / 放行请求', '业务信息只在本区落地，元信息才允许上报'] }
  ];

  /* ── ▇▇条协同流逐字定义（对齐源脚本 FLOWS，OCR 误读已纠正） ── */
  const FLOWS = {
    C01: '外部学习赋能：市场研究/平台能力/思维模型 → Ⅳ-A 情报与 Ⅳ-F 打法，辅助决策建议',
    C02: '判断能力赋能：升级后的规则/口径/证据标准 → Ⅳ 全部研判与写作的口径锁',
    C03: '业务灵感反哺：日常业务信息（客户信号/拜访/盘面/商单）→ ▇▇ 的学习原料与灵感源',
    C04: '纠错回流：验收错误/待验证线索/前提坍塌 → Ⅱ-D，驱动规则重算与判断进化',
    C05: '能力注册：新规则/新框架/新技能 → Ⅲ-A 可触发任务清单，纳入自运行编排',
    C06: '认知资源调取：▇▇ 按任务反向调用规则库、口径库、偏好库（Ⅱ-A/Ⅱ-B）',
    C07: '任务资源派发：▇▇ 拆解派工，数据/档案/样板/模板/技能送达 Ⅳ 六个业务模块',
    C08: '技能产出直供：▇▇ 六大技能定时产出（供料/取数/诊断/分析）→ Ⅳ 对应模块',
    C09: '业务请求上行：Ⅳ 发起任务/登录授权/放行请求 → ▇▇ 放行门与 Ⅲ-B 裁决台账',
    C10: '验收回执回流：交付验收结论与承诺跟踪 → Ⅲ-B/Ⅲ-C 运行台账',
    C11: '三线状态上报：Ⅱ/Ⅲ/Ⅳ 只上报系统元信息 → ▇▇ 四类总览（零业务数字）',
    C12: '缺口回喂：▇▇/Ⅲ-D 体检发现能力缺口 → ▇▇ 学习队列优先补位',
    C13: '采纳派单：驾驶舱建议采纳 → ▇▇ 放行 → ▇▇ 派发'
  };

  /* ── 六类分色（对齐源脚本 C_COLOR 与底部图例） ── */
  const TYPES = [
    { id: 'empower',  name: '认知赋能',     color: '#A78BFA', flows: ['C01', 'C02', 'C05'] },
    { id: 'feedback', name: '业务反哺',     color: '#4ADE80', flows: ['C03', 'C04'] },
    { id: 'dispatch', name: '血管调度',     color: '#60A5FA', flows: ['C06', 'C07', 'C08'] },
    { id: 'request',  name: '业务请求',     color: '#34D399', flows: ['C09', 'C10'] },
    { id: 'cockpit',  name: '状态上报',     color: '#94A3B8', flows: ['C11', 'C13'] },
    { id: 'gapfeed',  name: '缺口回喂',     color: '#FBBF24', flows: ['C12'] }
  ];
  const TYPE_OF = Object.keys(FLOWS).reduce((m, c) => {
    const t = TYPES.find(t => t.flows.includes(c));
    m[c] = t ? t.id : 'dispatch';
    return m;
  }, {});
  const COLOR_OF = Object.keys(FLOWS).reduce((m, c) => {
    const t = TYPES.find(t => t.flows.includes(c));
    m[c] = t ? t.color : '#60A5FA';
    return m;
  }, {});

  /* ── 连线：kind=card 卡间 / top 顶部桩 / bottom 资产盒双通道 ── */
  const LINKS = [
    { flow: 'C05', kind: 'card', from: 'n02', to: 'n03', dir: 'right' },
    { flow: 'C07', kind: 'card', from: 'n03', to: 'n05', dir: 'right', lane: 1 },
    { flow: 'C08', kind: 'card', from: 'n04', to: 'n05', dir: 'right', lane: 2 },
    { flow: 'C09', kind: 'card', from: 'n05', to: 'n04', dir: 'left', lane: 1 },
    { flow: 'C10', kind: 'card', from: 'n05', to: 'n04', dir: 'left', lane: 2 },
    { flow: 'C06', kind: 'card', from: 'n03', to: 'n02', dir: 'left' },
    { flow: 'C11', kind: 'top', from: 'n02', to: 'cockpit', via: 'Ⅱ 认知与学习上报' },
    { flow: 'C11', kind: 'top', from: 'n03', to: 'cockpit', via: 'Ⅲ 高阶交互上报' },
    { flow: 'C11', kind: 'top', from: 'n05', to: 'cockpit', via: 'Ⅳ 业务工作区上报' },
    { flow: 'C12', kind: 'top', from: 'cockpit', to: 'n01' },
    { flow: 'C13', kind: 'top', from: 'cockpit', to: 'n03' },
    { flow: 'C01', kind: 'bottom', from: 'a-II', to: 'a-IV', channel: 'down' },
    { flow: 'C02', kind: 'bottom', from: 'a-II', to: 'a-IV', channel: 'down' },
    { flow: 'C03', kind: 'bottom', from: 'a-IV', to: 'a-II', channel: 'up' },
    { flow: 'C04', kind: 'bottom', from: 'a-IV', to: 'a-II', channel: 'up' }
  ];

  /* ── 顶部三 pill（对齐源脚本 ▇▇-▇▇，位置左 C12 / 中 C13 / 右 C11） ── */
  const PILLS = [
    { flow: 'C12', label: '缺口回喂学习队列', align: 'left' },
    { flow: 'C13', label: '建议采纳后派单', align: 'center' },
    { flow: 'C11', label: '三线状态上报（无业务数字）', align: 'right' }
  ];

  /* ── 主环青色虚线五标签（逐字，源脚本 ▇▇行） ── */
  const LOOP_LABELS = ['加工成判断能力', '能力就位待派', '任务清单待跑', '获批任务进区', '执行结果反推'];

  /* ── 底部双通道（逐字，源脚本 ▇▇ 行） ── */
  const CHANNELS = [
    { color: '#A78BFA', bg: '#221A3D', text: '赋能下行通道 · 认知资产 → 业务决策', flows: ['C01', 'C02'] },
    { color: '#4ADE80', bg: '#14301F', text: '原料反哺通道 · 业务信号 → 认知灵感', flows: ['C04', 'C03'] }
  ];

  /* ── 图例（逐字，源脚本 ▇▇-▇▇行） ── */
  const LEGEND = [
    ['#A78BFA', '紫＝认知赋能'], ['#4ADE80', '绿＝业务反哺'], ['#60A5FA', '蓝＝血管调度'],
    ['#34D399', '深绿＝业务请求'], ['#94A3B8', '灰＝状态上报'], ['#FBBF24', '黄＝缺口回喂']
  ];
  const ROLES = [
    ['#A78BFA', '大脑（认知进化）'], ['#60A5FA', '血管（调度自运行）'], ['#4ADE80', '业务助力（判断推进）'],
    ['#38BDF8', '总台（系统总览）'], ['#E06460', '人工关口']
  ];
  const FOOT_NOTES = [
    '迭代闭环：总览发现缺口 → 外部学习补位 → 认知升级 → 调度派发 → 业务验证 → 再回流',
    '信息架构 v5 封版骨架不变，本图只显性化调用关系；人工拍板与验收不独立成环，作为闸门嵌入 ▇▇ 放行门与 ▇▇ 验收点'
  ];

  /* 待验证候选：未确认新链路先挂这里（首批为空，保留机制） */
  const PENDING = [];

  const NODE_OF = {};
  CARDS.forEach(c => { NODE_OF[c.node] = c; });

  return {
    SYNC, ZONES, COCKPIT, CARDS, ASSETS, FLOWS, TYPES, TYPE_OF, COLOR_OF,
    LINKS, PILLS, LOOP_LABELS, CHANNELS, LEGEND, ROLES, FOOT_NOTES, PENDING, NODE_OF
  };
})();
