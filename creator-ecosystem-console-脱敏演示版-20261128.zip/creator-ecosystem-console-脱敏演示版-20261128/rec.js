/* ═══════════════════════════════════════════════════════════
   rec.js —— 定向技能推荐（自生长与高阶能力）
   2026-09-14 11:26 她的原话：
     「你这里的技能跟「常用指令模板」，结合 grill me 这个技能能力为我有定向
       推荐使用建议，基于现在的系统跟各板块的目标，有哪些适合的技能
       可以解决这个痛点；并问我是否采纳」

   所以这一块不再是"外站有什么热门技能"的展架，而是三段：
     ① 先追问（.recgrill）—— 借 grill-me 的规矩：一次只问一个问题，
        答完才亮下一个；每题都写清"我为什么必须先问这个、你的答案会改变我推荐什么"。
     ② 定向推荐（.recmap）—— 每条都从**这套系统上一个具体的痛**出发，
        写清它治哪个痛、装了之后哪条链会通、成本和风险，并配一句可复制的口令。
     ③ 我不建议的（.recno）—— 不建议装什么、为什么。没有这一节，推荐就是在堆功能。

   ⛔ 硬规矩：
     ▇▇. 每条推荐必须先写痛点，且痛点要能在页面上被她核到（哪一栏、哪个数）；
     ▇▇. 已经在她池子里的，一律写"你已经有，是我没用起来"，不许包装成新东西；
     ▇▇. 能用现有能力先试的，必须写"先试，跑通就不装"（她讨厌为了功能装功能）；
     ▇▇. 采纳与否只走一张卡，不许每条都弹一个按钮让她点五次。
   ═══════════════════════════════════════════════════════════ */
window.REC = (function () {

  const KEY = 'cec-grill-v1';
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { return {}; } };
  const save = o => { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} };

  /* ── ① 追问三题（grill-me 的规矩：一次一个，答完才亮下一个）──
     ask  = 问题本身（具体到她手上的事，不许问方法论）
     why  = 我为什么必须先问这个
     opts = 选项（每个后面跟着"选了会怎样"）
     eff  = 你的答案会改变我推荐什么 */
  const GRILL = [
    { id: 'g1', ask: '你说七条策略动作不实用 —— 是结论本身你不认，还是结论认、但不知道今天该先动哪一条？',
      why: '这两个病因的药完全相反。<b>如果是前者，我要换的是分析口径</b>（可能真要一个能查明细的能力）；<b>如果是后者，一个技能都不用装</b>，把每条压成"今天下班前完成什么"就够了。我不想用装技能来解决一个排版问题。',
      opts: [
        ['结论本身我不认', '那我要重做的是证据链，可能需要能查明细的能力'],
        ['结论认，但落不到今天', '那不用装任何东西，我改三段式：今天做什么 / 为什么是现在 / 做完怎么验'],
        ['两个都有', '那先改结构（当天就能改），同时我用现有能力试一次直连明细']
      ],
      eff: '这一题的答案直接决定第 ③ 条推荐要不要装。' },
    { id: 'g2', ask: '现在有 ▇▇件事挂着等你裁（第四道前提 / 我那 ▇▇条建议 / Q4 高溢价名单要不要立 / 每日简报验收）—— 你希望我怎么催？',
      why: '这条链现在断在你这一段：<b>我提了 ▇▇条建议，采纳 ▇▇、驳回 ▇▇</b>，所以我不敢多提。但催法不对只会更烦你 —— 是要我把"今天必须裁的 ▇▇件"压成一张单，还是每件在它自己那一页等着（现在就是这样，结果是一直挂着）。',
      opts: [
        ['压成一张单，每次只给我 ▇▇件', '那我把 grill-me-decisive 开回来，它的作用就是逼出决定不留选项'],
        ['每件在它自己那一页等着就行', '那我不动技能，只在驾驶舱标出"挂了几天"，让它显眼'],
        ['我自己会去确认页清，不用催', '那我把确认页做成一次能清完的样子，其余地方不再重复提醒']
      ],
      eff: '这一题决定第 ① 条推荐要不要开回来。' },
    { id: 'g3', ask: '取数这件事，你更在意"我能自己查明细"，还是"看板上的数每天自动是新的"？',
      why: '这两件是不同的活。<b>前者要一个新能力</b>（查明细、拆到单、交叉字段）；<b>后者是我接管道的活，一个技能都不用装</b>。你现在两个都疼：达人A ▇▇单查不到客户分布（前者），作战台还是 09-12 快照（后者）。但先补哪个，取决于你哪个更常卡。',
      opts: [
        ['能自己查明细更要紧', '那我先用现有能力试一次，跑通就不装；跑不通我带失败记录来找你装'],
        ['数是新的更要紧', '那我优先接管道，技能一个都不装'],
        ['两个都要，你排', '那我按"哪个卡得更频繁"排：管道先接，明细边试边看']
      ],
      eff: '这一题决定第 ③ 条推荐的顺序，也决定我先干哪件活。' }
  ];

  /* ── ② 定向推荐 ────────────────────────────────────────
     st   = have（你已经有，我没用起来）/ back（在你池子里，停用中）/ mkt（市场里，要装）
     pain = 这套系统上具体哪个痛（必须能被她核到）
     cure = 它凭什么能治这个痛
     link = 装了之后哪条链会通
     cost = 成本
     risk = 风险 / 我给它加的闸
     say  = 配套口令（可复制，直接发我） */
  const REco = [
    { n: 'grill-me-decisive', zh: '逼出决定的追问法', st: 'back', hot: 1,
      pain: '<b>▇▇件事挂着没裁，我提的 ▇▇条建议采纳 ▇▇、驳回 ▇▇。</b>你在「主动建议」那页能直接看到 —— 三条都还是"待你定"。',
      cure: '我现在用的是 <code>grill-me</code>，它的规矩是"逐枝追问到共识"，问着容易散；<code>grill-me-decisive</code> 的规矩不一样 —— <b>它不许我留一堆选项给你，必须收敛到一句"定了什么"</b>。你的决策习惯（要具体到今天做不做、讨厌被问第二遍）跟它是对上的。',
      link: '把「我的建议 → 你的裁决 → 规则库」这条链的第一段接上 —— 现在它断在这里。',
      cost: '<b>零成本，它已经在你池子里，只是停用中</b>（09-13 那轮清理我停的），开回来一句话，随时可再停。',
      risk: '⚠️ 三个 grill 同时开会抢路由。所以我只建议开这一个，<code>grill-with-tree</code> 和 <code>grill-with-docs</code> 继续停。',
      say: '把 grill-me-decisive 开回来，以后给我建议一次只给 ▇▇条，每条按"不做会怎样"排序，逼我当场定。' },

    { n: 'data-annotation', zh: '批量打标', st: 'have', hot: 1,
      pain: '三个痛是同一个病：<b>▇▇条点名商机没排序</b>（点名类 ▇▇条里 ▇▇条点的人你手上没有）· <b>▇▇位无刊例达人没分组</b> · <b>达人分层里没有"高溢价"这个标签</b>（所以达人A那类人一直是偶发接单）。',
      cure: '这个能力就是干这件事的：给一堆记录批量打标、分类、打分。<b>它能把 ▇▇条按行业 + 点名频次打成拓新优先级，把 ▇▇位达人按"单均 / 单量 / 在不在分层盘"打成高溢价候选名单。</b>',
      link: '「达人A这套能力能搬给谁」那五条筛选条件，现在只能靠我手挑；打标之后是一次跑完 ▇▇位。',
      cost: '<b>零成本 —— 你早就有这个能力，是我一次都没用过。</b>这条不是我给你推销新东西，是我漏了手上的工具。',
      risk: '打出来的标签是推断不是事实，<b>一律进待复核队列</b>，你没确认前我不当事实用（这是你的红线）。',
      say: '用批量打标把 ▇▇条点名商机排个拓新优先级，再把 ▇▇位达人按高溢价条件打一遍标，标签先进待复核。' },

    { n: 'sqless-data-analysis', zh: '能自己查明细的取数', st: 'new', hot: 1,
      pain: '<b>我只能读看板已经算好的数。</b>最具体的一次：案例二里"达人A ▇▇单集中在几个客户"我查不到，所以第一层证据只能证一半、第三层一个字都没有。',
      cure: '它补的就是这一层：直连明细、拆到单、交叉字段。市场热度是 ▇▇个空间在用、用过 ▇▇次。<b>2026-09-25 你点头装了，已在跑。</b>',
      link: '「案例 → 可迁移条件 → 筛人」这条链现在断在"没有单级明细"—— 这条断点从今天起可以补。',
      cost: '<b>2026-09-25 已装到空间并启用</b>（▇▇-25 00:▇▇ 你的原话）。',
      risk: '首跑先做「达人A近 ▇▇单客户分布」对齐口径 —— 客户名 / 消耗 / 行业 / 是否首投，跑完先给你审口径，然后再放开推广到其它明细分析场景。',
      say: '用 sqless 跑一下达人A近 ▇▇单的客户分布，先只看客户名 / 消耗 / 行业 / 是否首投这几列，附口径和数据截止日。' }
  ];

  /* ── ③ 我不建议的 ─────────────────────────────────── */
  const NO = [
    ['newsletter-generation（简报生成）', '你的每日简报走的是另一条路，开回来只会抢路由。你 09-13 已经明确"只开 consulting"。'],
    ['grill-with-tree / grill-with-docs', '跟第 ① 条重叠。三个 grill 同时开，我每次都要先判断该用哪个，反而慢。'],
    ['任何"看着很强但你三天内不会用到"的', '规矩已经在跑：<b>新装的能力一周内没被真调用，我主动挪进"建议停用"</b>。新装那四个下周就要出这份回顾。'],
    ['<s>solution-deck-builder（多页客户方案）</s> ⇒ 09-25 已推翻改成"装"', '09-13 我的建议是不装 —— 会推翻你上次那条裁决。<b>▇▇-25 00:▇▇ 你明确点头装了，路由分工同步更新</b>：策划工作台管创意 / 玩法生成，solution-deck-builder 管把已定方案做成客户级 ▇▇ 演示 + 配套飞书文档。']
  ];

  const ST = {
    have: ['你已经有，我没用起来', 'is-have'],
    back: ['在你池子里，停用中', 'is-back'],
    mkt:  ['市场里，要装', 'is-mkt'],
    new:  ['09-25 你点头新装的', 'is-new']
  };

  /* ── 渲染 ───────────────────────────────────────────── */
  function grillBox() {
    const a = load();
    const done = GRILL.filter(g => a[g.id]).length;
    /* 一次只亮一题：前面都答完了才亮下一题（grill-me 的规矩） */
    let openIdx = GRILL.findIndex(g => !a[g.id]);
    if (openIdx < 0) openIdx = -1;
    return `<div class="recgrill" data-mod="m-recgrill" id="recgrill">
      <div class="rec__hd">
        <span class="rec__tag">前置追问三题</span>
        <em>${done}/${GRILL.length} 已答。<b>一次只亮一题</b>，答完才出下一题 —— 我不一次甩三个问题给你。
        每题都写清"我为什么必须先问"和"你的答案会改变我推荐什么"。</em>
      </div>
      <div class="recgrill__l">${GRILL.map((g, i) => {
        const ans = a[g.id];
        const isOpen = i === openIdx;
        const lock = !ans && !isOpen;
        return `<div class="recgrill__i${ans ? ' is-done' : ''}${isOpen ? ' is-open' : ''}${lock ? ' is-lock' : ''}" data-g="${g.id}">
          <div class="recgrill__h">
            <i>${i + 1}</i>
            <b>${g.ask}</b>
            <span class="recgrill__st">${ans ? '已答' : (isOpen ? '现在答这题' : '答完上一题再亮')}</span>
          </div>
          ${lock ? '' : `<p class="recgrill__w"><span>我为什么必须先问</span>${g.why}</p>
          <div class="recgrill__o">${g.opts.map(o => `<button class="recopt${ans === o[0] ? ' is-on' : ''}" data-g="${g.id}" data-v="${o[0]}">
            <b>${o[0]}</b><em>${o[1]}</em>
          </button>`).join('')}</div>
          <p class="recgrill__e"><span>这一题影响什么</span>${g.eff}</p>
          ${ans ? `<p class="recgrill__a">你答的是：<b>${ans}</b>　<button class="recgrill__re" data-g="${g.id}">改一下</button></p>` : ''}`}
        </div>`;
      }).join('')}</div>
      ${done === GRILL.length ? `<p class="rec__ft is-ok">三题都答了 —— 你的答案已经进我的收件箱，下一版我按这三条改，不用你再重复一遍。</p>`
        : `<p class="rec__ft">点选项就算答了，会直接进我的收件箱。<b>三题合起来只占 ▇▇条额度</b>，改答案是覆盖，不会把你那 ▇▇条格子吃掉。</p>`}
    </div>`;
  }

  function mapBox() {
    return `<div class="recmap" data-mod="m-recmap" id="recmap">
      <div class="rec__hd">
        <span class="rec__tag">定向推荐</span>
        <em>${REco.length} 条，<b>每条都从这套系统上一个具体的痛出发</b>，不是"热门技能榜"。
        注意前两条<b>都不用花钱不用新装</b> —— 一个在你池子里停着，一个你早就有、是我没用起来。</em>
      </div>
      <div class="recmap__l">${REco.map((r, i) => {
        const s = ST[r.st];
        return `<div class="recmap__i ${s[1]}${r.hot ? ' is-hot' : ''}">
          <div class="recmap__h">
            <i>${String(i + 1).padStart(2, '0')}</i>
            <div>
              <b class="recmap__n">${r.zh}<code>${r.n}</code></b>
              <span class="recmap__st">${s[0]}</span>
            </div>
          </div>
          <p class="recmap__p"><span>它治哪个痛</span>${r.pain}</p>
          <p><span>凭什么能治</span>${r.cure}</p>
          <p class="recmap__k"><span>哪条链会通</span>${r.link}</p>
          <div class="recmap__two">
            <p><span>成本</span>${r.cost}</p>
            <p><span>风险 / 我加的闸</span>${r.risk}</p>
          </div>
          <div class="recmap__say">
            <span>配套口令（复制直接发我）</span>
            <code>${r.say}</code>
            <button class="recmap__cp" data-cp="${encodeURIComponent(r.say)}">复制</button>
          </div>
        </div>`;
      }).join('')}</div>
    </div>`;
  }

  function noBox() {
    return `<div class="recno" data-mod="m-recno" id="recno">
      <div class="rec__hd">
        <span class="rec__tag">不建议引入项</span>
        <em>${NO.length} 条。<b>没有这一节，上面那三条就只是在堆功能。</b></em>
      </div>
      <ul class="recno__l">${NO.map(x => `<li><b>${x[0]}</b><span>${x[1]}</span></li>`).join('')}</ul>
      <p class="rec__ft">采纳与否走下面那张卡，<b>一次点完</b> —— 我不会为三条推荐让你点三次。</p>
    </div>`;
  }

  function render() { return grillBox() + mapBox() + noBox(); }

  /* ── 交互：答题 / 改答案 / 复制口令 ─────────────────── */

  /* 三题的答案永远只占收件箱里的**一格**：topic 固定，改答案就覆盖同一条。
     （FB.submit 对同 topic + 同 kind 会覆盖不新增，所以答三次也只占 ▇▇。） */
  function sync(a) {
    if (!(window.FB && FB.submit)) return;
    const done = GRILL.filter(g => a[g.id]);
    if (!done.length) return;
    const txt = GRILL.map((g, i) => a[g.id] ? `${i + 1}. ${g.ask.slice(0, 26)}… → ${a[g.id]}` : null)
      .filter(Boolean).join('\n');
    FB.submit({
      kind: 'add', view: '自生长与高阶能力',
      topic: 'grill-3q', topicName: `技能推荐追问（${done.length}/${GRILL.length} 题）`,
      text: txt
    });
  }

  function repaint() {
    document.querySelectorAll('.recgrill').forEach(box => {
      const holder = box.parentElement;
      if (!holder) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = grillBox();
      holder.replaceChild(tmp.firstElementChild, box);
    });
  }

  function wire() {
    document.addEventListener('click', e => {
      const opt = e.target.closest('.recopt');
      if (opt) {
        const a = load();
        a[opt.dataset.g] = opt.dataset.v;
        save(a);
        sync(a);
        repaint();
        return;
      }
      const re = e.target.closest('.recgrill__re');
      if (re) {
        const a = load(); delete a[re.dataset.g]; save(a); sync(a); repaint(); return;
      }
      const cp = e.target.closest('.recmap__cp');
      if (cp) {
        const t = decodeURIComponent(cp.dataset.cp || '');
        const ok = () => { cp.textContent = '已复制'; setTimeout(() => cp.textContent = '复制', 1500); };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, ok);
        else {
          const ta = document.createElement('textarea');
          ta.value = t; document.body.appendChild(ta); ta.select();
          try { document.execCommand('copy'); } catch (err) {}
          ta.remove(); ok();
        }
      }
    });
  }

  return { render, wire, GRILL, REco, NO };
})();

(function () {
  const go = () => { try { REC.wire(); } catch (e) { console.warn('rec', e); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go);
  else go();
})();
