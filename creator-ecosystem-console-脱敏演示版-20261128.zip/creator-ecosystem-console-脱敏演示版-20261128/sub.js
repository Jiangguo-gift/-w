/* ═══════════════════════════════════════════════════════════
   sub.js —— 左栏二级板块导航 + 当前板块上方的三级固定条（v3）
   2026-09-13 本人第二轮返工（附两张截图）：
     ①「你的所有标题标签一点都不像个标题的名字，请你用清晰直白的
        标题文字做替换，同步原本工作台上把标题也换了」
     ②「你的三级标题不要放在左侧导航栏了，你可以参考图示在当前二级
        模块的上方固定出现，切换下一个模块再换成下一个二级模块的三级标题」

   所以这一版改两件事：
     ① 标签全部改成**标题词**（模块定位 / 已具备能力 ▇▇ 项 / 可执行动作 ▇▇件 /
        重要信息汇总 ▇▇条 / 能力评价与短板 …），并且**和页面正文里的标题
        逐字一致**（正文那侧改在 mod.js / selfeval.js / plain.js / ui.js）；
        ⛔ 不许再拿一句话当标签（v2 的「本页答 · …」就是这个毛病）。
     ② 左栏只留二级；三级搬到**当前二级板块上方的固定横条**（贴在顶栏下面），
        滚到哪一块，条上就换成那一块的三级；那一块没有三级就写一句"整块看"。

   载入顺序：必须在 shell.js 之后（要用 OS.BY，且要等 ui.js 的 mnavs() 跑完）。
   ⛔ 只做导航与标题：不新增数字、不改口径、不动模块内容与顺序。
   ═══════════════════════════════════════════════════════════ */
window.SUBNAV = (function () {

  const $  = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];

  const clean = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const txt   = (el, sel) => { const t = sel ? $(sel, el) : el; return t ? clean(t.textContent) : ''; };
  const cut   = (s, n) => { s = clean(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  const cnt   = (el, sel) => $$(sel, el).length;
  const inum  = (el, sel) => clean((sel ? $(sel, el) : el) ? ((sel ? $(sel, el) : el).textContent || '') : '').replace(/[^0-9]/g, '');
  const esc   = s => String(s == null ? '' : s).replace(/"/g, '');

  /* ── 二级板块清单：selector → 标题词 → 三级固定项 ──────────
     排序不在这里定（按页面 DOM 真实顺序），这份表只管"叫什么"。
     ⛔ 标签必须是标题词，能念得出"这块装的是什么"；和正文标题保持一字不差。 */
  const SPEC = [
    /* 每页最上面那条结论 */
    { sel: '.mxsum', lbl: () => '本页结论' },

    /* ── 大类（她 09-13 23:18：内容又多又乱，聚类整合成几个大类，
       并分别给到类目的信息总结标题）───────────────────────────
       有大类的页面（驾驶舱 / 能力清单 / 业务基本盘）：
         二级 = 大类（数据总览 / 策略总结 / 能力提炼 / 数据底仓 …）
         三级 = 这一类里原来的那几块
       没大类的页面照旧走下面那份逐块清单，一个字没动。 */
    { sel: '.cgrp', all: 1,
      lbl: el => cut(txt(el, '.cgrp__t'), 14),
      kid: { sel: ':scope > .cgrp__b > *', exp: 1,
             lbl: el => (window.CGRP ? CGRP.labelOf(el) : ''), max: 8 } },

    /* ⛔ 不再进导航（她 09-13 第四轮圈选 / R-554）：
       模块定位（.mx__hd）· 已具备能力（.mxb--can）· 可执行动作（.mxb--do）·
       能力评价与短板（.mxs）—— 这四块是每页都一样的说明性骨架，
       现在收进模块卡底部那个默认收起的说明折叠区，导航里一个都不列。 */

    /* 这一页你必须知道的事实（带数字、带来源，属于具体事项，留） */
    { sel: '.mxk', lbl: () => '重要信息汇总' },

    /* 驾驶舱 */
    { sel: '.bizs', lbl: () => '业绩数据总览' },
    { sel: '.pano', lbl: () => '各板块要点',
      kid: { sel: '.pano__g', lbl: el => cut(txt(el, '.pano__gt'), 14), max: 6 } },

    /* 我的能力清单 */
    { sel: '.pl--role', lbl: () => '角色定位',
      kid: { sel: '.plr__i', lbl: el => cut(txt(el, '.plr__t'), 14), max: 4 } },
    { sel: '.pl--dom', lbl: () => '能力域明细',
      kid: { sel: '.pld__i', lbl: el => cut(txt(el, '.pld__t'), 15), max: 6 } },
    { sel: '.pl--mode', lbl: () => '模式与玩法库',
      kid: { sel: '.plm__i', lbl: el => cut(txt(el, '.plm__n') + ' ' + txt(el, '.plm__t'), 15), max: 12 } },

    /* 认知与学习 */
    { sel: '.mem', lbl: () => '记忆库清单',
      kid: { sel: '.mems', lbl: el => cut(txt(el, '.mems__hd b'), 14), max: 6 } },

    /* ── 09-16 她这一轮五条反馈新增的块 ──────────────────
       记忆库要"像图书目录一样可追踪"、灵感库要我主动给方向、
       思维模式要每天动、协作机制要一个能逐条反馈的窗口。
       三级取各自的小节名，不另起叫法（和正文标题一字不差）。 */
    { sel: '.cat', lbl: () => '记忆库总目录',
      kid: { sel: '.cat__sh, .cat__sec',
             lbl: el => cut(txt(el, '.cat__cls') || txt(el, '.cat__n'), 16), max: 9 } },
    { sel: '.rul', lbl: () => '判断规则与口径',
      kid: { sel: '.rul__sec', lbl: el => cut(txt(el, '.rul__n'), 16), max: 8 } },
    { sel: '.spk', lbl: () => '主动建议方向',
      kid: { sel: '.spkd', lbl: el => cut(txt(el, '.spkd__t'), 16), max: 8 } },
    { sel: '.pat', lbl: () => '今天这一页动了什么',
      kid: { sel: '.pat__sec, .pat__ask',
             lbl: el => cut(txt(el, '.pat__n'), 16), max: 7 } },
    { sel: '.gate', lbl: () => '等你逐条拍板的事项',
      kid: { sel: '.gate__i', lbl: el => cut(txt(el, '.gate__t'), 15), max: 11 } },
    { sel: '.wk', lbl: () => '每周二复盘',
      kid: { sel: '.wk__sec, .wk__honest',
             lbl: el => cut(txt(el, '.wk__n') || '先说清的一句实话', 16), max: 5 } },
    { sel: '.thk', lbl: () => '决策习惯' },
    { sel: '.gl',  lbl: () => '成长与能力' },

    /* 高阶交互 */
    { sel: '.hub', lbl: () => '「我能装的技能」' },
    { sel: '.mxcmd', lbl: () => '「常用指令模板」',
      kid: { sel: '.mxcmd__i', lbl: el => cut(txt(el, '.mxcmd__t').replace(/复制$/, ''), 15), max: 9 } },
    { sel: '.mxask', lbl: () => '等你定的事项',
      kid: { sel: '.ask', lbl: el => cut(txt(el, '.ask__q'), 15), max: 6 } },
    { sel: '.dnl', lbl: () => '已定事项' },

    /* 「外部大盘」：原来整块叫「外部大盘事实与机会」，看不出装了什么，
       现在按内容拆成四个各自成题的板块（她 09-13 第三轮：重新做内容聚类） */
    { sel: '.eco__sec', all: 1, lbl: el => {
        const n = $('.eco__n', el);
        if (!n) return '';
        if (n.classList.contains('eco__n--hot'))   return '可拓机会';
        if (n.classList.contains('eco__n--no'))    return '不建议做的';
        if (n.classList.contains('eco__n--brief')) return '每日行业简报';
        return '外部动态';
      } },

    /* 业务基本盘 */
    { sel: '.rv', lbl: () => '本周策略回顾',
      kid: { sel: '.rvs__sec, .rvfx',
             lbl: el => el.classList.contains('rvfx') ? '改这五个板块'
                      : cut(txt(el, '.rvsec__no') + ' ' + txt(el, '.rvsec__t h4'), 17), max: 6 } },
    { sel: '.viz', lbl: () => '季度结构分析',
      kid: { sel: '.viz__tab', lbl: el => cut(el.textContent, 14), max: 4, click: 1 } },
    { sel: '.bzv', lbl: () => '经营总判断' },
    { sel: '.block', all: 1, lbl: el => cut(txt(el, '.block__h h3'), 18) },
    { sel: '.bzsec', all: 1, lbl: el => cut(txt(el, '.bzsec__h h3'), 18),
      kid: { sel: '.bcard, .bzsrc__i', lbl: el => cut(txt(el, '.bcard__n') || txt(el, 'h5'), 15), max: 6 } }
  ];

  let io = null;

  /* ── 不进导航的板块（她 09-13 第四轮圈选 → R-554）─────────
     判定标准是她给的那句话："涉及描述性的、无具体事项的都隐藏，
     都不要列出设置二级标题"。
       · 说明性骨架（模块定位 / 已具备能力 / 可执行动作 / 能力评价与短板）
         已经从 SPEC 里删掉，并且在页面上收进折叠说明区；
       · 下面这几块页面上留着（点了能用、能查），但不占导航位：
         拜访快记 = 输入框、常用入口 = 跳转按钮、未照字面执行 = 我的交代、
         不建议做的 = 建议、数据口径对照 = 名词解释。 */
  const MUTE = new Set(['不建议做的', '数据口径对照', '未照字面执行', '拜访快记', '常用入口']);

  /* 自己改 DOM 会再次触发下面那个 MutationObserver —— 不设闸就是无限重画 */
  let busy = false;
  let lastSig = '';
  let curL2 = -1;                 /* 三级条现在显示的是第几个二级板块 */
  let SEC = null, ITEMS = [];     /* 当前页与它的二级板块清单（点击时直接用，不重算） */
  /* 点了导航就以点的那一块为准：滚动过程中观察器还会报上一块，
     所以点完先锁一小会儿，等她真正停在那一块上（她 09-13 第三轮反馈之后加的） */
  let lock = 0;

  /* 滚动落点要避开顶栏 + 那条固定的三级条，否则跳过去正好被压住 */
  function off() {
    const base = document.body.classList.contains('shell') ? 92 : 112;
    let h = 0;
    try {
      const sec = document.getElementById(document.body.dataset.view || '');
      const wrap = sec && $('.stk', sec);
      if (wrap && wrap.offsetHeight) h = Math.min(wrap.offsetHeight, 130);
    } catch (e) {}
    return base + h + 10;
  }

  /* ── 这一页有哪些二级板块（按页面真实顺序） ─────────────── */
  function blocks(sec) {
    const seen = new Set();
    const out = [];
    SPEC.forEach(sp => {
      const els = sp.all ? $$(sp.sel, sec) : [$(sp.sel, sec)].filter(Boolean);
      els.forEach(el => {
        if (!el || seen.has(el)) return;
        seen.add(el);
        let lbl = '';
        try { lbl = sp.lbl(el) || ''; } catch (e) { lbl = ''; }
        if (!lbl) return;
        if (MUTE.has(lbl)) return;                 /* 描述性 / 工具性：页面留着，导航不列 */
        if (el.closest('details')) return;          /* 收进折叠说明区的，导航一律不列 */
        /* 已经被收进大类的块：它是三级，不再单独占一个二级位（09-14 大类分组） */
        if (!el.classList.contains('cgrp') && el.closest('.cgrp')) return;
        out.push({ el, lbl, sp });
      });
    });
    /* 页面顺序才是她的阅读顺序 */
    out.sort((a, b) => (a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1);
    out.forEach((x, n) => {
      if (!x.el.id) x.el.id = sec.id + '-n' + n;
      x.kids = kidsOf(sec, x, n);
      /* 大类里只有一块、且那块就叫大类这个名字：三级条上再写一遍是废话，去掉 */
      if (x.kids.length === 1) {
        const a = x.kids[0].lbl, b = x.lbl;
        if (a === b || a.indexOf(b) >= 0 || b.indexOf(a) >= 0) x.kids = [];
      }
    });
    return out;
  }

  /* ── 三级：二级下面本来就固定存在的那几格 ───────────────── */
  function kidsOf(sec, item, n) {
    const k = item.sp.kid;
    if (!k) return [];
    let els = $$(k.sel, item.el);
    if (!els.length) return [];
    /* 声明了 data-l3sel 的块要摊平成它内部那几个固定子板块（走 grp.js 同一套展开，
       所以三级条和格子头的小链接名字永远一致）—— 她 09-18 10:52 要的
       「上层导航栏的小标题对应到每个子模块」。没声明的块行为不变。 */
    let pre = null;
    if (k.exp && window.CGRP && CGRP.expand) {
      pre = CGRP.expand(els);
      els = pre.map(x => x.el);
    }
    if (k.max) { els = els.slice(0, k.max); if (pre) pre = pre.slice(0, k.max); }
    return els.map((el, j) => {
      let lbl = '';
      try { lbl = (pre ? cut(pre[j].lbl, 14) : k.lbl(el)) || ''; } catch (e) { lbl = ''; }
      if (!lbl) return null;
      /* 图表这类是切页签不是滚动：点三级 = 先切页签，再滚到图上 */
      const clickId = k.click ? (el.id || (el.id = sec.id + '-k' + n + '-' + j)) : '';
      const goEl = k.click ? item.el : el;
      if (!goEl.id) goEl.id = sec.id + '-n' + n + '-' + j;
      return { el, lbl, go: goEl.id, click: clickId, obs: k.click ? null : el };
    }).filter(Boolean);
  }

  /* 这一块里有没有需要她动手的东西：红=等你定，黄=有前提/空缺 */
  function stateOf(el) {
    if (el.classList.contains('mxsum')) {
      if (el.classList.contains('mxsum--wait'))  return ['hot', '这一页的结论卡在你这里，等你拍板'];
      if (el.classList.contains('mxsum--watch')) return ['gap', '这一页能动，但带前提'];
      return ['', ''];
    }
    if (el.classList.contains('mxask') || $('.ask:not(.is-done)', el)) return ['hot', '这一块有等你定的'];
    if ($('[data-gap="▇▇"]', el)) return ['gap', '这一块有空缺'];
    return ['', ''];
  }

  /* ── 固定条的壳：顶栏底下一条，装（横向二级条）+ 三级条 ──────
     横向二级条只在窄屏 / 收起左栏时出现，两者叠在同一个 sticky 壳里，
     不会互相压住。 */
  function stack(sec) {
    let wrap = $('.stk', sec);
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'stk';
      const mn = $('.mnav', sec);
      const head = $('.sec__head', sec);
      if (mn && mn.parentNode) { mn.parentNode.insertBefore(wrap, mn); wrap.appendChild(mn); }
      else if (head) head.after(wrap);
      else sec.prepend(wrap);
      wrap.insertAdjacentHTML('beforeend', '<nav class="l3b" aria-label="当前板块内的分格直达"></nav>');
    } else {
      /* 模块重渲染后 mnav 可能又被塞回 section 下面，收回壳里 */
      const mn = $('.sec > .mnav', sec) || (sec.querySelector(':scope > .mnav'));
      if (mn && mn.parentNode !== wrap) wrap.insertBefore(mn, wrap.firstChild);
    }
    /* 板块少的页面 ui.js 不建横向条（它按初始锚点数判断），但窄屏 / 收起左栏时
       她只有这一条能用 —— 缺了就自己建一条，标签由 syncMnav 统一填（R-554 之后
       导航变短，这种页变多了）*/
    if (!$('.mnav', wrap)) {
      const D = (typeof DATA !== 'undefined' ? DATA : {});
      const stamp = (D.meta && D.meta.stamp) ? D.meta.stamp : '';
      wrap.insertAdjacentHTML('afterbegin',
        `<nav class="mnav" aria-label="模块内跳转"><span class="mnav__sp"></span>` +
        (stamp ? `<span class="mnav__stamp">数据截止 ${stamp}</span>` : '') + `</nav>`);
    }
    return $('.l3b', wrap);
  }

  /* ── 三级条：写当前二级板块的名字 + 它下面那几格 ─────────── */
  function paintL3(sec, items, n) {
    const host = stack(sec);
    if (!host) return;
    const it = items[n];
    if (!it) { host.innerHTML = ''; host.hidden = true; return; }
    const kids = it.kids || [];
    host.hidden = false;
    host.dataset.l2 = it.el.id;
    host.innerHTML =
      `<span class="l3b__k" title="${esc(it.lbl)}"><i>${n + 1}/${items.length}</i>${it.lbl}</span>` +
      (kids.length
        ? `<span class="l3b__l">${kids.map(kd =>
            `<button class="l3b__a" data-go="${kd.go}"${kd.click ? ` data-click="${kd.click}"` : ''}
               title="${esc(kd.lbl)}">${kd.lbl}</button>`).join('')}</span>`
        : `<span class="l3b__none">这一块整块看，没有分格</span>`);
    curL2 = n;
  }

  /* 重画之后不能一律回到第 ▇▇块：按当前滚动位置算出她正看着哪一块
     （图表画完会把页面撑高、触发重画，之前就是在这儿把条打回了「本页结论」）*/
  function activeIdx(items) {
    let n = 0;
    const line = off() + 12;
    items.forEach((x, i) => {
      try { if (x.el.getBoundingClientRect().top <= line) n = i; } catch (e) {}
    });
    return n;
  }

  /* ── 画左栏：只到二级 ─────────────────────────────────── */
  function paint(force) {
    const host = $('#osnav');
    if (!host || busy) return;

    const view = document.body.dataset.view;
    const sec = view && document.getElementById(view);
    const link = view && $(`.osi[data-view="${view}"]`, host);
    const li = link && link.closest('li');
    if (!sec || !li) return clear(host);

    const items = blocks(sec);
    if (items.length < 2) return clear(host);

    /* 内容没变就一个字都不动：不重画、不重新滚动 */
    const sig = view + '|' + items.map(x => x.lbl + '#' + (x.kids || []).length + '#' + stateOf(x.el)[0]).join('~');
    const cur = $('.ossub', host);
    if (cur && cur.dataset.for === view && sig === lastSig && !force) {
      busy = true; syncMnav(sec, items); busy = false; return;
    }
    lastSig = sig;

    busy = true;
    $$('.ossub', host).forEach(e => e.remove());
    const box = document.createElement('div');
    box.className = 'ossub';
    box.dataset.for = view;
    box.setAttribute('aria-label', '本页板块直达');
    box.innerHTML =
      `<div class="ossub__h"><span>本页 ${items.length} 个板块 · 点击定位</span></div>
       <ul class="ossub__l">${items.map((x, n) => {
        const [st, tip] = stateOf(x.el);
        const k = (x.kids || []).length;
        return `<li class="ossbi">
          <button class="ossb${n === 0 ? ' is-here' : ''}" data-go="${x.el.id}"
                  title="${esc((tip ? tip + ' · ' : '') + x.lbl + (k ? `（含 ${k} 个板块，顶部提供定位条）` : ''))}">
            <i class="ossb__n">${n + 1}</i>
            <span class="ossb__t">${x.lbl}</span>
            ${k ? `<em class="ossb__k">${k}</em>` : ''}
            ${st ? `<b class="ossb__d is-${st}"></b>` : ''}
          </button></li>`;
      }).join('')}</ul>`;
    li.after(box);
    document.body.classList.add('subnav-on');
    syncMnav(sec, items);
    /* 她刚点过左栏二级（还在平滑滚动途中）：按滚动位置算会算成第 ▇▇块，
       这时以她点的那一块为准（和 hit() 里那道 lock 是同一个道理）*/
    const keep = (Date.now() < lock && curL2 >= 0) ? Math.min(curL2, items.length - 1) : -1;
    curL2 = -1;
    SEC = sec; ITEMS = items;
    fixHeroCount(sec, items.length);
    paintL3(sec, items, keep >= 0 ? keep : activeIdx(items));
    keepVisible(host, li, box);
    observe(sec, items, box);
    busy = false;
  }

  function clear(host) {
    busy = true;
    $$('.ossub', host).forEach(e => e.remove());
    document.body.classList.remove('subnav-on');
    lastSig = '';
    busy = false;
  }

  /* 顶部横幅上那个「这页几块」原来数的是 ui.js 的初始锚点（和左栏对不上），改成真实块数 */
  function fixHeroCount(sec, n) {
    try {
      const hs = $$('.mhero__meta .mh', sec);
      const hit = hs.find(h => clean(txt(h, '.mh__k')) === '本页板块');
      if (hit) { const v = $('.mh__v', hit); if (v) v.textContent = n + ' 块'; }
    } catch (e) {}
  }

  /* 横向二级条用同一套标签（窄屏 / 收起左栏时它才出现，不能两套口径） */
  function syncMnav(sec, items) {
    stack(sec);                       /* 壳和横向条都由 stack 保证存在 */
    const bar = $('.mnav', sec);
    if (!bar) return;
    const old = $$('.mnav__a', bar);
    const want = items.map(x => x.el.id + '|' + x.lbl).join('~');
    const have = old.map(b => b.dataset.go + '|' + clean(b.textContent).replace(/^\d+\s*/, '')).join('~');
    if (want === have) return;
    old.forEach(b => b.remove());
    bar.insertAdjacentHTML('afterbegin', items.map((x, n) =>
      `<button class="mnav__a${n === 0 ? ' is-here' : ''}" data-go="${x.el.id}"><i>${n + 1}</i>${x.lbl}</button>`).join(''));
  }

  /* 左栏是可滚的，板块清单长出来后不许被挤到看不见的地方 */
  function keepVisible(host, li, box) {
    try {
      const hb = host.getBoundingClientRect();
      const lb = li.getBoundingClientRect();
      if (lb.top < hb.top + 4 || lb.top > hb.bottom - 40) {
        host.scrollTop += lb.top - hb.top - 6;
      } else {
        const bb = box.getBoundingClientRect();
        const over = Math.min((bb.bottom + 8) - hb.bottom, lb.top - hb.top - 6);
        if (over > 0) host.scrollTop += over;
      }
    } catch (e) {}
  }

  /* 滚到哪一块：左栏 + 横向条一起亮，顶部三级条换成这一块的分格 */
  function observe(sec, items, box) {
    if (io) { io.disconnect(); io = null; }
    const l2 = $$('.ossb', box);
    const bar = $$('.mnav__a', sec);
    const idx = {};
    items.forEach((x, n) => {
      idx[x.el.id] = n;
      (x.kids || []).forEach(kd => { if (kd.obs) idx[kd.go] = n; });
    });

    const hit = id => {
      if (Date.now() < lock) return;
      const n = idx[id];
      if (n == null) return;
      const pid = items[n].el.id;
      l2.forEach(b => b.classList.toggle('is-here', b.dataset.go === pid));
      bar.forEach(b => b.classList.toggle('is-here', b.dataset.go === pid));
      if (n !== curL2) { busy = true; paintL3(sec, items, n); busy = false; }
      /* 三级条上高亮当前那一格 */
      const host = $('.l3b', sec);
      if (host) $$('.l3b__a', host).forEach(b => b.classList.toggle('is-here', b.dataset.go === id));
    };

    io = new IntersectionObserver(es => {
      es.forEach(en => { if (en.isIntersecting) hit(en.target.id); });
    }, { rootMargin: '-132px 0px -62% 0px', threshold: 0 });
    items.forEach(x => {
      io.observe(x.el);
      (x.kids || []).forEach(kd => { if (kd.obs) io.observe(kd.obs); });
    });
  }

  /* 目标被收进折叠说明区里的话，先展开再滚 —— 否则点了「现在就做这一件」
     会滚到一条收起的横杠上，看着像没反应（R-554 配套）*/
  function openUp(el) {
    let p = el;
    while (p && p !== document.body) {
      if (p.tagName === 'DETAILS' && !p.open) p.open = true;
      p = p.parentElement;
    }
  }

  function goto(id, flash) {
    const t = document.getElementById(id);
    if (!t) return;
    openUp(t);
    const to = () => Math.max(t.getBoundingClientRect().top + window.scrollY - off(), 0);
    window.scrollTo({ top: to(), behavior: 'smooth' });
    /* 图表这类是露出来才画的，画完页面会变高 —— 滚完再校一次，别把她放偏 */
    let n = 0;
    const fix = () => {
      const want = to();
      if (Math.abs(want - window.scrollY) > 24) window.scrollTo({ top: want, behavior: 'auto' });
      if (++n < 3) setTimeout(fix, 420);
    };
    setTimeout(fix, 520);
    if (!flash) return;
    t.classList.remove('is-subflash'); void t.offsetWidth; t.classList.add('is-subflash');
  }

  /* 点了哪一块，三级条就写哪一块（并把左栏 / 横向条的高亮一起挪过去） */
  function focusL2(id) {
    if (!SEC || !ITEMS.length) return;
    const n = ITEMS.findIndex(x => x.el.id === id);
    if (n < 0) return;
    lock = Date.now() + 1200;
    busy = true;
    paintL3(SEC, ITEMS, n);
    $$('.ossb').forEach(b2 => b2.classList.toggle('is-here', b2.dataset.go === id));
    $$('.mnav__a', SEC).forEach(b2 => b2.classList.toggle('is-here', b2.dataset.go === id));
    busy = false;
  }

  /* ── 跳转收口：三级条 / 左栏二级 / 横向二级 / 结论条 / 「去做」 ── */
  function wireJumps() {
    document.addEventListener('click', e => {
      /* 三级条：先切页签（图表那类），再滚过去 */
      const k3 = e.target.closest('.l3b__a[data-go]');
      if (k3) {
        e.preventDefault();
        if (k3.dataset.click) { const t = document.getElementById(k3.dataset.click); if (t) t.click(); }
        goto(k3.dataset.go, 1);
        return;
      }

      /* 二级：左栏 + 横向条。点了就立刻把三级条换成这一块，别等滚动结束 */
      const sb = e.target.closest('.ossb[data-go], .mnav__a[data-go]');
      if (sb) { e.preventDefault(); focusL2(sb.dataset.go); goto(sb.dataset.go); return; }

      /* 结论条：滚到本页真正能动手的那一块（选择器由 SUM 的 act 指定） */
      const blk = e.target.closest('[data-goblk]');
      if (blk) {
        e.preventDefault();
        const sec = blk.closest('.sec');
        const sel = blk.dataset.goblk || '.mxb--do';
        const t = sec && ($(sel, sec) || $('.mxb--do', sec));
        if (t) { if (!t.id) t.id = sec.id + '-blk' + Math.abs(sel.split('').reduce((a, c) => a + c.charCodeAt(0), 0)); goto(t.id, 1); }
        return;
      }

      /* 结论条：外链新窗口 */
      const nt = e.target.closest('[data-newtab]');
      if (nt) { e.preventDefault(); window.open(nt.dataset.newtab, '_blank', 'noopener'); return; }

      /* 「去做 →」：以前 href="#base" 只改 URL 不切页，这里接到视图路由上 */
      const go = e.target.closest('.mxgo[href^="#"]');
      if (go) {
        const id = go.getAttribute('href').slice(1);
        if (!id) return;
        e.preventDefault();
        if (window.OS && OS.BY && OS.BY[id]) { OS.show(id); return; }
        const el = document.getElementById(id);
        if (el) { window.OS && OS.reveal && OS.reveal(id); goto(id, 1); }
      }
    });
  }

  /* ── 启动 ─────────────────────────────────────────────── */
  function boot() {
    paint();
    wireJumps();

    /* 切模块就重画。
       ⚠️ 2026-09-14 修的一个隐蔽 bug：把 data-view 写成同一个值也会产生 MutationRecord，
       而页面滚动时别处会反复回写 body.dataset.view —— 于是每次滚动都触发一次
       paint(1)，把三级条打回第 ▇▇块。表现就是"点左栏大类，三级条闪一下又跳回本页结论"。
       所以这里只在值真的变了时才重画。 */
    let lastView = document.body.dataset.view || '';
    new MutationObserver(() => {
      const v = document.body.dataset.view || '';
      if (v === lastView) return;
      lastView = v;
      paint(1);
    }).observe(document.body, { attributes: true, attributeFilter: ['data-view'] });

    /* 内容变了（提交完一件等你定、装了新卡）标签与状态点要跟着变；
       自己写的那三处（横向条 / 左栏 / 三级条）要排除掉，否则自己触发自己 */
    let t = 0;
    new MutationObserver(recs => {
      if (busy) return;
      const real = recs.some(r => {
        const n = r.target;
        return !(n && n.closest && (n.closest('.mnav') || n.closest('.ossub') || n.closest('.stk')));
      });
      if (!real) return;
      clearTimeout(t); t = setTimeout(() => paint(), 300);
    }).observe($('#sections') || document.body, { childList: true, subtree: true });
  }

  return { boot, paint, goto, focusL2, blocks, SPEC };
})();

(function () {
  const go = () => { try { SUBNAV.boot(); } catch (e) { console.warn('subnav', e); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go);
  else go();
})();
