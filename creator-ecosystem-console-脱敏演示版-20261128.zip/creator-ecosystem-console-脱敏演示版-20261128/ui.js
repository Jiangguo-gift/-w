/* ═══════════════════════════════════════════════════════════════════
   ui.js —— 达人生态 OS · 精修层行为（v12）
   载入顺序：… → mod.js → ui.js → render.js
   （render.js 里的 mount() 是同步执行的，所以本文件的 DOM 增强
     全部挂在 DOMContentLoaded 上，保证跑在 mount() 之后）
   ───────────────────────────────────────────────────────────────────
   只做四件事，不改任何业务口径、不新增任何没有来源的数字：
     ① 图标：把 unicode 占位换成统一描边 SVG
     ② 外壳：顶栏收成「一眼 + 更多」、侧栏在窄屏变抽屉、键盘可达
     ③ 驾驶舱：把装饰 Hero 换成「今天要动的事 + 快捷入口」
     ④ 可视化：业务基本盘里三张 Q3 收口图（数据全部来自已标源的业务底表）
   ═══════════════════════════════════════════════════════════════════ */

/* ── 图标表：▇▇ 视框，1.6px 描边，全站唯一一套 ───────────── */
window.ICONS = (function () {
  const P = {
    menu: 'M4 7h16M4 12h16M4 17h16',
    search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM16.5 16.5 21 21',
    dots: 'M6 12h.01M12 12h.01M18 12h.01',
    flag: 'M6 3v18M6 4h11l-2 4 2 4H6',
    grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
    spark: 'M12 3l1.7 4.5L18 9.2l-4.3 1.7L12 15.5l-1.7-4.6L6 9.2l4.3-1.7zM18.5 15.5l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z',
    bulb: 'M9.5 18h5M10.5 21h3M12 3a6 6 0 0 0-3.4 10.9V16h6.8v-2.1A6 6 0 0 0 12 3z',
    pen: 'M4 20l4.2-1L19 8.2 15.8 5 5 15.8zM14.6 6.2l3.2 3.2',
    diamond: 'M12 3l9 9-9 9-9-9z',
    db: 'M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6',
    target: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 11.5v.01',
    layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5',
    gear: 'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM12 2.5v3M12 18.5v3M4.6 7l2.6 1.5M16.8 15.5l2.6 1.5M4.6 17l2.6-1.5M16.8 8.5l2.6-1.5',
    shuffle: 'M3 8h7l4 8h7M18 4l3 4-3 4M18 12l3 4-3 4',
    globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.7 3 2.7 15 0 18M12 3c-2.7 3-2.7 15 0 18',
    bars: 'M3 20h18M7 20v-5.5M12 20V8M17 20v-9',
    arrow: 'M5 12h13M13 6l6 6-6 6',
    check: 'M4 12.5l5 5L20 6.5',
    bolt: 'M13 3L5 14h5.5L9.5 21 19 10h-6z',
    info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v5M12 8v.01',
    inbox: 'M3 12h5l1.5 3h5L16 12h5M5 5h14l2 7v6H3v-6z',
    clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7.5V12l3 2',
    link: 'M10 13a4 4 0 0 0 5.7 0l2.3-2.3A4 4 0 0 0 12.3 5L11 6.3M14 11a4 4 0 0 0-5.7 0L6 13.3A4 4 0 0 0 11.7 19L13 17.7',
    x: 'M6 6l12 12M18 6L6 18',
    plus: 'M12 5.5v13M5.5 12h13'
  };
  function svg(n, cls) {
    const d = P[n];
    if (!d) return '';
    return `<svg class="ic${cls ? ' ' + cls : ''}" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="${d}"/></svg>`;
  }
  /* 视图 → 图标 */
  const V = {
    deck: 'grid', evo: 'spark', advice: 'bulb', spark: 'pen',
    pattern: 'diamond', memory: 'db', premise: 'target',
    state: 'layers', cap: 'gear', mech: 'shuffle', confirm: 'flag',
    eco: 'globe', base: 'bars'
  };
  return { svg, P, V };
})();

/* ═══════════════════════════════════════════════════════════════════
   可视化：三张图，全部手写 SVG，按容器真实像素渲染（不缩字）
   ⚠️ 数据纪律：这里每一个数都来自已标注来源的业务底表，
      口径与截止日一起显示，不新造、不外推。
   ═══════════════════════════════════════════════════════════════════ */
window.VIZ = (function () {

  const TABS = [
    {
      id: 'month', n: '月度收口趋势', kind: 'column',
      title: 'Q3 已结算 GMV 连续三个月抬升',
      sub: '▇▇—9 月按客户结算日期汇总，仅作为 Q3 历史收口基线；Q4 当前盘面与结算口径见本页上方飞书主表刷新区。',
      max: 100, step: 25, suffix: '万',
      rows: [
        { n: '7 月', v: 42.35, note: 'Q3 月度起点', tone: 'muted' },
        { n: '8 月', v: 61.48, note: '较 7 月增加 ▇▇万', tone: 'brand' },
        { n: '9 月', v: 78.92, note: '较 8 月增加 ▇▇万', tone: 'ok' }
      ],
      legend: [
        { tone: 'muted', t: '7 月' }, { tone: 'brand', t: '8 月' }, { tone: 'ok', t: '9 月' }
      ],
      read: '<b>历史基线</b>：Q3 已结算 GMV 为 <b>▇▇万</b>，对 ▇▇万目标达成 <b>▇▇</b>；▇▇—9 月逐月抬升。<b>Q4 盘面已于 2026-11-06 按飞书主表 rev▇▇ 全量重读（发单/结算截止 11-05）</b>，正式结算 ▇▇万、发单 ▇▇万分栏看，订单状态“已完成”不直接等同到账。',
      src: '来源：飞书表《本季度业务合作情况》 · 口径 = 客户结算日期落在 2026-Q3 的已结算 GMV · 数据截止 2026-09-30'
    },
    {
      id: 'industry', n: '行业结构', kind: 'hbar',
      title: '美妆、汽车、3C 合计贡献 ▇▇',
      sub: '横条展示 Q3 已结算 GMV。前三行业是主盘，其他行业合并展示，避免用零散长尾掩盖核心结构。',
      max: 100, step: 25, suffix: '万',
      rows: [
        { n: '美妆', v: 36.20, note: '占 Q3 已结算 GMV ▇▇', tone: 'brand' },
        { n: '汽车', v: 28.40, note: '占 Q3 已结算 GMV ▇▇', tone: 'brand' },
        { n: '3C', v: 18.60, note: '占 Q3 已结算 GMV ▇▇', tone: 'brand' },
        { n: '其他行业', v: 16.80, note: '其余行业合计，占 ▇▇', tone: 'muted' }
      ],
      legend: [
        { tone: 'brand', t: '核心三行业' }, { tone: 'muted', t: '其他行业合计' }
      ],
      read: '<b>结论</b>：核心三行业贡献 <b>▇▇</b>，已形成清晰主盘。Q4 不能只追总量，要同时看核心行业能否延续、长尾行业是否形成第二增长曲线。',
      src: '来源：飞书表《本季度业务合作情况》 · 口径 = 2026-Q3 已结算 GMV 按行业汇总；其他行业为总额减前三行业 · 数据截止 2026-09-30'
    },
    {
      id: 'concentration', n: '集中度风险', kind: 'hbar',
      title: '增长收口漂亮，但结构依赖仍然偏重',
      sub: '三条横条分别看机构、合作类型和行业集中度。它们不是达成率，越接近 ▇▇ 代表越依赖单一来源。',
      max: 100, step: 25, suffix: '%',
      rows: [
        { n: 'TOP1 机构', v: 46.20, note: '客户A ▇▇万，占 Q3 已结算 GMV ▇▇', tone: 'warn' },
        { n: '指派任务', v: 72.50, note: '指派任务 ▇▇万，占 Q3 已结算 GMV ▇▇', tone: 'bad' },
        { n: 'TOP3 行业', v: 58.80, note: '美妆、汽车、3C 合计占 ▇▇', tone: 'warn' }
      ],
      legend: [
        { tone: 'warn', t: '集中度较高' }, { tone: 'bad', t: '高度集中' }
      ],
      read: '<b>Q4 优先动作</b>：先接入新季度数据；机构侧不把“降低 TOP1 占比”硬设成增长目标，而是用<b>客户J与 客户I</b>分别试两类资源形态；合作侧用授权费、素材后链路与达人团跑出非指派样本。',
      src: '来源：飞书表《本季度业务合作情况》 · 口径 = 2026-Q3 已结算 GMV 的机构 / 任务类型 / 行业集中度 · 数据截止 2026-09-30'
    }
  ];

  /* 图表专用色：比壳里的信号色低一档饱和度，长时间看不刺眼 */
  const TONE = {
    ok:    ['#0E9F6E', '#31C48D'],
    brand: ['#5B3CE6', '#8B74FF'],
    muted: ['#64748B', '#A8B2C1'],
    warn:  ['#D97706', '#F5A524'],
    bad:   ['#E11D6F', '#F472A6']
  };
  const COLOR = {
    ok: 'url(#vzOk)', brand: 'url(#vzBrand)', muted: 'url(#vzMuted)',
    warn: 'url(#vzWarn)', bad: 'url(#vzBad)'
  };
  const FLAT = {
    ok: TONE.ok[0], brand: TONE.brand[0], muted: TONE.muted[0],
    warn: TONE.warn[0], bad: TONE.bad[0]
  };
  /* dir: 'v' 竖条从上往下渐变，'h' 横条从左往右 */
  function defs(dir) {
    const p = dir === 'v' ? 'x1="0" y1="0" x2="0" y2="1"' : 'x1="0" y1="0" x2="1" y2="0"';
    return '<defs>' + Object.keys(TONE).map(k => {
      const id = 'vz' + k.charAt(0).toUpperCase() + k.slice(1);
      const c = TONE[k];
      return `<linearGradient id="${id}" ${p}>
        <stop offset="0" stop-color="${dir === 'v' ? c[1] : c[0]}"/>
        <stop offset="1" stop-color="${dir === 'v' ? c[0] : c[1]}"/>
      </linearGradient>`;
    }).join('') + '</defs>';
  }

  let cur = 'month';

  function block() {
    return `<section class="viz" data-mod="mx-viz" id="vizbox">
      <div class="viz__hd">
        <h3 class="viz__t">${ICONS.svg('bars')}Q3 收口结构图</h3>
        <p class="viz__s">只画已经结算、能够追溯的 Q3 数据。切换看月度趋势、行业结构和集中度风险；<b>悬停条形或用 Tab 键聚焦，可查看明细与口径</b>。</p>
      </div>
      <div class="viz__tabs" role="tablist" aria-label="切换视图">
        ${TABS.map(t => `<button class="viz__tab" role="tab" id="vzt-${t.id}"
          aria-controls="vizBody" aria-selected="${t.id === cur}" data-vz="${t.id}"
          tabindex="${t.id === cur ? 0 : -1}">${t.n}</button>`).join('')}
      </div>
      <div class="viz__body" id="vizBody" role="tabpanel"></div>
      <div class="viz__legend" id="vizLegend"></div>
      <div class="viz__read" id="vizRead"></div>
      <div class="viz__src" id="vizSrc"></div>
      <div class="viz__tblwrap" id="vizTbl"></div>
    </section>`;
  }

  /* ── 画图：按容器真实宽度出图，字号不随缩放走形 ─────── */
  function draw() {
    const body = document.getElementById('vizBody');
    if (!body) return;
    const t = TABS.filter(x => x.id === cur)[0];
    const W = Math.max(300, Math.round(body.clientWidth || 720));
    const html = t.kind === 'column' ? column(t, W) : hbar(t, W);
    body.innerHTML = `<div class="viz__ctx"><h4>${esc(t.title)}</h4><p>${esc(t.sub)}</p></div>
      <div class="viz__tip" id="vizTip" role="status" aria-live="polite"></div>${html}`;
    document.getElementById('vizRead').innerHTML = t.read;
    document.getElementById('vizSrc').textContent = t.src;
    document.getElementById('vizLegend').innerHTML = legend(t);
    document.getElementById('vizTbl').innerHTML = table(t);
    hover(body);
  }

  function legend(t) {
    return (t.legend || []).map(x =>
      `<span><i style="background:${FLAT[x.tone] || FLAT.brand}"></i>${x.t}</span>`
    ).join('');
  }

  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const pack = o => encodeURIComponent(JSON.stringify(o));

  const fmt = v => Number(v).toLocaleString('zh-CN', { maximumFractionDigits: 2 });

  /* 横条：行业规模 / 集中度 */
  function hbar(t, W) {
    const narrow = W < 560;
    const L = narrow ? 74 : 96, R = narrow ? 54 : 104, H = t.rows.length * 58 + 46;
    const iw = W - L - R;
    const x = v => L + (v / t.max) * iw;
    let grid = '';
    for (let i = 0; i <= t.max; i += t.step) grid += `<line class="vgrid" x1="${x(i)}" y1="24" x2="${x(i)}" y2="${H - 22}"/>
      <text class="vx" x="${x(i)}" y="${H - 6}" text-anchor="middle">${fmt(i)}${t.suffix}</text>`;
    const bars = t.rows.map((r, i) => {
      const y = 32 + i * 58;
      const w = Math.max(2, x(r.v) - L), c = COLOR[r.tone] || COLOR.brand;
      const tipv = `<em>${fmt(r.v)}${t.suffix}</em><br><i>${r.note}</i>`;
      return `<g class="vbar" tabindex="0" role="img" data-tip="${pack({ t: r.n, b: tipv })}"
          data-cx="${x(r.v)}" data-cy="${y}" aria-label="${esc(r.n)} ${fmt(r.v)}${t.suffix}，${esc(r.note)}">
        <rect x="${L}" y="${y}" width="${iw}" height="34" fill="transparent"/>
        <text class="vlab" x="${L - 12}" y="${y + 22}" text-anchor="end">${r.n}</text>
        <rect class="vgrow" x="${L}" y="${y + 7}" width="${w}" height="20" rx="5" fill="${c}"/>
        <text class="vnum${w > 78 ? ' vnum--in' : ''}" x="${w > 78 ? x(r.v) - 9 : x(r.v) + 8}" y="${y + 22}"
          text-anchor="${w > 78 ? 'end' : 'start'}">${fmt(r.v)}${t.suffix}</text>
      </g>`;
    }).join('');
    return `<svg class="viz__plot" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
      ${defs('h')}${grid}${bars}
    </svg>`;
  }

  /* 竖条：月度收口趋势 */
  function column(t, W) {
    const B = 54, T = 28, H = 294, AX = 54;
    const gap = Math.max(18, Math.min(52, W * .055));
    const iw = W - AX - 16;
    const bw = Math.min(132, (iw - gap * (t.rows.length - 1)) / t.rows.length);
    const step = bw + gap;
    const x0 = AX + Math.max(0, (iw - (step * t.rows.length - gap)) / 2);
    const y = v => H - B - (v / t.max) * (H - B - T);
    let grid = '';
    for (let i = 0; i <= t.max; i += t.step) grid += `<line class="vgrid" x1="${AX}" y1="${y(i)}" x2="${W - 8}" y2="${y(i)}"/>
      <text class="vx" x="${AX - 9}" y="${y(i) + 4}" text-anchor="end">${fmt(i)}${t.suffix}</text>`;
    const bars = t.rows.map((r, i) => {
      const bx = x0 + i * step, c = COLOR[r.tone] || COLOR.brand;
      const h = Math.max(3, H - B - y(r.v));
      const tipv = `<em>${fmt(r.v)}${t.suffix}</em><br><i>${r.note}</i>`;
      return `<g class="vbar" tabindex="0" role="img" data-tip="${pack({ t: r.n, b: tipv })}"
          data-cx="${bx + bw / 2}" data-cy="${y(r.v) - 6}" aria-label="${esc(r.n)} ${fmt(r.v)}${t.suffix}，${esc(r.note)}">
        <rect x="${bx}" y="${T - 12}" width="${bw}" height="${H - B - T + 12}" fill="transparent"/>
        <rect class="vgrowv" x="${bx}" y="${y(r.v)}" width="${bw}" height="${h}" rx="7" fill="${c}"/>
        <text class="vnum" x="${bx + bw / 2}" y="${y(r.v) - 9}" text-anchor="middle">${fmt(r.v)}${t.suffix}</text>
        <text class="vlab" x="${bx + bw / 2}" y="${H - B + 24}" text-anchor="middle">${r.n}</text>
      </g>`;
    }).join('');
    return `<svg class="viz__plot" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
      ${defs('v')}${grid}${bars}
    </svg>`;
  }

  /* 打印 / 读屏兜底：同一份数据的表格 */
  function table(t) {
    return `<table class="viz__tb"><caption>${esc(t.title)}</caption>
      <thead><tr><th>项</th><th>数值</th><th>说明</th></tr></thead>
      <tbody>${t.rows.map(r => `<tr><td>${esc(r.n)}</td>
        <td>${fmt(r.v)}${t.suffix}</td>
        <td>${esc(r.note || '')}</td></tr>`).join('')}</tbody></table>
      <p>${esc(t.src)}</p>`;
  }

  /* hover / focus 读数 */
  function hover(body) {
    const tip = document.getElementById('vizTip');
    const plot = body.querySelector('.viz__plot');
    if (!tip || !plot) return;
    const show = g => {
      let d; try { d = JSON.parse(decodeURIComponent(g.dataset.tip)); } catch (e) { return; }
      tip.innerHTML = `<b>${d.t}</b>${d.b}`;
      const bx = body.getBoundingClientRect(), gr = g.getBoundingClientRect();
      const off = plot.getBoundingClientRect().left - bx.left;
      const raw = (+g.dataset.cx || 0) + off;
      const cx = Math.min(bx.width - 108, Math.max(108, raw));
      tip.style.left = cx + 'px';
      tip.style.top = (gr.top - bx.top + 10) + 'px';
      tip.classList.add('is-on');
      plot.classList.add('is-dim');
      plot.querySelectorAll('.vbar').forEach(b => b.classList.toggle('is-hot', b === g));
    };
    const hide = () => {
      tip.classList.remove('is-on');
      plot.classList.remove('is-dim');
      plot.querySelectorAll('.vbar').forEach(b => b.classList.remove('is-hot'));
    };
    plot.querySelectorAll('.vbar').forEach(g => {
      g.addEventListener('mouseenter', () => show(g));
      g.addEventListener('focus', () => show(g));
      g.addEventListener('mouseleave', hide);
      g.addEventListener('blur', hide);
    });
    plot.addEventListener('mouseleave', hide);
  }

  function wire() {
    const box = document.getElementById('vizbox');
    if (!box) return;
    const tabs = [...box.querySelectorAll('.viz__tab')];
    const sel = id => {
      cur = id;
      tabs.forEach(t => {
        const on = t.dataset.vz === id;
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        t.tabIndex = on ? 0 : -1;
      });
      const p = document.getElementById('vizBody');
      if (p) p.setAttribute('aria-labelledby', 'vzt-' + id);
      draw();
    };
    tabs.forEach((t, i) => {
      t.addEventListener('click', () => sel(t.dataset.vz));
      t.addEventListener('keydown', e => {
        const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
        if (!d) return;
        e.preventDefault();
        const n = tabs[(i + d + tabs.length) % tabs.length];
        n.focus(); sel(n.dataset.vz);
      });
    });
    draw();
    let tmr;
    window.addEventListener('resize', () => { clearTimeout(tmr); tmr = setTimeout(draw, 160); });

    /* 页面隐藏时 clientWidth 是 ▇▇，画出来会被缩成一张小图。
       所以：容器宽度一变（含从隐藏变可见）就按真实宽度重画一次。 */
    const body = document.getElementById('vizBody');
    if (body && window.ResizeObserver) {
      let last = 0;
      new ResizeObserver(() => {
        const w = body.clientWidth;
        if (!w || Math.abs(w - last) < 8) return;
        last = w; clearTimeout(tmr); tmr = setTimeout(draw, 60);
      }).observe(body);
    }
  }

  return { block, wire, draw, TABS };
})();

/* ═══════════════════════════════════════════════════════════════════
   外壳精修：图标 / 顶栏 / 侧栏 / 驾驶舱首屏 / 模块内锚点条
   ═══════════════════════════════════════════════════════════════════ */
window.UIX = (function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
  const ic = (n, c) => ICONS.svg(n, c);

  /* ── ▇▇. 键盘落点 ─────────────────────────────────── */
  function skip() {
    const a = document.createElement('a');
    a.className = 'skip'; a.href = '#sections'; a.textContent = '跳到本页内容';
    document.body.insertBefore(a, document.body.firstChild);
    const s = $('#sections'); if (s) s.setAttribute('tabindex', '-1');
  }

  /* ── ▇▇. 图标替换：unicode 让位 ─────────────────────── */
  function icons() {
    const fold = $('#osFold');
    if (fold) { fold.innerHTML = ic('menu'); fold.setAttribute('aria-label', '收起 / 展开侧栏'); }
    $$('.osi').forEach(a => {
      const box = $('.osi__ic', a);
      if (box) box.innerHTML = ic(ICONS.V[a.dataset.view] || 'grid');
    });
    const pal = $('#palBtn');
    if (pal) pal.innerHTML = ic('search') + '搜索<span class="tbtn__kbd">⌘K</span>';
    /* 模块四块的小标题 */
    $$('.mx__k').forEach(e => { if (!$('svg', e)) e.insertAdjacentHTML('afterbegin', ic('spark', 'ic--sm')); });
    $$('.mxb--can .mxb__h').forEach(e => { if (!$('svg', e)) e.insertAdjacentHTML('afterbegin', ic('bolt', 'ic--sm')); });
    $$('.mxb--do .mxb__h').forEach(e => { if (!$('svg', e)) e.insertAdjacentHTML('afterbegin', ic('check', 'ic--sm')); });
    $$('.mxk__h').forEach(e => { if (!$('svg', e)) e.insertAdjacentHTML('afterbegin', ic('info', 'ic--sm')); });
    $$('.mxask__h').forEach(e => { if (!$('svg', e)) e.insertAdjacentHTML('afterbegin', ic('flag', 'ic--sm')); });
    $$('.mxcmd__h').forEach(e => { if (!$('svg', e)) e.insertAdjacentHTML('afterbegin', ic('inbox', 'ic--sm')); });
    $$('.mxgo').forEach(e => {
      if ($('svg', e)) return;
      e.textContent = e.textContent.replace(/[→↗➤\s]+$/, '');   /* 文字箭头交给图标，不重复 */
      e.insertAdjacentHTML('beforeend', ic('arrow', 'ic--sm'));
    });
  }

  /* ── ▇▇. 顶栏：一眼能看的留下，工具收进「更多」 ────── */
  function topbar() {
    const right = $('.topbar__right');
    if (!right) return;
    const pend = document.createElement('button');
    pend.className = 'tpend'; pend.id = 'tPend';
    pend.setAttribute('data-jumpv', 'confirm');
    right.insertBefore(pend, right.firstChild);

    const more = document.createElement('div');
    more.className = 'tmore';
    more.innerHTML = `<button class="tbtn" id="tMoreBtn" aria-expanded="false" aria-haspopup="true">${ic('dots')}更多</button>
      <div class="tpop" id="tPop" role="menu">
        <div class="tpop__r"><span class="tpop__k">看多少</span><div id="slotDens"></div></div>
        <div class="tpop__r"><span class="tpop__k">只看什么</span><div id="slotFilters"></div></div>
        <div class="tpop__r"><span class="tpop__k">动手</span><div class="tpop__btns" id="slotBtns"></div></div>
      </div>`;
    right.appendChild(more);

    const mv = (sel, into) => { const e = $(sel), t = $(into); if (e && t) t.appendChild(e); };
    mv('#dens', '#slotDens');
    mv('#filters', '#slotFilters');
    mv('#editToggle', '#slotBtns');
    mv('#queueBtn', '#slotBtns');
    mv('#patchBtn', '#slotBtns');

    const btn = $('#tMoreBtn'), pop = $('#tPop');
    const close = () => { pop.classList.remove('is-open'); btn.setAttribute('aria-expanded', 'false'); };
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const on = pop.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', on ? 'true' : 'false');
    });
    document.addEventListener('click', e => { if (!more.contains(e.target)) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
    paintPend();
  }

  /* 等你定 N —— 顶栏唯一的数字，口径和反馈抽屉一致 */
  function paintPend() {
    const el = $('#tPend');
    if (!el) return;
    const all = window.ASKS || [];
    const left = (window.FB && FB.answerOf) ? all.filter(a => !FB.answerOf(a.id)).length : all.length;
    el.innerHTML = ic('flag', 'ic--sm') + (left ? `等你定 <b>${left}</b>` : '没有等你定的');
    el.classList.toggle('is-zero', !left);
    el.setAttribute('aria-label', left ? `等你定 ${left} 件，去重要事项确认页` : '没有等你定的事');
  }

  /* ── ▇▇. 窄屏：侧栏变抽屉 ──────────────────────────── */
  function drawerNav() {
    const s = document.createElement('div');
    s.className = 'scrim'; s.id = 'navScrim';
    document.body.appendChild(s);
    const isNarrow = () => window.matchMedia('(max-width:1180px)').matches;
    const closeNav = () => document.body.classList.remove('nav-on');
    s.addEventListener('click', closeNav);
    /* 抽屉一打开就把「你现在在哪一项」滚到中间，▇▇个入口不用自己找 */
    const showHere = () => {
      const on = $('.osi.is-on'), nav = $('.osnav');
      if (!on || !nav) return;
      /* 当前项本来就看得见就别动，否则第一组会被滚出视野 */
      if (on.offsetTop + on.offsetHeight <= nav.clientHeight - 8) { nav.scrollTop = 0; return; }
      nav.scrollTop = Math.max(0, on.offsetTop - nav.clientHeight / 2 + on.offsetHeight / 2);
    };
    const fold = $('#osFold');
    if (fold) fold.addEventListener('click', () => {
      if (!isNarrow()) return;
      document.body.classList.toggle('nav-on');
      document.body.classList.remove('nav-off');
      if (document.body.classList.contains('nav-on')) setTimeout(showHere, 60);
    });
    $('#osnav')?.addEventListener('click', e => { if (e.target.closest('[data-view]') && isNarrow()) closeNav(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeNav(); });
    const rail = $('#rail'); if (rail) rail.setAttribute('aria-label', '模块导航');

    /* 渐隐只在真的还能滚的那一侧出现，否则第一组会莫名变浅 */
    const nav = $('.osnav');
    if (nav) {
      const mark = () => {
        nav.dataset.up = nav.scrollTop > 6 ? '1' : '0';
        nav.dataset.dn = (nav.scrollHeight - nav.clientHeight - nav.scrollTop) > 6 ? '1' : '0';
      };
      nav.addEventListener('scroll', mark, { passive: true });
      window.addEventListener('resize', mark);
      mark(); setTimeout(mark, 200);
      if (fold) fold.addEventListener('click', () => setTimeout(mark, 120));
    }
  }

  /* 模块锚点条：横向还能滑的时候才在右边渐隐 */
  function mnavFade() {
    const marks = [];
    $$('.mnav').forEach(bar => {
      const mark = () => {
        if (!bar.clientWidth) return;            /* 页面隐藏时量不准，等它显示再量 */
        bar.dataset.dn = (bar.scrollWidth - bar.clientWidth - bar.scrollLeft) > 6 ? '1' : '0';
      };
      marks.push(mark);
      bar.addEventListener('scroll', mark, { passive: true });
      mark();
    });
    const all = () => marks.forEach(m => m());
    window.addEventListener('resize', all);
    setTimeout(all, 220);
    /* 切模块之后新露出来的那条也要重新量 */
    if (window.OS && OS.show) {
      const o = OS.show;
      OS.show = function () { const r = o.apply(this, arguments); setTimeout(all, 80); return r; };
    }
    return all;
  }

  /* ── ▇▇. 驾驶舱首屏：装饰让位给入口 ─────────────────
     ⛔ 这里一个业绩数字都不放。缺口 / 待结算只在下面那块只读摘要里，
        拆单、改数一律去「我的业务基本盘」。 */
  const QUICK = [
    { i: 'link', t: '商机 × 达人 × 策划作战台', d: '今天能提报的已置顶', u: 'https://app.internal.example/' },
    { i: 'bars', t: '我的业务基本盘', d: '看板 · 数据源 · 七条动作', v: 'base' },
    { i: 'flag', t: '重要事项确认', d: '等你定的 · 我没照字面做的', v: 'confirm' },
    { i: 'globe', t: '「外部大盘」', d: '外部趋势与可打的市场机会', v: 'eco' }
  ];
  function hero() {
    const box = $('#hero');
    if (!box) return;
    box.innerHTML = `<div class="deckp">
      <div class="dpanel">
        <div class="dpanel__h">${ic('target')}今天从哪儿开始<em>驾驶舱只汇总，动手在各板块</em></div>
        <div class="dquick">
          ${QUICK.map(q => `<button class="dquick__i" ${q.v ? `data-jumpv="${q.v}"` : `data-open="${q.u}"`}>
            ${ic(q.i)}<span>${q.t}<em>${q.d}</em></span>
          </button>`).join('')}
        </div>
      </div>
      <div class="hero__blk" id="mastBlock"></div>
    </div>`;
    $$('[data-open]', box).forEach(b => b.addEventListener('click', () => window.open(b.dataset.open, '_blank', 'noopener')));
  }

  /* ── ▇▇. 模块内锚点条：长页面里知道自己在第几块 ────── */
  /* 标签一律用「像标题的标题词」（2026-09-13 她的第二轮返工意见）：
     禁止用句子当标签，也禁止用「这个模块给你什么」这种框架壳名。
     这份表只在 sub.js 还没接管前用一次，两处口径必须一致。 */
  const ANCH = [
    ['.mxsum', '本页结论'],
    /* 模块定位 / 已具备能力 / 可执行动作 / 能力评价与短板 已收进折叠说明区，
       不再作为二级标题出现（她 09-13 第四轮圈选 / R-554）；
       拜访快记 · 常用入口 · 未照字面执行 也一并退出导航（页面上留着）。 */
    ['.mxk', '重要信息汇总'],
    ['.bizs', '业绩数据总览'],
    ['.pano', '各板块要点'],
    ['.mem', '记忆库清单'],
    ['.thk', '决策习惯'],
    ['.gl', '成长与能力'],
    ['.rv', '本周策略回顾'],
    ['#vizbox', '季度结构分析'],
    ['.bzv', '经营总判断'],
    ['#bzboards', '业绩看板总览'],
    ['#bzsrc', '数据底仓'],
    ['.hub', '「我能装的技能」'],
    ['.mxask', '等你定的事项'],
    ['.mxcmd', '「常用指令模板」'],
    ['.dnl', '已定事项']
  ];
  function mnavs() {
    const D = (typeof DATA !== 'undefined' ? DATA : {});
    const stamp = (D.meta && D.meta.stamp) ? D.meta.stamp : '';
    $$('.sec').forEach(sec => {
      const head = $('.sec__head', sec);
      if (!head) return;
      const items = ANCH
        .map(([sel, lbl], i) => ({ el: $(sel, sec), lbl, i }))
        .filter(x => x.el);
      if (items.length < 2) return;
      items.forEach(x => { if (!x.el.id) x.el.id = sec.id + '-a' + x.i; });
      const bar = document.createElement('nav');
      bar.className = 'mnav';
      bar.setAttribute('aria-label', '模块内跳转');
      bar.innerHTML = items.map((x, n) =>
        `<button class="mnav__a${n === 0 ? ' is-here' : ''}" data-go="${x.el.id}"><i>${n + 1}</i>${x.lbl}</button>`).join('')
        + `<span class="mnav__sp"></span>`
        + (stamp ? `<span class="mnav__stamp">数据截止 ${stamp}</span>` : '');
      head.after(bar);

      bar.addEventListener('click', e => {
        const b = e.target.closest('[data-go]');
        if (!b) return;
        const t = document.getElementById(b.dataset.go);
        if (!t) return;
        const y = t.getBoundingClientRect().top + window.scrollY - 108;
        window.scrollTo({ top: y, behavior: 'smooth' });
      });

      /* 滚动到哪一块，条上就亮哪一个 */
      const btns = $$('.mnav__a', bar);
      const io = new IntersectionObserver(es => {
        es.forEach(en => {
          if (!en.isIntersecting) return;
          btns.forEach(b => b.classList.toggle('is-here', b.dataset.go === en.target.id));
        });
      }, { rootMargin: '-120px 0px -66% 0px', threshold: 0 });
      items.forEach(x => io.observe(x.el));
    });
  }

  /* ── ▇▇. 底部指令栏：平时一行，点了才展开 ─────────────── */
  function cmd() {
    const bar = document.querySelector('.cmdbar');
    const box = bar && bar.querySelector('.cmdbar__box');
    const inp = bar && bar.querySelector('.cmdbar__in');
    if (!bar || !box || !inp) return;

    const mini = document.createElement('button');
    mini.className = 'cmdbar__mini';
    mini.type = 'button';
    mini.title = '展开，随手记一句';
    mini.setAttribute('aria-label', '展开随手记');
    mini.innerHTML = ICONS.svg('plus');
    box.appendChild(mini);

    /* 窄屏一行放不下长占位文案，会被裁一半，换短的 */
    const ph = () => {
      inp.placeholder = window.innerWidth < 760
        ? '随手记一句…（回车提交给我）'
        : '随手记一句：看到什么现象 / 想到什么玩法 / 谁可能有需求…（回车就提交给我）';
    };
    ph();
    window.addEventListener('resize', ph);

    const open = () => { bar.classList.add('is-open'); inp.focus(); };
    const shut = () => { if (!inp.value.trim()) bar.classList.remove('is-open'); };

    mini.addEventListener('click', open);
    inp.addEventListener('focus', () => bar.classList.add('is-open'));
    inp.addEventListener('blur', () => setTimeout(shut, 140));
    inp.addEventListener('input', () => { if (inp.value) bar.classList.add('is-open'); });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && bar.classList.contains('is-open') && !inp.value.trim()) {
        bar.classList.remove('is-open'); inp.blur();
      }
    });
    /* 提交完自动收回去 */
    bar.addEventListener('click', e => {
      if (e.target.closest('.cmdbar__go')) setTimeout(() => { if (!inp.value.trim()) bar.classList.remove('is-open'); }, 80);
    });
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) setTimeout(() => { if (!inp.value.trim()) bar.classList.remove('is-open'); }, 80);
    });
  }

  /* ── ▇▇. 收口 ──────────────────────────────────────── */
  function boot() {
    try { skip(); } catch (e) {}
    try { icons(); } catch (e) {}
    try { topbar(); } catch (e) {}
    try { drawerNav(); } catch (e) {}
    try { hero(); } catch (e) {}
    try { mnavs(); } catch (e) {}
    try { mnavFade(); } catch (e) {}
    try { cmd(); } catch (e) {}
    try { if (window.VIZ) VIZ.wire(); } catch (e) {}

    /* Hero 是 OS 在重绘的，覆盖它，保证任何一次重绘都还是这一版 */
    if (window.OS) OS.renderHero = hero;
    /* 提交完一件「等你定」，顶栏那个数要跟着掉 */
    if (window.FB && FB.paint) {
      const p = FB.paint;
      FB.paint = function () { p.apply(this, arguments); paintPend(); };
    }
    document.addEventListener('click', e => {
      if (e.target.closest('.ask__go, .fbnote__go')) setTimeout(paintPend, 60);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  return { boot, paintPend, hero, mnavs, QUICK, ANCH };
})();
