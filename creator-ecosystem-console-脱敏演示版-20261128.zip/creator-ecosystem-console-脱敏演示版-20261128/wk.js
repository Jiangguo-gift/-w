/* ═══════════════════════════════════════════════════════════
   wk.js —— 每周二复盘规则
   原则：先读底仓、再算窗口、最后写结论；没更新的源明确标旧。
   ═══════════════════════════════════════════════════════════ */
window.WK = (function () {
  function nextTue() {
    const d = new Date(); d.setHours(0, 0, 0, 0);
    const add = (2 - d.getDay() + 7) % 7 || 7;
    const t = new Date(d.getTime() + add * 86400000);
    const p = n => String(n).padStart(2, '0');
    return { s: `${t.getFullYear()}-${p(t.getMonth() + 1)}-${p(t.getDate())}`, days: add };
  }

  const SRC = [
    { g: '业绩事实源', a: [
      { t: '本季度业务合作情况', u: 'https://docs.internal.example/sheets/INTERNAL-ID',
        take: '发单日、客户结算日、订单状态、GMV、机构、行业、品牌、合作类型',
        risk: '当前最大日期为 2026-09-30；Q4 无记录只能写“尚未入表”' },
      { t: '最新业绩明细（MMM）', u: 'https://corp.internal.example/bi/new-dashboard/edit?v=INTERNAL-ID',
        take: '用于核对飞书表未覆盖的盘中数据、在途与更新延迟',
        risk: '实时 / T+▇▇ / 飞书收口表不是同一时点，必须分行写' }
    ]},
    { g: '目标与供给源', a: [
      { t: '季度业绩目标', u: 'https://docs.internal.example/wiki/INTERNAL-ID?sheet=INTERNAL-ID',
        take: '目标分母与专项目标', risk: '目标调整必须回源，不从旧周报反推' },
      { t: '专项达人打标名单', u: 'https://docs.internal.example/wiki/INTERNAL-ID?sheet=INTERNAL-ID',
        take: '专项名单与人员变化', risk: 'AI 创作者按 ▇▇人；旧 ▇▇人口径作废' },
      { t: '达人刊例信息汇总', u: 'https://docs.internal.example/sheets/INTERNAL-ID',
        take: '报价资料完整度', risk: '无刊例只代表资料缺失，不代表无转化能力' }
    ]},
    { g: '需求与市场源', a: [
      { t: '商机 × 达人刊例 × 策划作战台', u: 'https://app.internal.example/',
        take: '可提报、缺表、点名与授权需求', risk: '若仍为 09-12 快照，必须标历史快照，不写“今天”' },
      { t: 'MCN 周报数据看板', u: 'https://app.internal.example/',
        take: '外部大盘与行业对标', risk: '大盘口径不能与个人结算金额直接相加' },
      { t: 'MCN 机构星图大盘', u: 'https://app.internal.example/',
        take: '机构、行业、直签 / 渠道与效果趋势', risk: '没更新就沿用旧值并标旧，不拿旧值冒充本周' }
    ]}
  ];

  const SEC = [
    { n: '① 上周判断验真', w: '成立 / 被推翻 / 未验证', d: '逐条核对上周判断；被推翻的写清是哪一个新数推翻，并同步进常错清单。' },
    { n: '② 最新 ▇▇ 天关键变化', w: '按数据截止日右端滚动 ▇▇ 天', d: '金额、订单、机构、行业、品牌、合作类型分开看；只写真的变化。' },
    { n: '③ 季度达成与接数状态', w: '先判断数据是否完整', d: '季度中看达成推演；季度切换时先看新季度是否入表。未入表不报 ▇▇。' },
    { n: '④ 结构与专项异动', w: '给名单与对象，不只给百分比', d: '机构集中、行业集中、合作类型、专项名单逐层拆，动作必须落到对象。' },
    { n: '⑤ 近 ▇▇ 天两个案例', w: '一个机构、一个达人 / 品牌', d: '必须是真 ▇▇ 天窗口；否则标候选。写清身份、价格 / 产出、杠杆、可复制条件。' },
    { n: '⑥ 本周错误与口径变化', w: '不省略', d: '错数、错口径、旧快照误当当前、推断误当事实，逐条留痕。' },
    { n: '⑦ 下周三件事', w: '对象 + 动作 + 量级 + 时点', d: '最多三件；禁止“加强沟通 / 持续关注”。' }
  ];

  const OUT = [
    ['本地 Obsidian', '<code>50-业绩与复盘/2026-W{周数}-周复盘.md</code>', '本地为权威；写后回读。'],
    ['工作台', '业务工作区 → 作战执行与节奏', '更新周度策略回顾，不保留旧周次冒充当前。'],
    ['飞书提醒', '▇▇行摘要 + 工作台直达链接', '最重要结论 / 一个风险 / 一个立即动作。'],
    ['云端镜像', '<code>/memory/</code>', '本地断连时只作降级读法，并记录待同步。']
  ];

  function render() {
    const t = nextTue();
    return `<div class="wk" data-mod="m-wk" id="wk">
      <div class="wk__hd"><span class="wk__tag">每周复盘规则 · 每周二</span><div class="wk__hdx"><b>下一次计划复盘：${t.s}（还有 ${t.days} 天）</b><em>先读底仓 → 校验截止日 → 取最新完整 ▇▇ 天 → 写结论 → 回写 Obsidian 与工作台。</em></div></div>
      <div class="wk__honest wk__honest--set"><span class="wk__hk">当前状态</span><p>飞书主表《本季度业务合作情况》已于 <b>2026-11-02 全量重读至 rev▇▇（▇▇行，数据截止 11-01）</b>，Q4 窗口 10-01~11-01 盘面与状态已入工作台；九术 BI 明细停在 10-24，仅作同比锚点。<b>本表无客户结算日期列，正式结算底表仍待回源，复盘里“已完成”只能写状态口径</b>。下一篇复盘第一项是核近 ▇▇ 天（10-26~11-01）节奏与近结算转化。</p></div>
      <div class="wk__sec"><div class="wk__h"><span class="wk__n">第一步 · 读哪几个底仓</span><em>同一指标只认一个权威源；旧源标旧</em></div>${SRC.map(g => `<div class="wksg"><div class="wksg__k">${g.g}</div>${g.a.map(x => `<div class="wks"><div class="wks__h"><b>${x.t}</b><a class="wks__a" href="${x.u}" target="_blank" rel="noopener">打开 ↗</a></div><p class="wks__t"><span>只取这些</span>${x.take}</p><p class="wks__r"><span>口径边界</span>${x.risk}</p></div>`).join('')}</div>`).join('')}</div>
      <div class="wk__sec"><div class="wk__h"><span class="wk__n wk__n--run">第二步 · 七段复盘</span><em>结论 → 拆解 → 归因 → 可行性 → 动作</em></div><div class="wk__secl">${SEC.map(s => `<div class="wkc"><div class="wkc__h"><b>${s.n}</b><span>${s.w}</span></div><p>${s.d}</p></div>`).join('')}</div></div>
      <div class="wk__sec"><div class="wk__h"><span class="wk__n wk__n--out">第三步 · 四处同步</span><em>写了但工作台与记忆没更新，等于没完成</em></div><div class="wk__outl">${OUT.map(o => `<div class="wko"><div class="wko__h"><b>${o[0]}</b><span>${o[1]}</span></div><p>${o[2]}</p></div>`).join('')}</div></div>
      <div class="wk__rule"><span class="wk__rk">四条硬纪律</span><ul><li>数字必须带来源、口径、截止日</li><li>发单 / 结算 / 盘中实时分行写，不相加</li><li>新季度未入表不等于新季度为 ▇▇</li><li>动作必须有对象、量级、时点与验收条件</li></ul></div>
    </div>`;
  }
  return { render, nextTue, SRC, SEC, OUT };
})();
