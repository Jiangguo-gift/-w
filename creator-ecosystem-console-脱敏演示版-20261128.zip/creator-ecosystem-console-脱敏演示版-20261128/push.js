/* ═══════════════════════════════════════════════════════════
   push.js —— 主动推进层（挂在「我的能力清单」页）
   2026-09-13 22:25 她的原话：
     「你这里的信息，不是都告诉我怎么叫你做，而是要主动提醒我，
       需要提供哪些信息，需要做哪些事项，有什么价值做主动的项目推进。
       可以给我列待办」

   所以这一页从"我会哪些活 / 你怎么叫我"改成三块主动件：
     ① 等你给我的信息（.pgv）—— 缺哪样 → 我因此做不了什么 → 你只要花多久
     ② 我建议推进的项目（.pgp）—— 不用你想，我自己提，每条挂一个数
     ③ 待办清单（.pgt）—— 可勾选，勾完一键发我

   ⛔ 待办只有一份真相：数据源就是 HQ.PLANS（驾驶舱那份"推进计划"）。
      驾驶舱看的是计划总览，这里是能勾的执行版，两处永远同一批条目，
      不许各写一套（E-02 类错误：两处各写一份，第二天就对不上）。
   ⛔ 一个业绩金额都没有：金额只在「我的业务基本盘」。
   ═══════════════════════════════════════════════════════════ */
/* global HQ, FB, PUSH */
window.PUSH = (function () {

  const KV = 'cec.todo';
  const SEED_KEY = 'cec.todo.seed';
  const SEED_VER = '2026-10-10T17:33';
  const SEED = {
    't-现在-▇▇': 1,
    't-现在-▇▇': 1,
    't-Q4 首批数据入表后-▇▇': 1,
    't-本季度-▇▇': 1,
    't-本季度-▇▇': 1
  };
  const load = () => { try { return JSON.parse(localStorage.getItem(KV) || '{}'); } catch { return {}; } };
  const save = o => { try { localStorage.setItem(KV, JSON.stringify(o)); } catch {} };
  function bootDone() {
    try {
      if (localStorage.getItem(SEED_KEY) !== SEED_VER) {
        save(Object.assign({}, SEED));
        localStorage.setItem(SEED_KEY, SEED_VER);
        return Object.assign({}, SEED);
      }
    } catch {}
    return load();
  }
  let DONE = bootDone();

  /* ── ① 等你给我的信息 ─────────────────────────────────
     k  你要给我什么
     cost 你实际要花多少（必须写小，写不小的说明我在推活给你）
     blk  缺了它我具体做不了什么（要能指到页面上某个具体的空）
     say  你原封不动发我的一句话
     p    高 / 中 */
  const GIVE = [
    { p: '高', k: '星图后台开一次登录态', cost: '▇▇ 分钟，你只要点开别退出',
      blk: '缺它我拿不到<b>达人级的内容表现、粉丝画像、转化数据</b> —— 这就是案例二里「用户粘性高、转化价值高」这两层<b>我现在一个字都证不了</b>的原因，也是减投三件事里「选人维度加转化证据」一直没动工的原因。',
      say: '星图我登好了，去把达人A的商单明细、粉丝画像、内容表现拉全' },
    { p: '高', k: '拜访完给我三句话', cost: '路上语音三句，不用整理',
      blk: '仓库<b>拜访与会议目录还是 ▇▇篇、▇▇家打标机构一家画像都没有、拜访策略类规则 ▇▇条</b>。客户减投的归因链断在最前端 —— 我只能看到金额掉了，看不到他为什么掉。',
      say: '刚见完 X 机构：他现在最缺什么 / 对我们最大的不满 / 下季度想做什么' },
    { p: '高', k: '▇▇条 A 类需求的提报表',
      cost: '在群里问一句要表，拿到丢给我',
      blk: '这 ▇▇条是<b>正式需求、有预算、只差一张表</b>，缺表就一条都提不了。表到我手上就能批量配人选。',
      say: '表拿到了（附件），把这几条的推荐人选一次配齐' },
    { p: '高', k: '每日行业简报的验收意见', cost: '两句话：哪个板块没用、哪个源要换',
      blk: '样张已经跑出来了，但<b>你不点头我不敢上 10:00 定时</b>，所以它一直是样张，不是每天的情报。竞标那一块本期一条都没抓到，也要你说换哪个源。',
      say: '简报里 XX 板块没用去掉，竞标改成从 XX 抓' },
    { p: '中', k: '重点客户的钱是从哪个口袋出的', cost: '每个客户一个词',
      blk: '缺它我判断增减投只能靠金额涨跌，<b>判不了预算换挡</b>。品牌预算（要曝光）／效果预算（要投产比）／内容资产预算（要可复用素材）—— 三个口袋决定该卖什么，不只是卖给谁。',
      say: 'X 客户是效果预算，Y 客户今年转内容资产了' },
    { p: '中', k: '达人级转化数据的取数权限', cost: '一张表，或一句"这个能力给你开"',
      blk: 'CPA ▇▇、进店率、看后搜、带货 GMV 档位 —— 这些拿不到，<b>「这个达人转化价值高」永远只能是我的推断</b>，写进提案客户会追问。',
      say: '这个数据我能给你 XX 表 / 你去申请 XX 权限' }
  ];

  /* ── ② 我建议推进的项目 ───────────────────────────────
     每条必须回答：为什么是现在（挂一个数）· 做什么 · 你花多久 · 不做会怎样
     st: new = 今天新提 / on = 已在推 / wait = 等你拍 */
  const PROJ = [
    { p: 1, st: 'new', t: '把「个体高溢价达人」立成一条正式线',
      why: '达人A ▇▇单做出的单均是<b>全盘指派任务单均的 ▇▇倍</b>；她和明星B两个人<b>没有任何机构在背后运营</b>，QTD 合计 ▇▇万，接近一家腰部机构一个季度的量。这条线现在<b>没名单、没目标、没归属人</b>，全靠偶发接单。',
      do: '我按五条可查条件从 ▇▇人池筛一版候选名单 → 给 Q4 目标区间 → 定归属人和跟进节奏。',
      you: '你只做一件事：拍要不要立。', bad: '不立，Q4 这条线还是"运气好就有"，进不了目标拆解。', to: 'base' },
    { p: 2, st: 'new', t: '把 ▇▇条点名商机做成拓新优先级表',
      why: '▇▇条点名类商机里，<b>▇▇条点的人不在你 ▇▇人池内</b>。这是市场替你写好的一张拓新清单，现在这些需求进来只能回"我们没这个人"。',
      do: '按"被点次数 × 客户量级"排序出 Top ▇▇，逐个标可签约路径（机构签 / 个体签 / 只做素材授权）。',
      you: '看一版排序，划掉你觉得不可能的。', bad: '继续每条需求单独找人，同一个名字被点五次也没人去谈。', to: 'eco' },
    { p: 3, st: 'on', t: '用 ▇▇ 类代表资源验证第二梯队能否长出来',
      why: 'Q3 TOP1 机构客户A占 <b>▇▇</b>，这是结构集中结果，不是要硬压的经营目标。真正要验证的是：哪些资源类型能承接新增需求。',
      do: '只试两家：客户J 跑「内容型头达 + 授权费单列 + 素材后链路」；客户I 跑「美妆矩阵 + 招募一口价达人团」。机构E只做备选，不为凑数立目标。',
      you: '拜访后补两家的经营意愿、目标客户与供给约束。', bad: '如果只盯 TOP1 占比、不验证资源形态，数字可能变了但新增收入不会自然出现。', to: 'supply' },
    { p: 4, st: 'new', t: '给 ▇▇位没刊例的达人开一条效果型承接路径',
      why: '池内刊例覆盖只有 <b>▇▇</b>，▇▇位没收到报价。<b>没报价 ≠ 不能接单</b> —— 招募任务、带货、素材授权都不靠刊例。',
      do: '从 ▇▇位里挑出适合招募 / 任务 / 带货的，做一版"无刊例也能接"的承接路径和话术。',
      you: '认一下这条路要不要走。', bad: '这 ▇▇位在系统里等于不存在，需求来了根本不会被想起。', to: 'base' },
    { p: 5, st: 'wait', t: '短剧演员专项名单补齐',
      why: '这个专项现在<b>名单上只有 ▇▇个人</b>，一个人背整条专项目标。这是名单缺口，不是能力缺口。',
      do: '池内 + 外部盘一版 ▇▇~▇▇人候选，标清楚谁能接品牌植入、谁只能接内容授权。',
      you: '拍一下这个专项 Q4 还要不要做。', bad: '要么这条专项交白卷，要么临时抱人、报价没谈判空间。', to: 'base' },
    { p: 6, st: 'wait', t: '每日 ▇▇ 点行业简报正式上线',
      why: '第一版四个板块已经跑通，只卡在你验收这一步。',
      do: '按你的意见改板块和源，然后挂定时，每天 10:00 推你三行摘要。',
      you: '两句话验收。', bad: '外部行情这一域永远是我火力最弱的一块。', to: 'eco' },
    { p: 7, st: 'on', t: '▇▇家打标机构档案从 ▇▇篇开始长',
      why: '机构档案 ▇▇篇是现在整套系统最大的空，年框谈判、该不该救、拜访策略三件事全都依赖它。',
      do: '你每拜访完一家给我三句话，我落一篇档案；下次拜访前我反过来给你「拜访前的机构情报清单」。',
      you: '拜访完别忘了发我。', bad: '每次拜访都从零开始准备，上次的结论第二次用不上。', to: 'base' }
  ];

  const ST = { new: ['今天新提', 'is-new'], on: ['已在推', 'is-on'], wait: ['等你拍', 'is-wait'] };

  /* ── ③ 待办清单：数据源 = HQ.PLANS ───────────────────── */
  function todoRows() {
    const P = (window.HQ && HQ.PLANS) || [];
    const rows = [];
    P.forEach(g => g.items.forEach((x, i) => rows.push({
      id: 't-' + g.w + '-' + i, w: g.w, t: x.t, y: x.y, to: x.to
    })));
    return rows;
  }

  /* ── 渲染 ─────────────────────────────────────────────── */
  function giveBox() {
    const hi = GIVE.filter(x => x.p === '高').length;
    return `<section class="pgv" data-mod="pg-give" id="pgv">
      <div class="pg__h"><span class="pg__k">待补充信息</span>
        <b>不是问你要资料，是这 ${GIVE.length} 样东西缺着，我有些事就是做不了</b>
        <em>其中 <i>${hi} 样</i> 卡着今天的事；每样都写清了你实际要花多久</em></div>
      <div class="pgv__l">${GIVE.map(x => `<div class="pgv__i${x.p === '高' ? ' is-hi' : ''}">
        <div class="pgv__hd">
          <span class="pgv__p">${x.p}</span>
          <b class="pgv__t">${x.k}</b>
          <span class="pgv__c">你花：${x.cost}</span>
        </div>
        <p class="pgv__b"><span>缺了它我做不了</span>${x.blk}</p>
        <div class="pgv__say"><span>直接发我这句</span><code>${x.say}</code></div>
      </div>`).join('')}</div>
    </section>`;
  }

  function projBox() {
    const nw = PROJ.filter(x => x.st === 'new').length;
    return `<section class="pgp" data-mod="pg-proj" id="pgp">
      <div class="pg__h"><span class="pg__k">建议推进项目</span>
        <b>不用你想，这 ${PROJ.length} 件是我自己提的，按价值排了序</b>
        <em>其中 <i>${nw} 件今天新提</i>；每件都挂着一个具体的数，不是"应该做点什么"</em></div>
      <div class="pgp__l">${PROJ.map(x => {
        const s = ST[x.st] || ST.on;
        return `<div class="pgp__i ${s[1]}">
          <div class="pgp__hd">
            <span class="pgp__n">${String(x.p).padStart(2, '0')}</span>
            <b class="pgp__t">${x.t}</b>
            <span class="pgp__st">${s[0]}</span>
          </div>
          <p class="pgp__r"><span>为什么是现在</span>${x.why}</p>
          <p class="pgp__r"><span>我会做什么</span>${x.do}</p>
          <div class="pgp__two">
            <p class="pgp__you"><span>你要花什么</span>${x.you}</p>
            <p class="pgp__bad"><span>不做的后果</span>${x.bad}</p>
          </div>
          <div class="pgp__ft">
            <button class="pgp__ok" data-pgok="${x.p}">这个做，我批了</button>
            ${x.to ? `<button class="pgp__go" data-jumpv="${x.to}">先去看相关数据 →</button>` : ''}
          </div>
        </div>`;
      }).join('')}</div>
    </section>`;
  }

  function todoBox() {
    const rows = todoRows();
    const grp = [];
    rows.forEach(r => {
      let g = grp.filter(y => y.w === r.w)[0];
      if (!g) { g = { w: r.w, items: [] }; grp.push(g); }
      g.items.push(r);
    });
    const done = rows.filter(r => DONE[r.id]).length;
    return `<section class="pgt" data-mod="pg-todo" id="pgt">
      <div class="pg__h"><span class="pg__k">待办清单</span>
        <b>${rows.length} 件 · 勾掉做完的，勾完点一下发我，我按剩下的排后面的活</b>
        <em>已勾 <i id="pgtN">${done}</i>/${rows.length} · 和驾驶舱那份「推进计划」是同一批，改一处两边一起变</em></div>
      <div class="pgt__g">${grp.map(g => `<div class="pgt__c">
        <div class="pgt__w">${g.w}<i>${g.items.length}</i></div>
        ${g.items.map(r => `<label class="pgt__i${DONE[r.id] ? ' is-done' : ''}" data-tid="${r.id}">
          <input type="checkbox" ${DONE[r.id] ? 'checked' : ''}>
          <span class="pgt__bx"></span>
          <span class="pgt__tx"><b>${r.t}</b><em>${r.y}</em></span>
          ${r.to ? `<button class="pgt__go" data-jumpv="${r.to}" type="button">去 →</button>` : ''}
        </label>`).join('')}
      </div>`).join('')}</div>
      <div class="pgt__ft">
        <button class="pgt__send" id="pgtSend">把我勾的进度发给你</button>
        <span class="pgt__hint">只发一条汇总，不占你那 ▇▇条反馈的额度</span>
      </div>
    </section>`;
  }

  function render() { return giveBox() + projBox() + todoBox(); }

  /* ── 交互 ─────────────────────────────────────────────── */
  function refreshN() {
    const el = document.getElementById('pgtN');
    if (el) el.textContent = Object.keys(DONE).filter(k => DONE[k]).length;
  }

  function wire() {
    document.addEventListener('change', e => {
      const box = e.target.closest('.pgt__i');
      if (!box || e.target.type !== 'checkbox') return;
      const id = box.dataset.tid;
      if (e.target.checked) DONE[id] = 1; else delete DONE[id];
      box.classList.toggle('is-done', !!e.target.checked);
      save(DONE); refreshN();
    });

    document.addEventListener('click', e => {
      /* 待办不能因为点了里面的跳转按钮就被勾上 */
      if (e.target.closest('.pgt__go')) { e.preventDefault(); return; }

      const send = e.target.closest('#pgtSend');
      if (send) {
        const rows = todoRows();
        const ok = rows.filter(r => DONE[r.id]);
        const left = rows.filter(r => !DONE[r.id]);
        if (!ok.length) { if (window.FB) FB.toast('还没勾任何一条 —— 勾掉做完的再发我'); return; }
        const txt = `待办进度（${ok.length}/${rows.length}）\n已做完：${ok.map(r => r.w + '·' + r.t).join('；')}\n还没动：${left.map(r => r.w + '·' + r.t).join('；')}`;
        if (window.FB && FB.submit) {
          const it = FB.submit({ kind: 'todo', view: '我的能力清单', topic: '待办进度', text: txt });
          if (it) FB.toast(`收到：${ok.length} 件做完、${left.length} 件还没动 —— 我按剩下的排后面的活`);
        }
        return;
      }

      const okb = e.target.closest('[data-pgok]');
      if (okb) {
        const p = okb.dataset.pgok;
        const it = PROJ.filter(x => String(x.p) === String(p))[0];
        if (!it) return;
        if (window.FB && FB.submit) {
          const r = FB.submit({ kind: 'decide', view: '我的能力清单',
            topic: '批推进项目·' + it.t, choice: '批了，去做', text: it.do });
          if (r) { okb.textContent = '已批 ✓'; okb.classList.add('is-ok'); FB.toast('收到，这件我接了 —— 进度会挂到驾驶舱「项目进度」里'); }
        }
        return;
      }
    });
  }

  return { render, wire, GIVE, PROJ, todoRows };
})();

(function () {
  const go = () => { try { PUSH.wire(); } catch (e) { console.warn('push', e); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go);
  else go();
})();
