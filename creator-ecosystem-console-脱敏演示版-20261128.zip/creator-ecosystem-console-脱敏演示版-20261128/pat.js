/* ═══════════════════════════════════════════════════════════
   pat.js —— 发现你的思维模式 · 每日动态层（她 2026-09-16 要的）

   她的原话：
     「你这里的内容不要固定死了，每天要有新的动态更新，及汇总整理；
       甚至你可以主动跟我聊天来了解我的想法」

   所以这一页从"▇▇条固定偏好"改成一本每天会动的册子：
     ① 今日新增（今天从你哪句话反推出来的）
     ② 观察中（只命中一次，不敢当结论用 —— 写清再命中几次才升级）
     ③ 被推翻 / 降级的（▇▇条也要写，并说清 ▇▇条不等于全对）
     ④ 今天我想问你的一个问题（这就是"主动跟你聊天"，一天只问一题）
     ⑤ 这一页每天怎么更新（料从哪来 · 升级门槛 · 你怎么追踪）

   ⛔ 四条硬规矩：
     ▇▇. 一天只问一题。问三题就变成问卷，你就不答了。
     ▇▇. 每条必须挂"哪一天 / 哪一题 / 你说了什么"，不许写成抽象标签。
     ▇▇. 只命中一次的一律进观察中，不许当结论用（这一条我犯过错）。
     ▇▇. 空白就写空白 —— 我不敢猜的地方不许编。
   ═══════════════════════════════════════════════════════════ */
window.PAT = (function () {

  const PKEY = 'cec.pat.v1';
  const TODAY = '2026-09-16';

  /* ── ① 今日新增：从她 09-14 / 09-16 的真实动作反推 ── */
  const NEW = [
    { t: '你会把一整套方案拆开，只采纳其中一层',
      when: '2026-09-14 换皮那次',
      said: '「按钮呈现风格采纳，UI 工作台界面设计帮我恢复回来上一版的版本风格」',
      was: '我原来默认"你说好 = 整套都要"，所以一次性把底色、卡片、按钮全换了。',
      now: '视觉方案以后拆成<b>界面底色 / 卡片结构 / 按钮控件</b>三层分别问你，一层一层点头。',
      cost: '这一条不立，下次我又会拿"你喜欢那个按钮"去证明"你喜欢这套界面"。' },
    { t: '你要的是一个能反馈的窗口，不是让你选 A / B / C',
      when: '2026-09-16',
      said: '「我逐条给反馈并确认动作，你给我一个可以反馈的窗口，我告诉你怎么落」',
      was: '我原来给的是三选一：全放行 / 逐条再说 / 都先别动 —— 等于让你在我的三个方案里挑一个。',
      now: '▇▇件活改成<b>等你逐条拍板的事项</b>：一条一行、你自己写怎么落，我按你的字执行，不按我的默认。',
      cost: '这一条是把上面那条又验了一次 —— 你要的从来是"落法归你"，不是"方案归我、选择权归你"。' },
    /* 09-21 HO-0921-▇▇ 第四条反馈：今天这一题 · 报价与让利 —— 她的答案原话入库。
       ⛔ 不许我把这两句缩成"看情况"，那等于没答。她的判读逻辑很清楚：
       先辨背景（钱包缩减 / 性价比过低），再走各自的固定动作。这一条以后我算总价、组包、
       谈让利时，先默认按这两条走，除非你当场说这次走别的。 */
    { t: '报价与让利 —— 先辨背景，再决定动哪一项',
      when: '2026-09-16 · HO-0921-▇▇ 第 ▇▇条',
      said: '「看客户刊预算的背景。如果客户是确定性钱包缩减，那么就是减少可覆盖的达人或者权益，找到更符合当下预算的资源组合；如果客户是觉得当前资源性价比过低，可以尽可能争取给到达人附赠资源，如素材授权等稳定合作报价」',
      was: '我原来把这题设计成四选一（换人 / 减量 / 补总价 / 换形态），把它当成一个可以直接挑一个的动作。',
      now: '<b>拆成两层</b>：<br>① 先判客户是「<b>确定性钱包缩减</b>」还是「<b>觉得性价比过低</b>」—— 这一步定路。<br>② 钱包缩减 → 减达人 / 减权益，找符合当下预算的资源组合（<b>报价随预算走</b>）；<br>性价比过低 → 争取给达人附赠资源，比如<b>素材授权 / 二次复用 / 打包权益</b>，用附赠换稳定报价（<b>保报价、加权益</b>）。<br>已立成 <b>R-615</b> + 决策习惯 <b>D-26</b>：报价让利决策树。',
      cost: '不立这条，我会默认走"砍价 = 砍单价"，把你原本用附赠能保住的报价白让掉。' }
  ];

  /* ── ② 观察中：只命中一次，不敢当结论 ── */
  const WATCH = [
    { t: '固定下来的东西，你都会要它变成每天会动的',
      hit: '目前 ▇▇次（但同一天里三句话都指向它）',
      said: '09-16 三条补充：思维模式「不要固定死了，每天要有新的动态更新」· 记忆库「每日更新…像图书目录一样可追踪」· 灵感库「你不断从市场上主动反馈」',
      need: '再命中 ▇▇次升为稳定。<b>什么算命中</b>：你对着一个静态板块说"这里要动起来"。',
      risk: '⚠️ 如果我判断错了，后果是我把一堆东西改成每天更新、但你其实只关心其中一两块 —— 那是给你添噪音。所以这条我先按"你关心的那几块动起来"办，不全站铺。' },
    { t: '你希望我主动开口，而不是等你来问',
      hit: '目前 ▇▇次',
      said: '09-16「甚至你可以主动跟我聊天来了解我的想法」',
      need: '再命中 ▇▇次升为稳定。<b>什么算命中</b>：你主动说"你可以问我"或者对我的追问给了正面回应。',
      risk: '⚠️ 边界我自己先划死：<b>一天最多一题</b>，且只问"我猜不到、猜错代价大"的那种。问多了就是骚扰，那会让这条直接被你推翻。' }
  ];

  /* ── ③ 被推翻 / 降级的 ── */
  const DROP = {
    n: 0,
    why: '这一册从 09-12 才开始记，<b>到今天只有 ▇▇ 天</b>。降级规则是"▇▇ 天没命中降为观察中、再 ▇▇ 天退役"，所以最早也要到 10 月中旬才会有第一条降级。',
    honest: '⚠️ <b>▇▇条不等于这几条全对，等于还没到检验期。</b>现在唯一能证伪它们的人是你 —— 看到哪条不对，一句"这条不对"我当场作废，不追问。'
  };

  /* ── ④ 今天我想问你的一个问题（主动追问）──
     选题标准：只问"我猜不到、且猜错代价大"的空白。今天这题正是两块空白里的第一块。 */
  const ASKD = {
    d: TODAY,
    why: '<b>✅ 已答</b> · 你于 2026-10-04 确认：<em>「看客户刊预算的背景 —— 确定性钱包缩减 = 减达人/减权益找符合当下预算的资源组合；觉得当前性价比过低 = 争取给达人附赠资源如素材授权等，稳定合作报价」</em>。<b>答案已进入决策习惯与判断规则</b>，这里仅保留最近确认记录。',
    q: '客户说预算要砍 ▇▇，你通常先动哪一个？',
    opts: [
      '换人选：换成单价更低的达人，条数不变',
      '减量保价：少发一条，但单价不降',
      '把总价补回来：谈素材授权费 / 二次复用这类可收费项',
      '换形态：直接改成后链路投放包，谈总预算不谈单条'
    ],
    ph: '这一题她已经答过了 —— 答案见今日新增第 ▇▇条 / D-26。这里不用再答。',
    answered: true,
    ansSummary: '<b>她的答法（拆两条走）</b>：<br>① 确定性钱包缩减 → 减达人 / 减权益，选出符合当下预算的资源组合。<br>② 性价比过低 → 争取给达人附赠资源（素材授权 / 二次复用 / 打包权益），<b>保报价、加权益</b>。',
    next: [
      '客户关系和数据结论正面打架时，你先信哪一个（明天问这个）',
      '一份客户提案，你自己最先翻哪一页 —— 这决定我以后把结论放第几页'
    ]
  };

  /* ── ⑤ 每天怎么更新 ── */
  const HOW = [
    ['料从哪来', '四个口：你在页面上写的字 · 你在对话里的原话 · 你的裁决（<b>选了哪个 + 补充框写了什么，后者权重更高</b>）· 你纠正我的那一刻',
     '最值钱的是第四个 —— 你纠我的时候，暴露的是你的判断链，不只是结论'],
    ['升级门槛（写死，不许我看心情）', '命中 ▇▇次 → 进观察中 · 同类命中 ▇▇次 → 升为稳定 · ▇▇ 天没命中 → 降回观察中 · 再 ▇▇ 天 → 退役（<b>只退不删，能查回</b>）',
     '为什么写死：不写死我就会把"你说过一次的话"当成"你一贯的偏好"，这个错我犯过'],
    ['你怎么追踪', '每条都挂日期 + 你的原话；每次改动记进记忆库的变更日志，按天倒序',
     '用法：你怀疑我按了一条你没同意的偏好，去变更日志查它哪天进来的'],
    ['⚠️ "每天"这件事的实话', '我不是常驻进程，<b>到点自己醒过来我做不到</b>。所以"每天更新"靠一个触发动作：你说一句，或者挂进你飞书日历提醒你说那句',
     '这件已经摆进等你定的事项，跟记忆库那边用同一个触发方式，不让你配两套']
  ];

  /* ── ⑥ 还空着的 ── */
  const BLANK = [
    ['客户关系 vs 数据结论', '还没样本，下一题再问', '不补的后果：数据说该砍、关系说该保的时候，我不知道该把哪一边写进结论']
  ];

  function pLoad() { try { return JSON.parse(localStorage.getItem(PKEY) || '{}') || {}; } catch (e) { return {}; } }
  function pSave(v) { try { localStorage.setItem(PKEY, JSON.stringify(v)); } catch (e) {} }
  const esc = s => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  /* 答案永远只占收件箱一格：topic 固定，改答案覆盖同一条 */
  function sync(silent) {
    if (!(window.FB && FB.submit)) return;
    const st = pLoad();
    if (!st.pick && !(st.txt || '').trim()) return;
    const txt = `今天这题：${ASKD.q}\n→ ${st.pick ? ASKD.opts[st.pick - 1] : '（没选选项）'}` +
                ((st.txt || '').trim() ? `\n→ 她补充：${st.txt.trim()}` : '');
    const it = FB.submit({
      kind: 'add', view: '发现你的思维模式',
      topic: 'pat-daily-' + TODAY, topicName: `今天这一题（${TODAY}）· 报价与让利`,
      text: txt
    });
    if (!silent && it && FB.toast) FB.toast('收到 —— 这一条会原话写进决策习惯那一册，不改你的字');
  }

  function repaint() {
    document.querySelectorAll('.pat').forEach(box => {
      const holder = box.parentElement; if (!holder) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = render();
      holder.replaceChild(tmp.firstElementChild, box);
    });
  }

  function render() {
    const st = pLoad();
    return `<div class="pat" data-mod="m-pat" id="pat">

      <div class="pat__hd">
        <span class="pat__tag">今天这一页动了什么</span>
        <div class="pat__hdx">
          <b>${TODAY} 的问题 · 2026-10-04 已确认</b>
          <em>过往确认只保留最近 ▇▇条。这道报价与让利题已收口为可直接复用的决策树，不再作为待答题重复出现。</em>
        </div>
      </div>

      <div class="pat__stat">
        <div class="pats"><span>最近确认</span><b>${NEW.length}</b><em>最多保留 ▇▇条</em></div>
        <div class="pats pats--w"><span>观察中</span><b>${WATCH.length}</b><em>只命中 ▇▇次，不敢当结论</em></div>
        <div class="pats"><span>被推翻</span><b>${DROP.n}</b><em>还没到检验期，不是全对</em></div>
        <div class="pats pats--b"><span>还空着</span><b>${BLANK.length}</b><em>不重复追问已确认题</em></div>
      </div>

      <div class="pat__sec">
        <div class="pat__h"><span class="pat__n pat__n--new">① 最近确认 ${NEW.length} 条</span>
          <em>每条写清：<b>哪一天 · 你说了什么 · 我原来怎么以为的 · 现在改成什么 · 不改会怎样</b></em></div>
        <div class="pat__l">${NEW.map((x, i) => `<div class="patn">
          <div class="patn__h"><i>新</i><b>${x.t}</b><span>${x.when}</span></div>
          <p class="patn__s"><span>你的原话</span>${x.said}</p>
          <p class="patn__w"><span>我原来怎么以为的</span>${x.was}</p>
          <p class="patn__d"><span>现在改成</span>${x.now}</p>
          <p class="patn__c"><span>不改会怎样</span>${x.cost}</p>
        </div>`).join('')}</div>
      </div>

      <div class="pat__sec">
        <div class="pat__h"><span class="pat__n pat__n--watch">② 观察中 ${WATCH.length} 条 · 还不能当结论用</span>
          <em>只命中一次的东西我不敢当你的一贯偏好 —— <b>这个错我犯过</b>，所以门槛写死在下面</em></div>
        <div class="pat__l">${WATCH.map(x => `<div class="patw">
          <div class="patw__h"><i>观察</i><b>${x.t}</b><span>${x.hit}</span></div>
          <p class="patw__s"><span>你的原话</span>${x.said}</p>
          <p class="patw__n"><span>怎么才算升级</span>${x.need}</p>
          <p class="patw__r">${x.risk}</p>
        </div>`).join('')}</div>
      </div>

      <div class="pat__sec pat__sec--drop">
        <div class="pat__h"><span class="pat__n pat__n--drop">③ 被推翻 / 降级的：${DROP.n} 条</span>
          <em>这一栏 ▇▇条也必须写出来，藏起来就等于我在报好消息</em></div>
        <p class="patd__d">${DROP.why}</p>
        <p class="patd__h">${DROP.honest}</p>
      </div>

      <div class="pat__ask pat__ask--answered">
        <div class="pat__h"><span class="pat__n pat__n--ask">④ 报价与让利 · 已确认</span>
          <em>原题已于 2026-10-04 收口，不再显示选项和提交框</em></div>
        <p class="patq__w">${ASKD.why}</p>
        <div class="patq patq--done">
          <b class="patq__q">${ASKD.q}</b>
          <div class="patq__answer">${ASKD.ansSummary}</div>
        </div>
        <div class="patq__nx">
          <span>下一道仍未确认的问题</span>
          <ol>${ASKD.next.slice(0, 1).map(n => `<li>${n}</li>`).join('')}</ol>
        </div>
      </div>

      <div class="pat__sec pat__sec--blank">
        <div class="pat__h"><span class="pat__n pat__n--gap">⑤ 仍未确认的 ▇▇块</span>
          <em>空白就写空白 —— 猜一个填上去比留白危险得多</em></div>
        <div class="pat__bl">${BLANK.map(b => `<div class="patb2">
          <b>${b[0]}</b><span>${b[1]}</span><em>${b[2]}</em>
        </div>`).join('')}</div>
      </div>

      <p class="pat__ft">这几条你随时可以一句话推翻，我不追问也不解释 —— <b>被你推翻的那一刻，这一页才是真的在长</b>。</p>
    </div>`;
  }

  function wire() {
    document.addEventListener('click', e => {
      const b = e.target.closest('.patq__b');
      if (b) {
        const st = pLoad(), v = Number(b.dataset.pp);
        st.pick = (st.pick === v) ? 0 : v;
        pSave(st); sync(1); repaint();
        return;
      }
      const s = e.target.closest('.patq__send');
      if (s) {
        const st = pLoad();
        if (!st.pick && !(st.txt || '').trim()) {
          if (window.FB && FB.toast) FB.toast('先选一个、或者写一句都行 —— 写的那句比选项值钱');
          return;
        }
        sync();
        if (window.FB && FB.open) FB.open();
        return;
      }
    });
    document.addEventListener('input', e => {
      const t = e.target.closest('.patq__t');
      if (!t) return;
      const st = pLoad(); st.txt = t.value; pSave(st);
    });
    document.addEventListener('change', e => {
      if (e.target.closest('.patq__t')) sync(1);
    });
  }

  return { render, wire, NEW, WATCH, ASKD, HOW, BLANK };
})();

(function () {
  const go = () => { try { PAT.wire(); } catch (e) { console.warn('pat', e); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go);
  else go();
})();
