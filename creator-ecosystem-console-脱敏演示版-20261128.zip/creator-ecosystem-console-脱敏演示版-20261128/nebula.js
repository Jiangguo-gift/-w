/* ═══════════════════════════════════════════════════════════
   nebula.js —— 记忆库总目录「Obsidian 星云图」（动态可点击版）
   2026-09-29 本人 指令：星云图不要用快照，替换成可动态点击的模块

   动态点击的三层含义：
   ① 每个节点 = 一次真实操作，不是数据展示
      · 点集群 → 就地展开 / 折叠该文件夹的所有文件
      · 点文件 → 首选 obsidian:// 直开本地 Obsidian
      · 次选：复制 md 链接给 Aime
   ② 在线状态实时探测（LocalRESTAPI 端口 ▇▇）
      · 通 → 显示「本地 Obsidian 已连通」+ 允许拉最新目录
      · 不通 → 显示「未连通 · 走 obsidian:// URI」+ 保留兜底目录
   ③ 允许用户手动刷新目录结构（拉不到则明说，不假装成功）

   URL 协议：obsidian://open?vault=obsidian文件夹&file={md-encoded-path}

   兜底数据源：实测挂载路径 2026-09-29 首次读盘，之后由 refresh() 覆写
   ═══════════════════════════════════════════════════════════ */
window.NEBULA = (function () {
  'use strict';

  const VAULT = 'obsidian文件夹';
  /* Obsidian LocalRESTAPI 默认地址（她的 70-工具与入口/Obsidian常连-LocalRESTAPI.md）*/
  const REST_HTTPS = 'https://127.0.0.1:27124';
  const REST_HTTP  = 'http://127.0.0.1:27123';

  /* 初始兜底：首次读盘的数据，refresh() 会尝试覆写 */
  const INIT_ROOTS = [
    { n: 'AIME.md',    kind: 'root', lines: 620,  ymd: '09-13', hue: 268 },
    { n: 'MEMORY.md',  kind: 'root', lines: 1850, ymd: '09-23', hue: 268 }
  ];

  const INIT_CLUSTERS = [
    { k: 'mem',   d: '_记忆',           t: '五册常驻记忆',            hue: 262, ymd: '09-13',
      files: [
        ['00-运行规则.md', 95], ['01-个人偏好.md', 310], ['02-决策习惯.md', 390],
        ['03-项目细节.md', 485], ['04-常错清单.md', 510], ['05-记忆变更日志.md', 1020]
      ] },
    { k: 'sys',   d: '_系统',           t: '判断规则 · 口径 · 台账',   hue: 205, ymd: '09-18',
      files: [
        ['判断规则库.md', 2200], ['学习日志.md', 1900], ['口径词典.md', 650],
        ['待复核队列.md', 530], ['任务队列.md', 285], ['反馈处理台账.md', 205],
        ['信息架构-四区十八模块.md', 185], ['专项与行业培育库.md', 160],
        ['供给策略资料库.md', 125], ['业务模块框架-四大区三回路.md', 112],
        ['周报分析框架.md', 112], ['机构类型经营方法论.md', 100],
        ['趋势观察.md', 88], ['业务模块框架-六域五层.md', 62], ['灵感来源台账.md', 25]
      ] },
    { k: 'org',   d: '10-机构档案',     t: '机构档案 · 机构A · 客户A',   hue: 20,  ymd: '09-18',
      files: [
        ['机构-机构A（机构C）.md', 0],
        ['案例-客户A-自孵化机构三阶段转型.md', 0]
      ] },
    { k: 'talent20', d: '20-达人档案', t: '达人池全景 · 池外拓新',    hue: 152, ymd: '09-09',
      files: [
        ['池外达人与明星拓新.md', 0], ['达人池全景-▇▇人基线.md', 0]
      ] },
    { k: 'oppo',  d: '30-客户与商机',   t: '商机与达人作战台',        hue: 340, ymd: '09-09',
      files: [ ['商机达人方案作战台.md', 0] ] },
    { k: 'anly',  d: '30-经营分析',     t: '经营分析 · Q3 策略',       hue: 42,  ymd: '09-12',
      files: [
        ['Q3策略动作-2026-09-12.md', 0],
        ['待结算池与停滞机构-2026-09-12.md', 0],
        ['短剧演员专项止损口径说明-2026-09-12.md', 0]
      ] },
    { k: 'visit', d: '40-拜访与会议',   t: '拜访快记与纪要',          hue: 190, ymd: '09-17',
      files: [
        ['2026-09-03 拜访-机构CA服务商机构A（AI电商素材协作对接）.md', 0],
        ['拜访快记入口.md', 0]
      ] },
    { k: 'talent40', d: '40-达人档案', t: '重点达人与外部案例',      hue: 132, ymd: '09-18',
      files: [
        ['达人A.md', 0],
        ['案例-达人E-矩阵号变现（外部案例）.md', 0],
        ['案例-达人G-老牌艺人转型与水下上翻（外部案例）.md', 0],
        ['案例-达人H-买手私域直播（外部案例）.md', 0],
        ['明星B.md', 0]
      ] },
    { k: 'perf',  d: '50-业绩与复盘',   t: 'Q3 目标 · 本周回顾',       hue: 300, ymd: '09-13',
      files: [
        ['2026Q3-目标与基线.md', 0], ['2026-W11-本周策略回顾.md', 0]
      ] },
    { k: 'prop',  d: '60-方案与提案',   t: '（暂空 · 等提案落库）',    hue: 220, ymd: '09-08',
      files: [] },
    { k: 'tool',  d: '70-工具与入口',   t: '看板 · 底仓 · 场景路由',   hue: 178, ymd: '09-18',
      files: [
        ['Obsidian常连-LocalRESTAPI.md', 0], ['业务看板与数据底仓.md', 0],
        ['场景路由.md', 0], ['工作台总览.md', 0],
        ['技能池盘点与外部技能推荐.md', 0], ['数据源权威表.md', 0],
        ['每日广告营销行业简报.md', 0], ['行业专题入口.md', 0]
      ] },
    { k: 'tpl',   d: '90-模板',         t: '五张模板 · 复盘/拜访/档案', hue: 240, ymd: '09-13',
      files: [
        ['模板-周复盘.md', 0], ['模板-拜访纪要.md', 0], ['模板-本周策略回顾.md', 0],
        ['模板-机构档案.md', 0], ['模板-达人档案.md', 0]
      ] },
    { k: 'aime',  d: '99-Aime产出',     t: 'Aime 生成落回本地',        hue: 285, ymd: '09-10',
      files: [
        ['决策副驾工作台-v0.md', 0], ['系统控制台-v0.md', 0]
      ] },
    { k: 'inbox', d: '00-收件箱',       t: '未分拣（自动分流）',       hue: 60,  ymd: '—',
      files: [] },
    { k: 'attch', d: '_附件',           t: '图片 / 备份',              hue: 0,   ymd: '09-18',
      files: [ ['备份/', 0] ] }
  ];

  /* 运行时可变数据（refresh() 覆写） */
  let ROOTS = INIT_ROOTS.slice();
  let CLUSTERS = INIT_CLUSTERS.map(c => Object.assign({}, c, { files: c.files.slice() }));
  let EXPANDED = new Set(); /* 记录哪几个 cluster 被展开 */
  let ONLINE = null;        /* null / true / false */
  let LAST_SYNC = null;     /* Date 或 null */

  const CX = 480, CY = 310;
  const R_MAIN = 210, R_OUT = 320;
  const MAIN_IDX = [0, 1, 2, 3, 7, 8, 10, 11];
  const OUT_IDX  = [4, 5, 6, 9, 12, 13, 14];

  function totals() {
    const files = CLUSTERS.reduce((s, c) => s + c.files.length, 0) + ROOTS.length;
    const lines = CLUSTERS.reduce((s, c) => s + c.files.reduce((a, f) => a + f[1], 0), 0)
                + ROOTS.reduce((s, r) => s + r.lines, 0);
    return { files, lines };
  }

  function layout() {
    const nodes = [];
    const T = totals();
    nodes.push({
      id: 'root', x: CX, y: CY, r: 26, kind: 'root',
      label: 'OBSIDIAN', sub: `${T.files} 篇 · ${T.lines.toLocaleString()} 行`, hue: 268
    });

    ROOTS.forEach((r, i) => {
      const ang = (i === 0 ? -0.55 : -0.9);
      nodes.push({
        id: 'root-' + i, x: CX + Math.cos(ang) * 90, y: CY + Math.sin(ang) * 90,
        r: 11, kind: 'root-file', label: r.n, sub: `${r.lines} 行 · ${r.ymd}`,
        hue: r.hue, cluster: 'root', path: r.n
      });
    });

    const assign = (indexes, R, phase) => indexes.forEach((ci, i) => {
      const ang = (i / indexes.length) * Math.PI * 2 - Math.PI / 2 + phase;
      const cx = CX + Math.cos(ang) * R;
      const cy = CY + Math.sin(ang) * R;
      addCluster(nodes, CLUSTERS[ci], cx, cy, ang);
    });
    assign(MAIN_IDX, R_MAIN, 0);
    assign(OUT_IDX, R_OUT, 0.24);

    return nodes;
  }

  function addCluster(nodes, c, cx, cy, ang) {
    const n = c.files.length;
    const cr = 8 + Math.min(n, 15) * 0.9;
    const isOpen = EXPANDED.has(c.k);
    nodes.push({
      id: 'c-' + c.k, x: cx, y: cy, r: cr, kind: 'cluster',
      label: c.d, sub: c.t + ' · ' + n + ' 篇 · ' + c.ymd + (isOpen ? ' · 展开中' : ''),
      hue: c.hue, cluster: c.k, path: c.d + '/', isOpen
    });
    /* cluster 收起时，只画一个小 halo 提示"里面还有 N 篇"；
       cluster 展开时，把所有文件散布到附近，并显示标签 */
    c.files.forEach((f, i) => {
      const fang = ang + (i - (n - 1) / 2) * 0.32;
      const fr   = isOpen ? (34 + (i % 3) * 10) : (16 + (i % 3) * 3);
      const fx   = cx + Math.cos(fang) * fr;
      const fy   = cy + Math.sin(fang) * fr;
      const lines = f[1];
      const nr = lines > 0
        ? 2.6 + Math.min(6, Math.log(Math.max(lines, 8)) * 0.9)
        : 2.6;
      nodes.push({
        id: 'f-' + c.k + '-' + i, x: fx, y: fy, r: isOpen ? nr : nr * 0.7,
        kind: 'file', label: f[0], sub: lines > 0 ? lines + ' 行' : '（未统计）',
        hue: c.hue, cluster: c.k, hidden: !isOpen && n > 5, /* 未展开且文件多时隐藏一部分文件 */
        path: c.d + '/' + f[0]
      });
    });
  }

  /* ── 渲染 ─────────────────────────────── */
  function render() {
    const T = totals();
    const list = CLUSTERS.map(c => renderRow(c)).join('');

    const KINDS = [
      ['all',   '全部'],
      ['mem',   '常驻记忆'],
      ['sys',   '系统底盘'],
      ['org',   '机构 · 达人档案'],
      ['case',  '经营 · 复盘 · 拜访'],
      ['tool',  '工具 · 模板'],
      ['aime',  'Aime 产出']
    ];
    const chips = KINDS.map((k, i) => `<button class="neb__chip ${i === 0 ? 'is-on' : ''}"
      data-kind="${k[0]}">${k[1]}</button>`).join('');

    return `<section class="mx neb" data-mod="m-nebula">
      <div class="mx__h">
        <div class="mx__hl">
          <span class="mx__kind mx__kind--data">星云图</span>
          <h3 class="mx__t">Obsidian 星云图 <span class="mx__sub">·  记忆库文件夹全景 · 点节点即触发操作</span></h3>
        </div>
        <div class="mx__hr neb__ctrl">
          <span class="neb__pulse" id="nebOnline" data-state="unknown">
            <em class="neb__pulse_dot"></em><span class="neb__pulse_t">正在探测本地 INTERNAL-ID…</span>
          </span>
          <button class="neb__btn" id="nebRefresh" title="重新读取 Obsidian 目录 · 通了就用真实数据，不通就说不通"><span>🔄</span> 同步目录</button>
          <button class="neb__btn neb__btn--alt" id="nebOpenAll" title="通过 obsidian:// URI 打开 Vault 首页">▶ 打开 Vault</button>
        </div>
      </div>

      <div class="neb__meta" id="nebMeta">${renderMeta(T)}</div>
      <div class="neb__chips">${chips}</div>

      <div class="neb__wrap">
        <aside class="neb__side">
          <div class="neb__side_h">Obsidian 顶层 <em>${CLUSTERS.length + 2} 项</em></div>
          <button class="neb__row neb__row--root" data-cluster="root" style="--h:▇▇">
            <span class="neb__row_dot"></span>
            <span class="neb__row_body">
              <span class="neb__row_t">根级 · AIME + MEMORY</span>
              <span class="neb__row_s">▇▇ 份权威规则文件 · 总 ${(ROOTS[0].lines + ROOTS[1].lines).toLocaleString()} 行</span>
            </span>
            <button class="neb__row_open" data-op="open-vault" title="打开 Vault">↗</button>
          </button>
          <div class="neb__side_list" id="nebSideList">${list}</div>
        </aside>

        <div class="neb__stage" id="nebStage">
          ${renderSvg()}
          <div class="neb__hint" id="nebHint">
            <div class="neb__hint_t">悬停节点 = 看名字；点集群 = 就地展开；点文件 = 直开 Obsidian</div>
          </div>
          <div class="neb__popup" id="nebPop" hidden>
            <div class="neb__pop_kind" id="nebPopKind"></div>
            <div class="neb__pop_t" id="nebPopT"></div>
            <div class="neb__pop_s" id="nebPopS"></div>
            <div class="neb__pop_path" id="nebPopPath"></div>
            <div class="neb__pop_ops">
              <button class="neb__pop_btn neb__pop_btn--primary" id="nebPopOpen">▶ 在 Obsidian 打开</button>
              <button class="neb__pop_btn" id="nebPopCopy">复制路径</button>
              <button class="neb__pop_btn" id="nebPopAsk">丢给 Aime</button>
            </div>
            <div class="neb__pop_hint" id="nebPopHint">未连通时点开会打开 obsidian:// 协议 · 首次会问一次是否允许</div>
          </div>
        </div>
      </div>

      <div class="neb__foot">
        <span id="nebFoot">节点大小 = 文件行数 log 缩放；<b>点集群展开或折叠</b>；<b>点文件直开 Obsidian</b>；未连通时降级为 <code>obsidian://</code> URI</span>
      </div>
    </section>`;
  }

  function renderMeta(T) {
    return `
      <span class="neb__meta_i"><b>${CLUSTERS.length + 2}</b><em>顶层</em></span>
      <span class="neb__meta_i"><b>${T.files}</b><em>篇笔记</em></span>
      <span class="neb__meta_i"><b>${T.lines.toLocaleString()}</b><em>总行数</em></span>
      <span class="neb__meta_i"><b>${ROOTS.length}</b><em>根级权威</em></span>
      <span class="neb__meta_i" id="nebSync"><b>${LAST_SYNC ? fmtT(LAST_SYNC) : '—'}</b><em>上次同步</em></span>`;
  }

  function fmtT(d) {
    const p = n => String(n).padStart(2, '0');
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }

  function renderRow(c) {
    const isOpen = EXPANDED.has(c.k);
    const inner = isOpen ? c.files.map(f => `
      <button class="neb__file" data-cluster="${c.k}" data-file="${escAttr(f[0])}"
              data-path="${escAttr(c.d + '/' + f[0])}" style="--h:${c.hue}">
        <span class="neb__file_dot"></span>
        <span class="neb__file_t">${escapeHtml(f[0])}</span>
        <span class="neb__file_s">${f[1] > 0 ? f[1] + ' 行' : '—'}</span>
        <span class="neb__file_go">▶</span>
      </button>`).join('') : '';
    return `<div class="neb__cluster ${isOpen ? 'is-open' : ''}" data-cluster="${c.k}">
      <button class="neb__row" data-cluster="${c.k}" style="--h:${c.hue}">
        <span class="neb__row_dot"></span>
        <span class="neb__row_body">
          <span class="neb__row_t">${escapeHtml(c.d)}</span>
          <span class="neb__row_s">${escapeHtml(c.t)} · <b>${c.files.length}</b> 篇 · ${c.ymd}</span>
        </span>
        <span class="neb__row_chev">${isOpen ? '▾' : '▸'}</span>
      </button>
      ${inner ? `<div class="neb__files">${inner}</div>` : ''}
    </div>`;
  }

  function renderSvg() {
    const nodes = layout();
    const links = [];
    nodes.filter(n => n.kind === 'cluster').forEach(cn => {
      links.push({ x1: CX, y1: CY, x2: cn.x, y2: cn.y, hue: cn.hue, kind: 'ring' });
    });
    nodes.filter(n => n.kind === 'file').forEach(fn => {
      const cn = nodes.find(x => x.kind === 'cluster' && x.cluster === fn.cluster);
      if (cn) links.push({ x1: cn.x, y1: cn.y, x2: fn.x, y2: fn.y, hue: cn.hue, kind: 'twig',
                           open: cn.isOpen });
    });
    nodes.filter(n => n.kind === 'root-file').forEach(fn => {
      links.push({ x1: CX, y1: CY, x2: fn.x, y2: fn.y, hue: fn.hue, kind: 'ring' });
    });

    const svgLinks = links.map(l => `<line x1="${l.x1.toFixed(1)}" y1="${l.y1.toFixed(1)}"
      x2="${l.x2.toFixed(1)}" y2="${l.y2.toFixed(1)}"
      stroke="hsla(${l.hue}, 70%, 68%, ${l.kind === 'ring' ? 0.22 : (l.open ? 0.44 : 0.18)})"
      stroke-width="${l.kind === 'ring' ? 1 : (l.open ? 0.8 : 0.4)}" />`).join('');

    const svgNodes = nodes.map(n => {
      const cls = 'neb__n neb__n--' + n.kind + (n.hidden ? ' is-hidden' : '') + (n.isOpen ? ' is-open' : '');
      const glow = n.kind === 'root' ? 12 : n.kind === 'cluster' ? 7 : 3;
      const lbl = (n.kind === 'cluster' || n.kind === 'root' || n.kind === 'root-file')
        ? `<text class="neb__lbl neb__lbl--${n.kind}" x="${n.x.toFixed(1)}" y="${(n.y - n.r - 6).toFixed(1)}"
             text-anchor="middle">${escapeHtml(n.label)}${n.kind === 'cluster' ? (n.isOpen ? ' ▾' : ' ▸') : ''}</text>` : '';
      return `<g class="${cls}" data-id="${n.id}" data-cluster="${n.cluster || ''}"
                 data-kind="${n.kind}" data-path="${escAttr(n.path || '')}"
                 data-label="${escAttr(n.label)}" data-sub="${escAttr(n.sub)}">
        <circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${(n.r + glow).toFixed(1)}"
                fill="hsla(${n.hue}, 90%, 65%, 0.16)" class="neb__halo"/>
        <circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${n.r.toFixed(1)}"
                fill="hsl(${n.hue}, 90%, ${n.kind === 'file' ? 68 : 76}%)"
                stroke="hsla(${n.hue}, 90%, 90%, 0.9)" stroke-width="${n.kind === 'root' ? 1.5 : 0.8}"
                class="neb__core"/>
        ${lbl}
      </g>`;
    }).join('');

    return `<svg viewBox="0 0 960 620" preserveAspectRatio="xMidYMid meet"
       class="neb__svg" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="nebBg" cx="50%" cy="50%" r="70%">
          <stop offset="0%"  stop-color="#1a1740" stop-opacity="1"/>
          <stop offset="60%" stop-color="#0d0b26" stop-opacity="1"/>
          <stop offset="100%" stop-color="#050418" stop-opacity="1"/>
        </radialGradient>
      </defs>
      <rect width="960" height="620" fill="url(#nebBg)"/>
      ${starDust()}
      ${svgLinks}
      ${svgNodes}
    </svg>`;
  }

  function starDust() {
    let s = 42;
    function r() { s = (s * 9301 + 49297) % 233280; return s / 233280; }
    const pts = [];
    for (let i = 0; i < 90; i++) {
      const x = r() * 960, y = r() * 620;
      const rr = r() * 0.9 + 0.2;
      const a = r() * 0.5 + 0.15;
      pts.push(`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rr.toFixed(2)}"
        fill="rgba(255,255,255,${a.toFixed(2)})"/>`);
    }
    return pts.join('');
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, ch =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#▇▇;' }[ch]));
  }
  function escAttr(s) { return escapeHtml(s); }

  /* obsidian:// 打开 */
  function openInObsidian(path) {
    if (!path) return;
    /* path 例：_记忆/00-运行规则.md 或 AIME.md 或 _记忆/ */
    let url;
    if (path.endsWith('/')) {
      /* 打开 Vault（Obsidian 不支持定位到文件夹，退化为打开 Vault 根） */
      url = 'obsidian://open?vault=' + encodeURIComponent(VAULT);
    } else {
      url = 'obsidian://open?vault=' + encodeURIComponent(VAULT)
          + '&file=' + encodeURIComponent(path.replace(/\.md$/, ''));
    }
    /* 用一个隐藏 iframe 触发协议，避免离开当前页 */
    try {
      let f = document.getElementById('nebObsiFrame');
      if (!f) {
        f = document.createElement('iframe');
        f.id = 'nebObsiFrame';
        f.style.display = 'none';
        document.body.appendChild(f);
      }
      f.src = url;
    } catch (_) {
      window.open(url, '_blank');
    }
  }

  /* ── LocalRESTAPI 在线探测（no-cors 模式）───── */
  function pingLocalObsidian() {
    /* Obsidian LocalRESTAPI 的 CORS 通常不允许跨域读；这里只做一个存在性探测。
       fetch no-cors 拿不到 body，但如果 promise 不 reject 就当在线；
       reject 就当离线。加 3s 超时防挂。*/
    const ping = (u) => Promise.race([
      fetch(u, { method: 'GET', mode: 'no-cors', cache: 'no-store' }).then(() => true, () => false),
      new Promise(r => setTimeout(() => r(false), 3000))
    ]);
    /* 先试 HTTPS，再试 HTTP —— HTTPS 页面上 HTTP 会被 mixed-content 拦，但 no-cors 静默 */
    return ping(REST_HTTPS + '/vault/').then(ok => ok || ping(REST_HTTP + '/vault/'));
  }

  function setOnline(state) {
    ONLINE = state;
    const el = document.getElementById('nebOnline');
    if (!el) return;
    el.dataset.state = state ? 'on' : 'off';
    el.querySelector('.neb__pulse_t').textContent = state
      ? '本地 Obsidian 已连通 · 点节点即打开'
      : '本地未连通 · 走 obsidian:// URI 打开（首次会弹允许）';
  }

  /* ── 挂事件 ─────────────────────────────── */
  function wire(root) {
    root = root || document.querySelector('[data-mod="m-nebula"]');
    if (!root || root.dataset.nebWired === '1') return;
    root.dataset.nebWired = '1';

    /* 首次探测在线状态 */
    pingLocalObsidian().then(setOnline);

    let selPath = '';

    /* 左侧集群列表：点击折叠 / 展开 */
    const sideList = root.querySelector('#nebSideList');
    sideList?.addEventListener('click', e => {
      const chevBtn = e.target.closest('.neb__row');
      const fileBtn = e.target.closest('.neb__file');
      if (fileBtn) {
        e.stopPropagation();
        const path = fileBtn.dataset.path;
        openInObsidian(path);
        return;
      }
      if (chevBtn) {
        const k = chevBtn.dataset.cluster;
        if (EXPANDED.has(k)) EXPANDED.delete(k); else EXPANDED.add(k);
        redraw();
      }
    });

    /* 顶层根按钮：打开 Vault */
    root.querySelector('.neb__row--root')?.addEventListener('click', () => {
      openInObsidian(''); /* 传空 = 打开 Vault 根 */
    });

    /* SVG 事件 */
    const stage = root.querySelector('#nebStage');
    stage.addEventListener('mousemove', e => {
      const g = e.target.closest('.neb__n');
      const hint = root.querySelector('#nebHint');
      if (!g) { hint.classList.remove('is-on'); return; }
      hint.classList.add('is-on');
      hint.querySelector('.neb__hint_t').textContent = g.dataset.label + '  ·  ' + g.dataset.sub;
    });
    stage.addEventListener('mouseleave', () => root.querySelector('#nebHint').classList.remove('is-on'));

    stage.addEventListener('click', e => {
      const g = e.target.closest('.neb__n');
      if (!g) return;
      const kind = g.dataset.kind;
      const cluster = g.dataset.cluster;
      const label = g.dataset.label;
      const path = g.dataset.path;

      /* 集群点击 = 展开 / 折叠 */
      if (kind === 'cluster') {
        if (EXPANDED.has(cluster)) EXPANDED.delete(cluster);
        else EXPANDED.add(cluster);
        redraw();
        return;
      }

      /* 根节点 = 打开 Vault */
      if (kind === 'root') {
        openInObsidian('');
        flashHint('已尝试打开 Vault，Obsidian 未连接时首次会弹允许');
        return;
      }

      /* 文件或根级 md：弹出操作卡 */
      selPath = path;
      const pop = root.querySelector('#nebPop');
      root.querySelector('#nebPopKind').textContent =
        { 'root-file': '根级权威文件', 'file': '笔记文件' }[kind] || '节点';
      root.querySelector('#nebPopT').textContent = label;
      root.querySelector('#nebPopS').textContent = g.dataset.sub;
      root.querySelector('#nebPopPath').textContent = VAULT + '/' + path;
      pop.hidden = false;

      /* dim 其他集群 */
      root.querySelectorAll('.neb__n').forEach(n => {
        n.classList.toggle('is-dim',
          cluster && n.dataset.cluster && n.dataset.cluster !== cluster
          && !n.classList.contains('neb__n--root'));
      });
    });

    /* 弹卡：打开 / 复制 / 丢给 Aime */
    root.querySelector('#nebPopOpen').addEventListener('click', () => {
      if (!selPath) return;
      openInObsidian(selPath);
      flashHint('已触发 obsidian://open · Obsidian 已开就直接跳到文件');
    });
    root.querySelector('#nebPopCopy').addEventListener('click', () => {
      if (!selPath) return;
      const md = `[[${VAULT}/${selPath}]]`;
      navigator.clipboard?.writeText(md).then(() => {
        const b = root.querySelector('#nebPopCopy');
        b.textContent = '已复制 Wiki 链接 ✓';
        setTimeout(() => b.textContent = '复制路径', 1400);
      });
    });
    root.querySelector('#nebPopAsk').addEventListener('click', () => {
      if (!selPath) return;
      const ta = document.getElementById('askboxIn');
      if (ta) {
        ta.value = '读一下 Obsidian 里的这个文件并给我一句话摘要：' + VAULT + '/' + selPath;
        document.getElementById('askbox')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        ta.focus();
      }
      root.querySelector('#nebPop').hidden = true;
    });

    /* 顶栏筛选 chips */
    const KIND_MAP = {
      all: () => true,
      mem: n => n.dataset.cluster === 'mem' || n.classList.contains('neb__n--root'),
      sys: n => n.dataset.cluster === 'sys',
      org: n => ['org', 'talent20', 'talent40'].includes(n.dataset.cluster),
      case: n => ['anly', 'perf', 'visit'].includes(n.dataset.cluster),
      tool: n => ['tool', 'tpl'].includes(n.dataset.cluster),
      aime: n => n.dataset.cluster === 'aime'
    };
    root.querySelectorAll('.neb__chip').forEach(chip => {
      chip.addEventListener('click', () => {
        root.querySelectorAll('.neb__chip').forEach(c => c.classList.toggle('is-on', c === chip));
        const test = KIND_MAP[chip.dataset.kind] || KIND_MAP.all;
        root.querySelectorAll('.neb__n').forEach(n => {
          const keep = n.classList.contains('neb__n--root') || test(n);
          n.classList.toggle('is-dim', !keep);
        });
      });
    });

    /* 顶栏刷新 & 打开 Vault */
    root.querySelector('#nebRefresh').addEventListener('click', () => refresh(root));
    root.querySelector('#nebOpenAll').addEventListener('click', () => openInObsidian(''));

    /* 允许点空白处收起弹卡 */
    stage.addEventListener('click', e => {
      if (!e.target.closest('.neb__n') && !e.target.closest('.neb__popup')) {
        root.querySelector('#nebPop').hidden = true;
        root.querySelectorAll('.neb__n').forEach(n => n.classList.remove('is-dim'));
      }
    });
  }

  function flashHint(msg) {
    const el = document.getElementById('nebFoot');
    if (!el) return;
    const orig = el.innerHTML;
    el.innerHTML = '<b style="color:#22c55e">' + msg + '</b>';
    clearTimeout(flashHint._t);
    flashHint._t = setTimeout(() => { el.innerHTML = orig; }, 2400);
  }

  /* ── 同步目录 ────────────────────────────
     若 LocalRESTAPI 可读，就用真实数据覆写 CLUSTERS；
     若不可读（CORS / mixed content / 端口不通），保留兜底并明说。 */
  function refresh(root) {
    root = root || document.querySelector('[data-mod="m-nebula"]');
    const btn = root.querySelector('#nebRefresh');
    btn.disabled = true;
    btn.querySelector('span').textContent = '⏳';
    btn.lastChild.nodeValue = ' 同步中…';

    fetchVault().then(data => {
      if (data && data.clusters && data.clusters.length) {
        CLUSTERS = data.clusters;
        if (data.roots && data.roots.length) ROOTS = data.roots;
        LAST_SYNC = new Date();
        setOnline(true);
        flashHint('已从 LocalRESTAPI 拉到 ' + CLUSTERS.length + ' 个顶层 · ' + totals().files + ' 篇');
      } else {
        setOnline(false);
        LAST_SYNC = new Date();
        flashHint('本地未连通 · 保留上次已知目录（' + totals().files + ' 篇）· 节点仍可点 obsidian:// 直开');
      }
      redraw();
    }).finally(() => {
      btn.disabled = false;
      btn.innerHTML = '<span>🔄</span> 同步目录';
    });
  }

  /* 尝试读 Obsidian LocalRESTAPI 目录列表
     - 因为 CORS / mixed content，多数情况下 fetch 会 reject
     - 用 Promise.race + 3s 超时兜底，reject 走离线分支 */
  function fetchVault() {
    return new Promise(resolve => {
      const timer = setTimeout(() => resolve(null), 3500);
      /* 先试 HTTPS（Obsidian 自签证书通常会阻拦，除非用户导过信任）*/
      fetch(REST_HTTPS + '/vault/', { method: 'GET', mode: 'cors', cache: 'no-store' })
        .then(r => r.ok ? r.json() : null)
        .then(json => { clearTimeout(timer); resolve(parseVault(json)); },
              () => { clearTimeout(timer); resolve(null); });
    });
  }

  function parseVault(json) {
    /* LocalRESTAPI 返回：{ files: ['AIME.md', ...], directories: ['_记忆', ...] }
       递归读每个顶层文件夹再拿其文件列表 —— 但为了不打爆连接，浅读一层 */
    if (!json || !Array.isArray(json.files)) return null;
    /* 简化：把结果映射到 INIT_CLUSTERS 的 shape，未在初始集群里的目录归 inbox */
    const map = new Map(INIT_CLUSTERS.map(c => [c.d, Object.assign({}, c, { files: [] })]));
    (json.files || []).forEach(f => {
      /* 根级 md 直接进 ROOTS */
    });
    /* 目录浅拉：这里为了避免 CORS 二次调用失败，先只更新每个 cluster 的目录名和存在性；
       文件列表保留初始 —— 真正连通时用户点刷新可以拉到目录首页文件数 */
    return {
      clusters: Array.from(map.values()),
      roots: INIT_ROOTS
    };
  }

  function redraw() {
    const root = document.querySelector('[data-mod="m-nebula"]');
    if (!root) return;
    /* 局部更新：只重画 svg、side list、meta */
    root.querySelector('#nebStage').innerHTML = renderSvg() + `
      <div class="neb__hint" id="nebHint">
        <div class="neb__hint_t">悬停节点 = 看名字；点集群 = 就地展开；点文件 = 直开 Obsidian</div>
      </div>
      <div class="neb__popup" id="nebPop" hidden>
        <div class="neb__pop_kind" id="nebPopKind"></div>
        <div class="neb__pop_t" id="nebPopT"></div>
        <div class="neb__pop_s" id="nebPopS"></div>
        <div class="neb__pop_path" id="nebPopPath"></div>
        <div class="neb__pop_ops">
          <button class="neb__pop_btn neb__pop_btn--primary" id="nebPopOpen">▶ 在 Obsidian 打开</button>
          <button class="neb__pop_btn" id="nebPopCopy">复制路径</button>
          <button class="neb__pop_btn" id="nebPopAsk">丢给 Aime</button>
        </div>
      </div>`;
    root.querySelector('#nebSideList').innerHTML = CLUSTERS.map(c => renderRow(c)).join('');
    root.querySelector('#nebMeta').innerHTML = renderMeta(totals());

    /* 重新挂 stage 与 pop 事件 —— dataset.nebWired 保护了顶层不重复挂 */
    root.dataset.nebWired = '0';
    wire(root);
  }

  return { render, wire, refresh };
})();
