/* ═══════════════════════════════════════════════════════════
   spk.js —— 灵感库 · 我主动给你的方向（她 2026-09-16 要的）

   她的原话：
     「这里的灵感，不仅仅是需要我看到的，也需要你不断从市场上或者
       现有的工作台中，你主动反馈给我可以尝试的方向」

   所以灵感库从"一个等你扔东西的收件口"改成两条腿：
     左腿（原来就有）：你随手扔 → 我按标签落进 Obsidian 对应目录
     右腿（今天新增）：**我主动去找 → 每条带出处、带你手上能接的资源、带第一步**

   ⛔ 四条硬规矩，缺一条这一页就变成资讯摘抄：
     ▇▇. 每条必须写清"我从哪看到的"，官方能力给官方链接，第三方观点标第三方；
     ▇▇. 每条必须写清"你手上什么能接"，接不上的方向不摆上来；
     ▇▇. 每条必须有"第一步做什么"，且这一步今天或本周能动；
     ▇▇. 每条必须写"我有几分把握 + 什么情况算我错" —— 没有证伪条件的不算方向，算废话。

   ⚠️ 她自己批过的红线：趋势观察每周最多 ▇▇条写进仓库，写到第四条就是在抄资讯。
      所以页面上摆 ${n} 条，**只有我标了"进仓库"的 ▇▇条会写进趋势观察**，其余只在页面上活着。
   ═══════════════════════════════════════════════════════════ */
window.SPK = (function () {

  const SKEY = 'cec.spk.v3';

  /* ── 她 2026-10-10 11:04 在对话里最新点过的（▇▇）──
     仅 ▇▇ 招募一口价达人团。
     新版本使用独立存储键，确保这次 ▇▇ 的确认覆盖 10-09 的旧 ▇▇ 状态。 */
  const PICK = { d3: 'y' };
  const PICKAT = '▇▇-10 11:▇▇';

  /* 生效状态 = 她 10-10 点过的 ▇▇条（底） + 她在这一页改过的（覆盖）
     ⛔ 坑：撤销必须存成 ''（记住"她撤了"），不能删 key —— 删了默认值又会把它顶回"要打" */
  function eff() {
    const st = sLoad(), out = Object.assign({}, PICK);
    Object.keys(st).forEach(k => { out[k] = st[k] || ''; });
    return out;
  }
  function edited(k) { const st = sLoad(); return Object.prototype.hasOwnProperty.call(st, k); }

  /* src: mkt 官方市场能力 / desk 工作台运行观察 / base 底仓信号 / talk 第三方观点（未验证） */
  const SRCK = {
    mkt:  ['📡 市场信号 · 官方能力', 'is-mkt'],
    desk: ['🖥️ 工作台观察 · 你自己的数', 'is-desk'],
    base: ['📊 底仓信号 · 作战台实测', 'is-base'],
    talk: ['🗣️ 第三方观点 · 未验证', 'is-talk']
  };

  /* 每条：
     t 方向（一句话说完）        src 来源类型
     from 我从哪看到的（带链接）  hold 你手上什么能接（具体资源数）
     step 第一步做什么           bet  我有几分把握 + 什么算我错
     vault 会不会写进仓库趋势观察（每周最多 ▇▇条，这是她的红线） */
  const DIR = [
    { t: '客户只要素材不要本人出镜的那批需求，走星图「素材任务」承接', src: 'mkt', vault: 1, hot: 1,
      from: '星图帮助中心 · <a href="https://www.xingtu.cn/help-center/demander/206682" target="_blank" rel="noopener">素材任务</a>：官方说明素材任务与素材授权的下单方式，页面上仍标着部分能力在内测、需要联系星图销售配置。<b>你本人就是那个"星图销售"入口</b> —— 这一条对别人是门槛，对你是优势。',
      hold: '需求端已经有实证：<b>▇▇条明星 / 演员类商机里，▇▇条明确只要素材或肖像授权、不要本人出镜</b>（作战台 09-12 实测）。供给端还有 ▇▇位无刊例达人 —— 不能报价出镜，但不代表不能供素材。',
      step: '本周从那 ▇▇条里挑 ▇▇条，问客户一句"这条走素材任务行不行"；同时替自己确认一件事：这个能力在你账号下开没开、要不要走配置。',
      bet: '<b>需求端我有实证（▇▇条），供给端我一个字都没有</b> —— 我不知道那 ▇▇位手里有没有可授权的存量素材。<b>什么算我错</b>：抽查 ▇▇位发现多数没有能授权的存量素材，这条就降级为"只对明星线成立"。' },

    { t: '把"素材被白用"改成一笔可结算收入：指派任务下单时单列素材授权费', src: 'mkt', vault: 1, hot: 1,
      plan: { w: '本周先打 ▇▇张真实订单',
        one: '优先找<b>客户G × 客户J / 客户I</b>：客户G Q3 已完成 ▇▇万 / ▇▇单，两家合计已有 ▇▇单指派合作；下一张指派单把授权从“顺手送”改成单列报价。',
        give: '我给你的东西：一页对客说法（授权费怎么解释、客户问“凭什么加钱”怎么答）+ 官方能力出处链接；报价同时写清授权范围与时长。',
        fail: '连续谈两张真实订单，客户都宁可不要授权也不加钱 → 这条降级成“机构侧自我保护条款”，不再算增收方向。' },
      from: '星图帮助中心 · <a href="https://www.xingtu.cn/help-center/demander/139122" target="_blank" rel="noopener">指派任务支持下单增加素材授权费</a>：官方说明授权费可与商单一口价合并支付结算。',
      hold: '这一条同时压住两个你天天遇到的矛盾：<b>客户要压价</b>、<b>机构怕素材被白用</b>。原来"授权顺手送"的部分，现在有一个官方的收费位置。',
      step: '下一场机构拜访就带这一条去：把"授权免费给"改成"授权费单列"，先谈一家，看客户加不加。',
      bet: '<b>能力是官方明确的，但能不能真的提总价，我没有一个成交样本。</b><b>什么算我错</b>：谈两家客户都宁可不要授权也不加钱，那这条就只能当机构侧的自我保护条款，不算增收方向。' },

    { t: '你 09-13 说客户要"后链路转化"—— 官方现成链路是：达人素材一键推千川 / 巨量营销 / 本地推 / DOU+', src: 'mkt', vault: 1,
      plan: { w: '本周做 ▇▇次带客户名的提案',
        one: '优先找<b>客户H × 客户I</b>（备选达人B）：客户H Q3 已完成 ▇▇万 / ▇▇单；把“达人内容好”改成“▇▇次生产 + 多端复用”的交付结构。',
        give: '我给你的东西：后链路投放端清单、授权时长与预审边界；明确<b>星图预审不等于投放平台最终审核通过</b>。',
        fail: '客户不需要复用，或投放端最终审核/适配持续不通过 → 这条不能作为该客户增量卖点。' },
      from: '星图帮助中心 · <a href="https://www.xingtu.cn/help-center/demander/114316" target="_blank" rel="noopener">视频支持推送巨量营销 / 千川 / 本地推 / DOU+</a>：官方说明星图任务视频可授权推送到这几个投放端复用。',
      hold: '这条不是我找来的新概念，是<b>你自己那句话的解法</b>：你 09-13 说「客户更追求性价比跟后链路转化能力，传统的定制视频内容难以满足客户需求」。这条链路把"一条内容只发一次"变成"一条内容能进投放账户反复用"。',
      step: '拜访话术改一句就行：从"这位达人内容好"改成"这条内容能直接推进你的千川账户复用，一条素材两次价值"。',
      bet: '<b>链路是官方的，我有把握；但复用之后的 ROI 我讲不了。</b>因为达人级的 CPA ▇▇ / 进店率 / 看后搜我们看板一个都没接（这也正是案例二第三层卡住的地方）。<b>所以这条只能讲"能复用"，不许讲"复用后效果提升多少"</b> —— 我要是哪天写了个提升百分比，你直接打回。' },

    { t: '腰部谈不动单个大单，那就组团报：招募任务一口价 + 达人团', src: 'mkt', hot: 1,
      plan: { w: '本周只挑 ▇▇个代表机构做试水',
        one: '<b>客户I</b> 先用美妆矩阵组 ▇▇–▇▇人，对已有美妆复投客户报一次；<b>客户J</b> 用 ▇▇位内容型达人做高调性小团备选，不给所有腰部机构硬摊目标。',
        give: '我给你的东西：两家组团候选人 + 客户拿到的交付 + 一口价和挂车佣金（T+S）结构建议。',
        fail: '客户仍然只挑其中一两个人下单，或交付无法标准化 → 客户要的是人不是包，这条作废。' },
      from: '星图帮助中心 · <a href="https://www.xingtu.cn/help-center/demander/143347" target="_blank" rel="noopener">招募任务一口价 · 带货达人团 / 高调性达人团</a>：官方说明这类任务面向中腰达人批量招募、种草与带货可同时算价值。',
      hold: 'Q3 实数提供了两个可试样本：<b>客户I ▇▇万 / ▇▇单 / ▇▇位变现达人</b>，<b>客户J ▇▇万 / ▇▇单 / ▇▇位变现达人</b>；两家都已有招募任务成交，不是从零发明形态。',
      step: '先让 客户I 报 ▇▇个美妆矩阵团；客户J 只做高调性小团备选，验证后再扩，不为凑数立目标。',
      bet: '<b>腰部掉队是实测，但"组团就能起量"在你盘里没有成交样本 —— 这条是推断。</b><b>什么算我错</b>：报了团客户仍然只挑其中一两个人下单，那说明客户要的是人不是包，这条作废。' },

    { t: '两个人裸跑出 ▇▇万，这条线到今天还没名单、没目标、没归属人', src: 'desk', hot: 1,
      from: '不是外面的信息，是<b>你自己的数</b>：达人A ▇▇万 + 达人B ▇▇万 QTD（业绩日报 09-11 结算口径），加起来接近一家腰部机构一个季度的量。',
      hold: '这是已经跑出来的钱，不需要任何新供给。而且筛"下一个她"的判据我已经压成五条，<b>前三条今天就能在 ▇▇人池里跑</b>（单均 ≥ 全盘 ▇▇倍 · 季度单量 ≤▇▇单 · 同比 ≥▇▇ 且基数 ≥▇▇万）。',
      step: 'Q4 拍一件事：要不要给"个体高溢价达人"立一张正式名单和目标。你说立，我当天把前三条判据跑出候选名单。',
      bet: '<b>数是实测的，能不能复制没验过。</b>五条判据里第四条（有不可替代的内容设定）我筛不了 —— 看不到内容；第五条（不在机构分层盘里）只能查打标名单，<b>查不出隐性经纪约，那部分只有你知道</b>。' },

    { t: '▇▇条点名商机点的人不在你池子里 —— 这是一张现成的拓新地图', src: 'base',
      plan: { w: '你说一声，当天出前 ▇▇位',
        one: '⚠️ 这条和等你拍板的事项第 ▇▇件是同一件事，你 09-16 已经改过范围：<b>先拎需求最多的前 ▇▇位，并排查是不是已经有对接同学</b>。所以我不做 ▇▇条的全量表。',
        give: '我给你的东西：前 ▇▇位一张表（被点次数 / 来自哪些客户与行业 / 是否已有对接同学·待排查）。<b>没排查完的一律标待排查，不写成可签。</b>',
        fail: '前 ▇▇位里多数已经有同事在对 → 这条就从"拓新地图"降级成"内部撞单预警表"，价值换了个方向但不算白做。' },
      from: '作战台 09-12 实测：点名类商机 ▇▇条，其中 <b>▇▇条（▇▇）点的人不在你 ▇▇人池内</b>。点得最多的是明星N ▇▇次，后面是明星O ▇▇ · 明星P ▇▇ · 明星Q ▇▇ · 明星R ▇▇ · 全嘻嘻 ▇▇。',
      hold: '不需要新工具、不需要新能力，拜访时多问一句就能用。',
      step: '下次见机构直接问："这几位你签得到哪一个？"签得到的当场记，签不到的问"你手上有没有同类型的"。',
      bet: '<b>词频是算出来的，这条把握最高。</b>唯一的毛病是数据新鲜度：<b>09-12 快照，数据管道还没接</b>（那件在协作机制里卡着要你一句话），所以每周会漂一点。' },

    { t: '市场在从"选人"往"选内容 / 二剪素材有效率"偏 —— 这条我只当话题，不当结论', src: 'talk',
      plan: { w: '一个月内攒证据，不进提案',
        one: '你 09-16 点了"这条要打"，但你自己也写了"我只当…"。<b>所以我按话题级打，不按结论级打</b>：拜访开场用一句，专门去接客户那句原话。',
        give: '我给你的东西：一句拜访开场话术 + 一个只记原话的口子（你把客户说的"我要素材不要出镜"原话丢给我，我攒够 ▇▇条就把它从观点升级成证据）。',
        fail: '一个月内攒不到 ▇▇ 句客户原话 → 我自己把它撤掉，不许它长期挂在页面上冒充趋势。' },
      from: '第三方媒体与行业讨论里反复出现的说法。<b>我没有找到任何官方口径支撑</b>，所以按规矩标成未验证。',
      hold: '如果这条成立，它解释了上面前三条为什么都指向素材：客户买的是可复用的内容资产，不只是一次曝光。',
      step: '只当拜访开场话题用一句，<b>不许写进提案、不许拿去支撑报价</b>。',
      bet: '<b>▇▇ 分把握，纯观点。</b>要变成能用的东西，需要一样具体的东西：你手上有没有客户明确说过"我要素材不要出镜"。<b>你有一句这样的原话，它就从观点变证据</b>；一个月内没有，我就把它撤掉。' }
  ];

  /* ── 我下周去哪儿找新方向（源要写死，不然这一页下周就没货）── */
  const WHERE = [
    ['星图帮助中心的更新页', '官方能力上新最快的地方，且更新有日期可核 —— 上面四条市场信号全部来自这里',
     '每周扫一次，只捞"能承接你现有需求"的，不捞纯功能说明'],
    ['你自己的工作台运行数据', '哪个数突然动了、哪条链一直不通、哪些资源摆着没用 —— 上面第 ▇▇条就是这么长出来的',
     '这一路最值钱，因为它天然接得上你手上的资源'],
    ['作战台的商机结构', '客户在要什么，比市场在说什么更硬 —— 上面第 ▇▇条就是从这里来的',
     '⚠️ 数据管道没接前，每次都要标快照日期'],
    ['竞媒动态（小红书蒲公英 / 快手磁力聚星）', '客户预算在几个平台之间挪，对手上了什么能力，你在谈判桌上要知道',
     '只看能力与结算规则变化，不看它们的公关稿'],
    ['行业媒体（巨量营销观察 / 广告狂人 / Morketing / ▇▇氪 / 艾瑞）', '拿观点和大盘背景，但一律标第三方未验证',
     '这一路产出的东西<b>默认不进仓库</b>，只当话题']
  ];


  /* ═══════════════════════════════════════════════════════
     外部 Skill 借力（她 2026-09-16 20:45 给的验收动作）
       「我给你分享一份大家日常分享的一些 skill 内容，请你看看有没有比较好的
         操作技巧，或者比较实用的策略，可以在我的框架上做延展结合的，
         给我几个建议方向」

     源：2026-10-10 生态 Skill 共创大赛作品清单（▇▇个作品）+ ▇▇ 份重点作品说明。
     ⛔ 我给自己定的四条，防止这一栏变成"技能推荐列表"：
       ▇▇. 只挑**能接进她已有框架**的，接不上的不写；
       ▇▇. 每条必须写清**嫁接到她哪一块**，不是"这个 skill 很好用"；
       ▇▇. 每条必须写**会不会重复造轮子**，能直接接的就说"别造，接"；
       ▇▇. 每条必须写**我做不到的部分**，未拿到入口或权限不写成已接入。
     ═══════════════════════════════════════════════════════ */
  const BSRC = 'https://docs.internal.example/docx/INTERNAL-ID';
  const BORROW = [
    { t: '客户 Brief 先路由成可提案打法，再进入现有筛人与 onepage 链路',
      from: '作品<b>「一键生成客户创新打法 Skill」</b>：输入客户背景与具体问题，按内容主题、机制选型、达人组合、预算节奏和案例证据输出一套打法，不停在泛泛创意。',
      graft: '接到<b>客户与商机需求 → 提案与组包</b>。它不替代现有达人筛选和 onepage，而是在两者前面补一层：先判断客户这次买的是内容、后链路、矩阵还是授权，再把明确的合作形态交给现有工具选人和出页。',
      first: '下一份真实 Brief 到手时先跑一单：我先交<b>▇▇ 句核心判断 + ▇▇个传播模块 + 每个模块的人选条件</b>，再进现有筛人链，不另造新提案工具。',
      dup: '<b>不重复，但必须守边界。</b>策划工作台和 onepage 已经负责筛人、预算与呈现；这里只补“Brief → 打法”的前置路由，绝不再做一套提案台。',
      lack: '没有真实客户 Brief、预算边界和交付约束时，我只能先搭路由，<b>不能凭空产出可发客户的正式方案</b>；最终发不发仍由你决定。' },

    { t: '把机构侧 ▇▇个零散能力收成一张「AI 经营升级菜单」',
      from: '作品<b>「机构工作台」</b>：把内容洞察、内容诊断、达人周报、精选诊断、刊例生成、破冰沟通和接单品牌汇总组合成机构内容团队与商务团队可用的一套经营工具。',
      graft: '接到<b>达人与机构供给 → 机构经营诊断</b>和<b>作战执行与节奏 → 拜访前准备</b>。不是把 ▇▇个能力全部搬进来，而是按机构类型与当场问题做菜单：缺选题、缺商机、缺刊例、缺内容诊断，各自只推一个入口。',
      first: '下一场真实机构拜访只试<b>一诊一招</b>：拜访前判断它最缺哪一项，现场只带对应能力；会后记录机构愿不愿用、用了有没有少一步。',
      dup: '<b>部分重复，所以不整包复制。</b>刊例、周报、机构诊断已有入口；只借“按问题配能力”的菜单法，不再新建第 ▇▇个模块。',
      lack: '我拿不到机构团队真实使用反馈，也不能替机构开通它们的权限；<b>未拿到入口的能力只标待索取，不写成已接入</b>。' },

    { t: '给 Obsidian 与策略资料库补上「收录—查重—过期」三道闸',
      from: '作品<b>「全自动资料百宝库」</b>：资料进入后自动收录、分类、去重、提醒和更新；价值不是多存材料，而是需要时能找到、过期时会暴露。',
      graft: '接到<b>认知与学习 → 记忆机制与同步</b>、<b>达人与机构供给 → 策略资料库</b>。每份新材料强制记录来源、业务入口、数据截止和失效条件；相同链接或同主题先查重，过期政策只保留玩法参考，不再报数字。',
      first: '先给本次 ▇▇ 份重点 Skill 说明做一轮样板：记录 ▇▇个可嫁接方向、▇▇个明确不接方向，并把“是否已有能力 / 何时需复核”写进台账。',
      dup: '<b>不重复。</b>Obsidian 已有目录、记忆和台账，但还缺自动查重与过期暴露；这条补的是治理机制，不是再建一个资料库。',
      lack: '我不是常驻进程，<b>无法在材料过期当天自动醒来提醒</b>；目前只能在每日刷新或下一次调用时做过期检查。' }
  ];

  /* ── 外部思维原料：不是书单，而是能嵌入她真实业务链路的判断工具 ──
     2026-10-10：结合 C 组周会、机构经营方法论、她的判断规则库与外部原始来源筛选。
     排序原则：使用频率 × 决策杠杆 × 上手成本；先学前 ▇▇个，其余按场景调用。 */
  const MODELS = [
    { rank: '主模型', t: 'JTBD：先问客户真正要完成什么，再谈达人和玩法', src: '名人B · Jobs to Be Done',
      link: 'https://www.christenseninstitute.org/theory/jobs-to-be-done/',
      why: '它最贴合你当前最大的业务错位：客户表面说“人选不对 / 报价贵”，真实任务可能已经从曝光变成<b>性价比、素材复用或后链路转化</b>。内部周会也明确沉淀过：先抓客户核心诉求，不要把实现方式当成目的。',
      use: '<b>拿到 Brief 或听到减投理由时</b>，固定追三问：① 这次最终拿什么指标验收？② 现在用什么替代方案完成？③ 为什么现在要变？答案出来后，再决定卖单达人、达人团、素材授权还是投流复用。',
      drill: '本周拿下一份真实 Brief，只写一张“任务卡”：情境 / 想取得的进展 / 当前阻力 / 验收指标。<b>先不写达人名</b>；写完再进筛人链。',
      guard: '⛔ JTBD 不是替客户脑补需求。客户未明确验收指标时标“未知”，继续问，不把推断写成事实。' },

    { rank: '总框架', t: '三 H：先看行业，再看机构，最后才下动作', src: '内部《像 CEO 一样思考》· MCN 场景学习沉淀',
      link: 'https://docs.internal.example/wiki/INTERNAL-ID',
      why: '它与现有机构经营资料天然同构：<b>How’s the industry → How’s the company → How to improve</b>。能防止你一上来就推政策、推达人，而没先判断行业预算、机构类型和真实伤口。',
      use: '<b>每次拜访前只做一页</b>：H▇▇行业现在往哪变；H2 这家机构属于强渠道型还是强内容型、卡在哪；H3 本次只带“一诊一招”。',
      drill: '给下一家要见的机构各写 ▇▇ 句，共 ▇▇ 句；删到最后只留 ▇▇个主判断、▇▇个证据、▇▇个动作。',
      guard: '⛔ 三 H 是提问顺序，不是三段资料摘抄。H3 动作必须能回指 H1/H2 的证据，否则不进拜访议程。' },

    { rank: '证据闸', t: '事实—观点—立场—信念：先分清一句话属于哪层', src: '名人A《底层逻辑》·《▇▇分钟商学院》',
      link: 'https://www.dedao.cn/ebook/detail?id=vExPL6aYQPjadpoZxR5r6KDkbNJVO0oZ1nw84GeXyLElm92gnMA1zvB7qMKpBGkj',
      why: '你的信息源同时有客户原话、机构说法、看板数字、行业文章。混在一起时最容易把<b>客户的立场当事实、把媒体观点当趋势</b>。这个模型能直接强化现有“事实 / 推断分开”和“数字带来源截止”的纪律。',
      use: '读材料或复盘沟通时给每句话贴 F/O/S/B：F 事实要核来源与日期；O 观点要找反证；S 立场要问谁因此获益；B 信念只用来理解分歧，不拿去证明业务结论。',
      drill: '每天挑 ▇▇条客户原话，拆成四栏。例如“达人太贵”只是立场；可核事实是预算、竞品报价与验收指标。',
      guard: '⛔ 分类不是为了反驳对方，而是为了决定下一步该“查数据、问原因还是谈交换”。' },

    { rank: '谈判锚', t: 'BATNA：压价前先算不成交时最好的替代方案', src: '机构BR',
      link: 'https://www.pon.harvard.edu/category/daily/batna/',
      why: '你经常同时面对客户压价、机构守价和权益交换。BATNA 能让“要不要让”从情绪判断变成有底线的比较，也贴合你已形成的原则：<b>预算真缩就动量，性价比质疑就加权益，不先砍单价</b>。',
      use: '谈前写四格：我方最好替代 / 对方可能替代 / 可交换权益 / 拒绝线。可交换项优先放素材授权范围、达人数量、排期、复用权，不把单价当唯一旋钮。',
      drill: '下一次报价前花 ▇▇ 分钟填四格；谈后记录“哪项交换真的推动成交”，沉淀成同类客户话术。',
      guard: '⛔ BATNA 不是虚张声势。没有真实替代方案就标弱，不编造“还有别的客户在抢”。' },

    { rank: '学习法', t: '检索练习 + 间隔复习：少重读，多从记忆里调用', src: '机构BS · Retrieval Practice',
      link: 'https://www.learningscientists.org/retrieval-practice',
      why: '你的资料已经很多，瓶颈不是继续收藏，而是<b>在真实 Brief、拜访和复盘里能否三秒调出正确模型</b>。检索练习比反复重读更适合把“看懂”变成“会用”。',
      use: '每学一个模型只留一张卡：触发句 / ▇▇个问题 / 一个真实例子 / 误用边界。第二天和一周后先合上资料口述，再对照补漏；每次真实使用后把例子回写 Obsidian。',
      drill: '先只练 JTBD 与三 H：明天各口述一次；下周从一份真实 Brief 和一次机构拜访各调用一次。',
      guard: '⛔ 能复述定义不算学会；只有在新场景里选对模型、问出新信息或改变动作，才算一次有效调用。' }
  ];

  const MODEL_ORDER = [
    ['先学什么', '<b>先学 JTBD + 三 H</b>：一个解决“客户到底要什么”，一个解决“先看什么再行动”。连续用在 ▇▇个真实场景后，再加其余模型。'],
    ['怎么串起来', '三 H 定位全局 → JTBD 拆客户任务 → 事实/观点/立场/信念校验证据 → BATNA 决定谈判底线 → 检索练习把案例变成长期记忆。'],
    ['暂不优先', 'SWOT、MECE、▇▇W2H、OODA 都有用，但现在不单独学：前三个容易变成填表，OODA 与你现有“观察—判断—行动—回写”闭环重叠。需要时把它们当工具，不再开一门课。']
  ];
  const MINDMAP_URL = 'https://docs.internal.example/docx/INTERNAL-ID';

  /* ── 她 2026-09-16 立的验收方式：她投喂外部素材 → 我回"能接进她框架的方向" ──
     她的原话：「我上一次补入了一份灵感来源的信息，后面可以这么对你验收动作」
     规则同步写进本地仓库 U-28 / J-16 / _系统/灵感来源台账.md，页面这一块只是把它摆到她眼前。 */
  const ACC = [
    ['借的是什么', '素材里<b>具体哪一条</b>能力、哪一句话，写清出处。<b>不许模糊成"业界都在这么做"</b> —— 那种话你自己就能说，不需要我。'],
    ['接到你哪一块', '必须点名你框架里的<b>具体位置</b>：等你拍板的事项第几件 / 每周二复盘第几段 / 哪一页 / 哪条你已经定过的口径。<b>接不到具体位置的，不算方向，只算资讯，我不端给你。</b>'],
    ['第一步', '小到<b>今天或者下一场拜访就能做</b>，而且是我自己能起的头，不是"等你先怎样"。'],
    ['会不会重复造轮子', '包含<b>"别造，直接接别人的"</b>这种结论 —— 你的时间比多一个功能值钱，劝我别做也算交付。'],
    ['我做不到的那部分', '照实说。<b>要你配合的不许写成我已经能做的</b>，要往外发东西给机构的我做好但不自己发。']
  ];
  const ACCB = [
    ['▇▇~▇▇条，宁少不凑', '素材里确实没有能接的，我就写"这份没有能接的"并说明为什么。<b>为了交差硬凑，比不交更糟。</b>'],
    ['你投喂当天给', '不攒到周会。你扔进来我当天回方向，回不了我告诉你什么时候回。'],
    ['三条我不越的线', '① 只在群里介绍过、<b>没有入口</b>的能力我不承诺接入，只标"要找贡献人要"；② <b>口径/看板类默认不接</b>（会跟你自己裁过的分层、专项、待结算池三口径打架）；③ 会往外发给机构或客户的，<b>发不发你说</b>。']
  ];
  const FEEDLOG = [
    { d: '2026-10-10', src: '外部思维原料 · 思维模型业务化筛选', link: 'https://www.christenseninstitute.org/theory/jobs-to-be-done/',
      out: '结合内部 C 组周会、机构经营资料和外部原始来源，筛出 <b>▇▇个模型</b>；明确先学 <b>JTBD + 三 H</b>，其余按证据校验、谈判和学习场景调用。',
      st: '已写进本页并补充 ▇▇ 分钟脑图入口；下一份真实 Brief 试 JTBD 任务卡，下一场机构拜访试三 H 一页纸，连续跑 ▇▇次后再判断是否沉淀为固定模板' },
    { d: '2026-10-10', src: '生态 Skill 共创大赛 · 多部门作品清单', link: BSRC,
      out: '核对 <b>▇▇个作品</b>并重点下钻 ▇▇个，留下 <b>▇▇个可嫁接方向</b>：Brief 前置路由、机构 AI 经营升级菜单、资料收录—查重—过期机制。',
      st: '你已同意继续；第 ▇▇条等下一份真实客户 Brief 先跑 ▇▇单，第 ▇▇条等下一场机构拜访试“一诊一招”，第 ▇▇条已从本次台账开始落地' },
    { d: '2026-09-16', src: '生态 Skill 共创大赛 · ▇▇个 Skill 全景手册', link: 'https://docs.internal.example/docx/INTERNAL-ID',
      out: '回了 <b>▇▇个嫁接方向</b>，其中第 ▇▇条结论是<b>劝我自己别造</b>；另附三句实话（约 ▇▇个点开即装 · ▇▇个没入口 · 业绩看板类 ▇▇个我不接）。',
      st: '历史记录保留在台账；本页借力区已替换为 2026-10-10 最新一批，不继续堆叠旧卡' }
  ];

  /* 本轮明确不接的能力 —— 劝自己别做也算交付 */
  const BWARN = [
    ['竞媒雷达追踪站：不重复建设', '已经安装并在外部大盘承担品牌五源回源；客户与商机页的重复入口也已按你要求删除。<b>继续用现有入口，不复制第二套。</b>'],
    ['渠道工作助理：不整体接入', '它的取数、追踪、触达闭环与现有 PRM / MMM / 业务工作区 / 每日刷新链高度重叠。<b>只借“异常 → 动作 → 回写”的闭环方法，不再引一个口径源。</b>']
  ];

  function sLoad() { try { return JSON.parse(localStorage.getItem(SKEY) || '{}') || {}; } catch { return {}; } }
  function sSave(v) { try { localStorage.setItem(SKEY, JSON.stringify(v)); } catch {} }

  function sync(silent) {
    if (!(window.FB && FB.submit)) return;
    const st = eff();
    const lines = DIR.map((d, i) => st['d' + i]
      ? `${String(i + 1).padStart(2, '0')} ${d.t.slice(0, 34)}… → ${st['d' + i] === 'y' ? '这条要打' : '这条不打'}`
      : null).filter(Boolean);
    if (!lines.length) return;
    const it = FB.submit({
      kind: 'idea', view: '灵感库',
      topic: 'spark-dir', topicName: `我主动提的方向，你点了 ${lines.length}/${DIR.length} 条`,
      text: lines.join('\n')
    });
    if (!silent && it && FB.toast) FB.toast(`收到 ${lines.length} 条 —— 要打的我这周就动，不打的我不再提第二遍`);
  }

  function repaint() {
    document.querySelectorAll('.spk').forEach(box => {
      const holder = box.parentElement; if (!holder) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = render();
      holder.replaceChild(tmp.firstElementChild, box);
    });
  }

  function renderModels() {
    return `<div class="spkmodels" data-mod="m-spkmodels" id="spkmodels">
      <div class="spk__sec spk__sec--models">
        <div class="spk__h"><span class="spk__n spk__n--models">最适合你当前业务的 ▇▇个思维模型</span>
          <em>不是通用书单，而是按<b>使用频率 × 决策杠杆 × 上手成本</b>筛出的业务工具。内部依据来自 C 组周会、机构经营方法论与现有判断规则；外部定义回到原始来源。<b>结论：先学 JTBD + 三 H，暂时不要同时铺开十几个模型。</b></em></div>
        <a class="spkmo__map" href="${MINDMAP_URL}" target="_blank" rel="noopener">
          <span><i>🧠</i><b>先看脑图 · ▇▇ 分钟掌握五模型调用链</b></span>
          <em>三 H 定位 → JTBD 拆任务 → 四层辨析验证据 → BATNA 定边界 → 检索间隔变能力</em>
          <strong>打开飞书脑图 ↗</strong>
        </a>
        <div class="spkmo__order">${MODEL_ORDER.map(m => `<div class="spkmo__oi"><b>${m[0]}</b><p>${m[1]}</p></div>`).join('')}</div>
        <div class="spkmo__list">${MODELS.map((m, i) => `<article class="spkmo${i < 2 ? ' is-first' : ''}">
          <div class="spkmo__h"><i>${String(i + 1).padStart(2, '0')}</i><span>${m.rank}</span><b>${m.t}</b></div>
          <a class="spkmo__src" href="${m.link}" target="_blank" rel="noopener">来源 · ${m.src} ↗</a>
          <p><span>为什么适合你</span>${m.why}</p>
          <p><span>业务里怎么用</span>${m.use}</p>
          <p><span>▇▇ 天内怎么练</span>${m.drill}</p>
          <p class="spkmo__guard"><span>误用边界</span>${m.guard}</p>
        </article>`).join('')}</div>
        <div class="spkmo__rule"><b>你的学习闭环</b><span>看懂定义不算完成 → 用真实 Brief / 拜访 / 报价跑一次 → 记录它改变了哪条判断或动作 → 第二天与一周后合上资料复述 → 回写一个自己的案例。</span></div>
      </div>
    </div>`;
  }

  function render() {
    const st = eff();
    const yes = DIR.filter((d, i) => st['d' + i] === 'y').length;
    const done = DIR.filter((d, i) => st['d' + i]).length;
    const vn = DIR.filter(d => d.vault).length;
    return `<div class="spk" data-mod="m-spk" id="spk">

      <div class="spk__hd">
        <span class="spk__tag">主动建议方向</span>
        <div class="spk__hdx">
          <b>本周 ${DIR.length} 条 · 你 ${PICKAT} 点了 ${Object.keys(PICK).length} 条要打 · 现在生效 ${done} 条（其中要打 ${yes} 条）</b>
          <button class="spk__rst" type="button">回到你原来点的 ${Object.keys(PICK).length} 条</button>
          <em>你说灵感「不仅仅是需要我看到的，也需要你不断从市场上或者现有的工作台中主动反馈给我可以尝试的方向」——
          所以这一块是我去找的，不是等你扔的。<b>每条都写清：我从哪看到的 · 你手上什么能接 · 第一步做什么 · 我有几分把握、什么情况算我错。</b></em>
        </div>
      </div>

      ${yes ? `<div class="spk__go">
        <span class="spk__gk">你点了要打的 ${yes} 条 · 各自的第一步（这一栏就是这一页的用处）</span>
        <ol class="spk__gl2">${DIR.map((d, i) => (st['d' + i] === 'y' && d.plan)
          ? `<li><b>${d.t.length > 30 ? d.t.slice(0, 30) + '…' : d.t}</b>
              <span class="spk__gw">${d.plan.w}</span>
              <em>${d.plan.one.replace(/<[^>]+>/g, '')}</em></li>` : '').join('')}</ol>
        <p class="spk__gf">这 ${yes} 条我不再问你第二遍，按上面的第一步走；<b>每条都写了"什么情况算打输了"</b>，输了我自己撤，不让它烂在页面上。</p>
      </div>` : ''}

      <div class="spk__law">
        <span>⚠️ 你自己批过的红线我没绕</span>
        <p>趋势观察<b>每周最多 ▇▇条</b>写进仓库，写到第四条就是在抄资讯。所以这 ${DIR.length} 条里<b>只有 ${vn} 条我标了「会写进仓库」</b>，其余只在这一页上活着 ——
        没被你点"要打"、也没进仓库的，下周我自己撤掉，不许堆着。</p>
      </div>

      <div class="spk__l">${DIR.map((d, i) => {
        const k = 'd' + i, s = st[k], sk = SRCK[d.src] || SRCK.talk;
        return `<div class="spkd ${sk[1]}${d.hot ? ' is-hot' : ''}${s ? ' is-set is-' + s : ''}" data-sk="${k}">
          <div class="spkd__h">
            <i class="spkd__no">${String(i + 1).padStart(2, '0')}</i>
            <span class="spkd__src">${sk[0]}</span>
            ${d.vault ? '<span class="spkd__v">会写进仓库</span>' : ''}
            ${d.hot ? '<span class="spkd__hot">我建议先打这条</span>' : ''}
            ${(PICK[k] && !edited(k)) ? `<span class="spkd__pk">你 ${PICKAT} 点的</span>` : ''}
            ${edited(k) ? '<span class="spkd__pk spkd__pk--e">你在这一页改过</span>' : ''}
          </div>
          <b class="spkd__t">${d.t}</b>
          <p class="spkd__f"><span>我从哪看到的</span>${d.from}</p>
          <p class="spkd__o"><span>你手上什么能接</span>${d.hold}</p>
          <p class="spkd__s"><span>第一步做什么</span>${d.step}</p>
          <p class="spkd__b"><span>我有几分把握</span>${d.bet}</p>
          ${s === 'y' && d.plan ? `<div class="spkp">
            <div class="spkp__h"><span>你点了要打 · 我的打法</span><b>${d.plan.w}</b></div>
            <p class="spkp__o"><span>第一步</span>${d.plan.one}</p>
            <p class="spkp__g"><span>我先给你什么</span>${d.plan.give}</p>
            <p class="spkp__f"><span>什么情况算这条打输了</span>${d.plan.fail}</p>
          </div>` : ''}
          <div class="spkd__act">
            <button class="spkd__a${s === 'y' ? ' is-on' : ''}" data-sa="y" data-sk="${k}">这条要打</button>
            <button class="spkd__a${s === 'n' ? ' is-on' : ''}" data-sa="n" data-sk="${k}">这条不打</button>
            ${s ? `<span class="spkd__st">${s === 'y' ? '我这周就动' : '我不再提第二遍'}</span>` : ''}
          </div>
        </div>`;
      }).join('')}</div>

      <div class="spk__sec spk__sec--acc" id="spkacc">
        <div class="spk__h"><span class="spk__n spk__n--acc">你这样验收我 · 你扔素材，我回"能接进你框架的方向"</span>
          <em>你 09-16 说的：<b>「我上一次补入了一份灵感来源的信息，后面可以这么对你验收动作」</b>。
          我把它当成一个<b>可以反复调用的动作</b>写死了（不是一次性任务）：你丢一份别人分享的东西过来，我不给你读书笔记，
          <b>给你几个能接到你现有框架上的方向</b>。下面是我每次必须交齐的五段 —— 缺一段就算我没做完，你可以直接打回。</em></div>

        <div class="spk__accl">${ACC.map((a, i) => `<div class="spka">
          <div class="spka__h"><i>${String(i + 1).padStart(2, '0')}</i><b>${a[0]}</b></div>
          <p class="spka__d">${a[1]}</p>
        </div>`).join('')}</div>

        <div class="spk__accb">${ACCB.map(b => `<div class="spkab">
          <b class="spkab__k">${b[0]}</b><p class="spkab__v">${b[1]}</p>
        </div>`).join('')}</div>

        <div class="spk__feed">
          <label class="spkfd__l">把素材扔进来（链接、群里看到的一句话、截图说明都行）</label>
          <textarea class="spkfd__t" rows="▇▇" placeholder="例：这份文档里大家分享的 skill，看看有没有能在我框架上延展结合的 —— 贴链接 + 一句你想让我留意什么"></textarea>
          <div class="spkfd__act">
            <button class="spkfd__go" type="button">交给我，当天回你几个方向</button>
            <span class="spkfd__n">进收件箱、占 ▇▇ 格；我回的时候按上面那五段回。<b>没有能接的我会直接说没有。</b></span>
          </div>
        </div>

        <div class="spk__fl">
          <span class="spk__flk">你投喂过 ${FEEDLOG.length} 次 · 我回了什么（这一栏本地仓库也存了一份台账）</span>
          ${FEEDLOG.map(f => `<div class="spkfl">
            <div class="spkfl__h"><em>${f.d}</em><b>${f.link ? `<a href="${f.link}" target="_blank" rel="noopener">${f.src}</a>` : f.src}</b></div>
            <p class="spkfl__o"><span>我回了</span>${f.out}</p>
            <p class="spkfl__s"><span>当前进度</span>${f.st}</p>
          </div>`).join('')}
        </div>
      </div>

      <div class="spk__sec spk__sec--b">
        <div class="spk__h"><span class="spk__n spk__n--b">外部 Skill 借力 · ${BORROW.length} 个可以接进你框架的方向</span>
          <em>你给了这份 <a href="${BSRC}" target="_blank" rel="noopener">多部门 Skill 作品清单</a>，让我判断哪些适配当前业务。
          下面每条都按五段写清：<b>借的是什么</b>、<b>接到你哪一块</b>、<b>第一步</b>、<b>会不会重复造轮子</b>、<b>我做不到的部分</b>。</em></div>
        <div class="spk__bl">${BORROW.map((b, i) => `<div class="spkb">
          <div class="spkb__h"><i>${String(i + 1).padStart(2, '0')}</i><b>${b.t}</b></div>
          <p class="spkb__f"><span>借的是什么</span>${b.from}</p>
          <p class="spkb__g"><span>接到你哪一块</span>${b.graft}</p>
          <p class="spkb__s"><span>第一步</span>${b.first}</p>
          <p class="spkb__d"><span>会不会重复造轮子</span>${b.dup}</p>
          <p class="spkb__l"><span>我做不到的部分</span>${b.lack}</p>
        </div>`).join('')}</div>
        <div class="spk__bw">
          <span>⚠️ 本轮明确不接的 ▇▇ 类能力</span>
          <ul>${BWARN.map(w => `<li><b>${w[0]}</b>${w[1]}</li>`).join('')}</ul>
        </div>
      </div>

      <div class="spk__sec">
        <div class="spk__h"><span class="spk__n">我下周去哪儿找新的</span>
          <em>源写死，不然这一页下周就没货。每条都写清"从这儿能捞到什么"和"这一路的东西算不算证据"</em></div>
        <div class="spk__wl">${WHERE.map(w => `<div class="spkw">
          <div class="spkw__h"><b>${w[0]}</b></div>
          <p class="spkw__d">${w[1]}</p>
          <p class="spkw__r"><span>我怎么用它</span>${w[2]}</p>
        </div>`).join('')}</div>
      </div>

      <p class="spk__ft">下面那个输入框是<b>你自己扔灵感</b>用的，两条腿不冲突：我主动找的进这一块，你随手扔的我按标签落进 Obsidian 对应目录。
      <b>最容易有货的两个时刻：拜访路上、提案被否之后。</b></p>
    </div>`;
  }

  function wire() {
    document.addEventListener('click', e => {
      const b = e.target.closest('.spkd__a');
      if (!b) return;
      const st = sLoad(), k = b.dataset.sk, cur = eff()[k];
      st[k] = (cur === b.dataset.sa) ? '' : b.dataset.sa;   /* 再点一次 = 撤回未定，含默认亮着的那 ▇▇条 */
      sSave(st); sync(1); repaint();
      return;
    });
    /* 她投喂素材 → 进收件箱（每次一条独立 topic，不互相覆盖） */
    document.addEventListener('click', e => {
      if (!e.target.closest('.spkfd__go')) return;
      const box = e.target.closest('.spk__feed');
      const tx = box && box.querySelector('.spkfd__t');
      const v = tx ? tx.value.trim() : '';
      if (!v) { if (window.FB && FB.toast) FB.toast('先把链接或那句话贴进来 —— 空的我没法看'); return; }
      if (!(window.FB && FB.submit)) return;
      const it = FB.submit({
        kind: 'idea', view: '灵感库',
        topic: 'spark-feed-' + Date.now(),
        topicName: '你扔给我的素材（等我回可嫁接方向）',
        text: v + '\n\n（我按五段回：借的是什么 / 接到你哪一块 / 第一步 / 会不会重复造轮子 / 我做不到的那部分。没有能接的我直说没有。）'
      });
      if (it) { tx.value = ''; if (FB.toast) FB.toast('收到 —— 当天回你几个方向，接不到你框架的我不端上来'); if (FB.open) FB.open(); }
    });

    document.addEventListener('click', e => {
      if (!e.target.closest('.spk__rst')) return;
      try { localStorage.removeItem(SKEY); } catch (err) {}
      repaint();
      if (window.FB && FB.toast) FB.toast('已回到你 ' + PICKAT + ' 点的那 ' + Object.keys(PICK).length + ' 条（你在这一页改的都撤了）');
    });
  }

  return { render, renderModels, wire, DIR, WHERE, BORROW, MODELS };
})();

(function () {
  const go = () => { try { SPK.wire(); } catch (e) { console.warn('spk', e); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go);
  else go();
})();
