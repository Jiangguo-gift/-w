#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
export_rules.py —— 把本地 Obsidian 仓库里的「判断规则库」和「口径词典」导成一份页面能直接读的数据文件。

她 2026-09-16 21:23 对这件活的落法：就这么做。
原来的毛病：页面上写的"▇▇条规则 / ▇▇条口径"是一条条手抄进 JS 的，仓库改了页面不会动。
现在的链路：本地 Obsidian（权威）→ 本脚本导出 → data/rules.json → rul.js 直接读。

⛔ 三条纪律：
  ▇▇. 只读不写本地仓库（这两个文件是她的资产，导出器一个字都不许改）；
  ▇▇. 计数一律从解析结果来，不许在任何地方手写数字；
  ▇▇. 导出文件里必须带「源文件 / 源文件最近更新 / 导出时间 / 行数」，页面上要能看到这是几号的仓库。

用法：
  python3 tools/export_rules.py --vault "<obsidian 根目录>" --out data/rules.json
"""
import argparse, json, os, re, datetime

RULE_H = re.compile(r'^(#{2,4})\s+(R-\d+)\s*(.*)$')
SEC_H = re.compile(r'^##\s+(?!R-)(.+)$')
TERM_H = re.compile(r'^##\s+(?!R-)(.+)$')
FIELD = re.compile(r'^\s*[-*]\s*\*\*(.+?)\*\*\s*[：:]\s*(.*)$')
META_UPD = re.compile(r'^最近更新[：:]\s*(.+)$')
META_CUT = re.compile(r'^数据截止[：:]\s*(.+)$')


def clean(s: str) -> str:
    """去掉 markdown 强调与内链符号，留人话；不改语义。"""
    s = re.sub(r'\*\*(.+?)\*\*', r'\1', s)
    s = re.sub(r'`(.+?)`', r'\1', s)
    s = re.sub(r'\[\[(.+?)\]\]', r'\1', s)
    s = re.sub(r'\[(.+?)\]\((.+?)\)', r'\1', s)
    return s.strip()


def split_conf(v: str):
    """有些条目把「置信度」用 | 挂在同一行末尾，拆出来，别让它混在动作里。"""
    m = re.search(r'[|｜]\s*置信度\s*[：:]\s*(.+)$', v)
    if not m:
        return v, ''
    return v[:m.start()].strip(' |｜'), m.group(1).strip()


def summarize(body, k=2):
    """结构化字段抓不到时的回退：取正文前几句人话（跳过表格行与纯符号行）。
       ⛔ 不许编：抓不到就留空，页面上照实显示「这条正文没有结构化字段」。"""
    keep = []
    for b in body:
        if not b or b.startswith('|') or b.startswith('---') or set(b) <= set('-—= '):
            continue
        keep.append(re.sub(r'^[-*>]\s*', '', b))
        if len(keep) >= k:
            break
    return ' '.join(keep)[:220]


def read(path: str):
    with open(path, encoding='utf-8') as f:
        return f.read().split('\n')


def head_meta(lines):
    upd = cut = ''
    for ln in lines[:12]:
        m = META_UPD.match(ln)
        if m and not upd:
            upd = clean(m.group(1))
        m = META_CUT.match(ln)
        if m and not cut:
            cut = clean(m.group(1))
    return upd, cut


def parse_rules(path):
    lines = read(path)
    upd, cut = head_meta(lines)
    sec = ''
    out, cur = [], None

    def flush():
        if cur:
            out.append(cur)

    for ln in lines:
        mr = RULE_H.match(ln)
        if mr:
            flush()
            cur = {'id': mr.group(2), 'title': clean(mr.group(3)) or '(标题在正文里)',
                   'sec': sec, 'f': {}, 'body': []}
            continue
        ms = SEC_H.match(ln)
        if ms and not ln.startswith('## R-'):
            sec = clean(ms.group(1))
            continue
        if cur is None:
            continue
        mf = FIELD.match(ln)
        if mf:
            k, v = clean(mf.group(1)), clean(mf.group(2))
            if k and v:
                cur['f'].setdefault(k, v)
        elif ln.strip():
            cur['body'].append(clean(ln))
    flush()

    def pick(f, *keys):
        for k in keys:
            for fk in f:
                if fk.startswith(k):
                    return f[fk]
        return ''

    rules = []
    for r in out:
        f = r['f']
        cond = pick(f, '条件', '触发')
        act = pick(f, '动作', '结论', '正确规则', '规则')
        why = pick(f, '理由', '为什么', '业务含义')
        conf = pick(f, '置信度')
        act, c1 = split_conf(act)
        cond, c2 = split_conf(cond)
        why, c3 = split_conf(why)
        conf = conf or c1 or c2 or c3
        item = {
            'id': r['id'],
            'sec': r['sec'],
            'title': r['title'],
            'cond': cond,
            'act': act,
            'why': why,
            'conf': conf,
            'fail': pick(f, '失效条件'),
            'n': len(r['body'])
        }
        if not cond and not act:
            item['sum'] = summarize(r['body'])      # 回退摘要，标明是正文摘的
        rules.append(item)
    return {
        'src': os.path.basename(path),
        'srcUpdated': upd, 'dataCut': cut,
        'lines': len(lines), 'count': len(rules), 'rules': rules
    }


def parse_terms(path):
    lines = read(path)
    upd, cut = head_meta(lines)
    out, cur = [], None

    def flush():
        if cur:
            out.append(cur)

    for ln in lines:
        mt = TERM_H.match(ln)
        if mt:
            flush()
            t = clean(mt.group(1))
            cur = {'term': t, 'f': {}, 'body': [], 'tbl': 0, 'red': '⛔' in ln or '红线' in t}
            continue
        if cur is None:
            continue
        mf = FIELD.match(ln)
        if mf:
            k, v = clean(mf.group(1)), clean(mf.group(2))
            if k and v:
                cur['f'].setdefault(k, v)
        elif ln.strip():
            if ln.lstrip().startswith('|'):
                cur['tbl'] += 1
            cur['body'].append(clean(ln))
    flush()

    def pick(f, *keys):
        for k in keys:
            for fk in f:
                if fk.startswith(k):
                    return f[fk]
        return ''

    terms = []
    for t in out:
        f = t['f']
        warn = [b for b in t['body'] if b.startswith('⚠️') or b.startswith('⛔')]
        d = pick(f, '定义')
        item = {
            'term': t['term'],
            'def': d,
            'use': pick(f, '默认口径', '用在哪', '业务含义'),
            'mix': pick(f, '常见混淆', '与'),
            'warn': warn[0] if warn else '',
            'red': bool(t['red'] or (warn and warn[0].startswith('⛔'))),
            'n': len(t['body'])
        }
        if not d:
            item['sum'] = summarize(t['body'], 2)   # 这一条在仓库里不是「定义：」的写法，摘正文
            if not item['sum'] and f:
                # 这一条用的是别的字段名（取值规则 / 指标组 …）：把前两个字段原样拼成摘要
                item['sum'] = ' ｜ '.join('%s：%s' % kv for kv in list(f.items())[:2])[:220]
            if not item['sum'] and t['tbl']:
                item['tblOnly'] = t['tbl']          # 正文只有一张对照表：页面照实说，不复制表格也不编摘要
        terms.append(item)
    return {
        'src': os.path.basename(path),
        'srcUpdated': upd, 'dataCut': cut,
        'lines': len(lines), 'count': len(terms), 'terms': terms
    }


def vault_stats(vault: str):
    """顺手把仓库体量也实测一遍 —— 页面上「多少篇笔记 / 多少行 / 几个目录」一律用这里的数，
    不许再手抄（E-11 就是手抄数字栽的）。只读，不写。"""
    notes, lines, dirs, empty = 0, 0, 0, 0
    for root, ds, fs in os.walk(vault):
        ds[:] = [d for d in ds if not d.startswith('.')]
        rel = os.path.relpath(root, vault)
        mds = [f for f in fs if f.endswith('.md')]
        if rel != '.':
            dirs += 1
            if not mds:
                empty += 1
        for f in mds:
            notes += 1
            try:
                with open(os.path.join(root, f), encoding='utf-8', errors='ignore') as fh:
                    lines += sum(1 for _ in fh)
            except OSError:
                pass
    log = os.path.join(vault, '_系统', '学习日志.md')
    logs = 0
    if os.path.exists(log):
        with open(log, encoding='utf-8', errors='ignore') as fh:
            logs = sum(1 for ln in fh if ln.startswith('## '))
    mem = os.path.join(vault, 'MEMORY.md')
    memLines = 0
    if os.path.exists(mem):
        with open(mem, encoding='utf-8', errors='ignore') as fh:
            memLines = sum(1 for _ in fh)
    return {'notes': notes, 'lines': lines, 'dirs': dirs, 'emptyDirs': empty,
            'learnLogs': logs, 'memoryLines': memLines,
            'measuredAt': datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}


def mem_stats(vault: str):
    """记忆层与纠错台账的实测计数 —— 页面上「待复核多少条 / 我犯过多少错 / 偏好多少条」
    一律走这里，不许手抄（R-570）。只读，不写。"""
    def ids(path, pat):
        if not os.path.exists(path):
            return set(), ''
        with open(path, encoding='utf-8', errors='ignore') as fh:
            txt = fh.read()
        upd = ''
        m = re.search(r'最近更新[:：]\s*([0-9\-/\.]+)', txt)
        if m:
            upd = m.group(1)
        if not upd:
            upd = datetime.datetime.fromtimestamp(os.path.getmtime(path)).strftime('%Y-%m-%d')
        return set(re.findall(pat, txt)), upd

    md = os.path.join(vault, '_记忆')
    sysd = os.path.join(vault, '_系统')
    prefs, prefUpd = ids(os.path.join(md, '01-个人偏好.md'), r'U-(\d+)')
    decs, decUpd = ids(os.path.join(md, '02-决策习惯.md'), r'D-(\d+)')
    projs, projUpd = ids(os.path.join(md, '03-项目细节.md'), r'J-(\d+)')
    errs, errUpd = ids(os.path.join(md, '04-常错清单.md'), r'E-(\d+)')

    qp = os.path.join(sysd, '待复核队列.md')
    q_all, qUpd = ids(qp, r'Q-(\d+)')
    q_done = set()
    if os.path.exists(qp):
        with open(qp, encoding='utf-8', errors='ignore') as fh:
            for ln in fh:
                if ('✅' in ln or '已裁决' in ln or '已确认' in ln) or ln.startswith('| Q-'):
                    q_done |= set(re.findall(r'Q-(\d+)', ln))
    return {
        'prefs': len(prefs), 'prefUpdated': prefUpd,
        'decisions': len(decs), 'decUpdated': decUpd,
        'projects': len(projs), 'projUpdated': projUpd,
        'errors': len(errs), 'errUpdated': errUpd,
        'qTotal': len(q_all), 'qDone': len(q_done),
        'qOpen': max(len(q_all) - len(q_done), 0), 'qUpdated': qUpd,
        'measuredAt': datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--vault', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    sysdir = os.path.join(a.vault, '_系统')
    rp = os.path.join(sysdir, '判断规则库.md')
    tp = os.path.join(sysdir, '口径词典.md')
    for p in (rp, tp):
        if not os.path.exists(p):
            raise SystemExit('源文件不在：' + p)

    R, T = parse_rules(rp), parse_terms(tp)
    doc = {
        'meta': {
            'exportedAt': datetime.datetime.now().strftime('%Y-%m-%d %H:%M'),
            'vault': '本地 Obsidian（权威源）',
            'how': '仓库 → tools/export_rules.py → data/rules.json → 页面直接读；页面上的条数不再是手抄的',
            'ruleCount': R['count'], 'termCount': T['count'],
            'ruleSrc': R['src'], 'ruleUpdated': R['srcUpdated'], 'ruleLines': R['lines'],
            'termSrc': T['src'], 'termUpdated': T['srcUpdated'], 'termCut': T['dataCut'], 'termLines': T['lines'],
            'sections': sorted({r['sec'] for r in R['rules'] if r['sec']})
        },
        'vault': vault_stats(a.vault),
        'mem': mem_stats(a.vault),
        'rules': R['rules'],
        'terms': T['terms']
    }
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump(doc, f, ensure_ascii=False, indent=1)
    # 页面用的那一份：写成 JS 赋值，file:// 直接打开也能读（fetch 在本地文件协议下会被浏览器拦）
    js = os.path.splitext(a.out)[0] + '.data.js'
    with open(js, 'w', encoding='utf-8') as f:
        f.write('/* 自动生成，不要手改 —— 改本地 Obsidian 里的源文件，然后重跑 tools/export_rules.py */\n')
        f.write('window.RULDATA = ')
        json.dump(doc, f, ensure_ascii=False, separators=(',', ':'))
        f.write(';\n')
    print('页面数据层 → ' + js)
    print('规则 %d 条 / 口径 %d 条 → %s' % (R['count'], T['count'], a.out))
    v = doc['vault']
    print('仓库实测：%d 篇笔记 / %d 行 / %d 个目录（%d 个空）/ 学习日志 %d 篇 / MEMORY.md %d 行'
          % (v['notes'], v['lines'], v['dirs'], v['emptyDirs'], v['learnLogs'], v['memoryLines']))
    print('规则源最近更新：%s ｜ 口径源最近更新：%s（数据截止 %s）'
          % (R['srcUpdated'], T['srcUpdated'], T['dataCut']))
    m = doc['mem']
    print('记忆层实测：偏好 %d · 决策 %d · 项目卡 %d · 常错 %d ｜ 待复核 %d 条（已裁 %d / 挂起 %d）'
          % (m['prefs'], m['decisions'], m['projects'], m['errors'], m['qTotal'], m['qDone'], m['qOpen']))


if __name__ == '__main__':
    main()
