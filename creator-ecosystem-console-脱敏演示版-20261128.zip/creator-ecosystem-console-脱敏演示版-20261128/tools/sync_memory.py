#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sync_memory.py —— 把本地 Obsidian 的常驻记忆同步成云端镜像（Mac 断连时的兜底）。

为什么要有这个脚本：镜像原来是我手工复制 + 手写 index.json 的，版本号、条数、最新编号
每次都得手改，改漏一处，Mac 一断连就会读到过期记忆（E-09 / E-11 的老账）。

链路：本地 Obsidian（权威）→ 本脚本 → memory/*.md + memory/ALL.md + memory/index.json

⛔ 三条纪律：
  ▇▇. 只读本地仓库，一个字都不改（那是她的资产）；
  ▇▇. 版本号、行数、各册条数、最新编号一律从文件里算出来，不许手写；
  3. index.json 里手写的判断类内容（证据链标准 / 机制标准 / 连接方式等）保留不动，
     只覆盖能算出来的字段。

用法：
  python3 tools/sync_memory.py --vault "<obsidian 根目录>" [--out memory]
"""
import argparse, json, os, re, shutil, datetime

ALIAS = {
    '00-运行规则.md': '00-rules.md',
    '01-个人偏好.md': '01-preferences.md',
    '02-决策习惯.md': '02-decisions.md',
    '03-项目细节.md': '03-projects.md',
    '04-常错清单.md': '04-mistakes.md',
    '05-记忆变更日志.md': '05-changelog.md',
}
PREFIX = {'01-个人偏好.md': 'U', '02-决策习惯.md': 'D', '03-项目细节.md': 'J', '04-常错清单.md': 'E'}


def read(p):
    with open(p, encoding='utf-8') as f:
        return f.read()


def ids(text, pre):
    """某一册里出现过的编号，按数字排序返回。"""
    got = sorted({int(m) for m in re.findall(r'^#{2,4}\s+[^\n]*?' + pre + r'-(\d+)', text, re.M)})
    return got


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--vault', required=True)
    ap.add_argument('--out', default='memory')
    a = ap.parse_args()

    mem = os.path.join(a.vault, 'MEMORY.md')
    sub = os.path.join(a.vault, '_记忆')
    extra = os.path.join(a.vault, '_系统', '灵感来源台账.md')
    if not os.path.exists(mem):
        raise SystemExit('MEMORY.md 不在：' + mem)
    os.makedirs(a.out, exist_ok=True)

    memtxt = read(mem)
    memlines = len(memtxt.splitlines())
    ver = (re.search(r'版本：\s*(v[\d.]+)', memtxt) or [None, '?'])[1]

    # ▇▇) 逐册拷贝（中文原名 + 英文别名，两份都留，历史链接不断）
    parts, stat = [], {}
    for fn in sorted(os.listdir(sub)):
        if not fn.endswith('.md'):
            continue
        txt = read(os.path.join(sub, fn))
        stat[fn] = {'lines': len(txt.splitlines()), 'ids': ids(txt, PREFIX[fn]) if fn in PREFIX else []}
        for name in (fn, ALIAS.get(fn)):
            if name:
                with open(os.path.join(a.out, name), 'w', encoding='utf-8') as f:
                    f.write(txt)
        parts.append((fn, txt))
    shutil.copyfile(mem, os.path.join(a.out, 'MEMORY.md'))
    if os.path.exists(extra):
        shutil.copyfile(extra, os.path.join(a.out, '灵感来源台账.md'))

    # 2) ALL.md：一次读全版
    stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    all_md = ['# ALL.md —— 本人跨会话记忆库（云端镜像 · 一次读全版）', '',
              '> 权威源是本地 Obsidian（`/Users/demo/Desktop/工作使用文档/obsidian文件夹`）。这份是 Mac 断连时的兜底镜像。',
              '> 由 tools/sync_memory.py 生成于 %s ｜ 常驻记忆 %s（%d 行）。' % (stamp, ver, memlines),
              '', '---', '', '# 【常驻记忆】MEMORY.md', '', memtxt]
    for fn, txt in parts:
        all_md += ['', '---', '', '# 【分库】' + fn, '', txt]
    with open(os.path.join(a.out, 'ALL.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(all_md))

    # 3) index.json：只覆盖能算出来的字段，手写判断保留
    ip = os.path.join(a.out, 'index.json')
    doc = json.loads(read(ip)) if os.path.exists(ip) else {}
    rulep = os.path.join(a.vault, '_系统', '判断规则库.md')
    termp = os.path.join(a.vault, '_系统', '口径词典.md')
    rc = len(set(re.findall(r'^#{2,4}\s+(R-\d+)', read(rulep), re.M))) if os.path.exists(rulep) else 0
    tc = len([1 for ln in read(termp).splitlines() if re.match(r'^##\s+(?!R-)', ln)]) if os.path.exists(termp) else 0

    def last(fn, pre):
        g = stat.get(fn, {}).get('ids') or []
        return '%s-%02d' % (pre, g[-1]) if g else '—'

    doc['version'] = ver
    doc['generated'] = '%s · 由 tools/sync_memory.py 从本地仓库同步（常驻记忆 %s / %d 行）' % (stamp, ver, memlines)
    doc['files'] = {
        'MEMORY.md': '常驻记忆启动包，硬上限 ▇▇行（现 %d 行 · %s）' % (memlines, ver),
        '00-rules.md': '记忆层运行规则：分类标准 / 写入规则 / 每日整理 / 每周二复盘',
        '01-preferences.md': '个人偏好 U-01~%s，共 %d 条' % (last('01-个人偏好.md', 'U'), len(stat.get('01-个人偏好.md', {}).get('ids', []))),
        '02-decisions.md': '决策习惯 D-01~%s，共 %d 条' % (last('02-决策习惯.md', 'D'), len(stat.get('02-决策习惯.md', {}).get('ids', []))),
        '03-projects.md': '项目细节 J-01~%s，共 %d 张项目卡' % (last('03-项目细节.md', 'J'), len(stat.get('03-项目细节.md', {}).get('ids', []))),
        '04-mistakes.md': '我犯过的错 E-01~%s（%d 条）+ 动手前自检卡' % (last('04-常错清单.md', 'E'), len(stat.get('04-常错清单.md', {}).get('ids', []))),
        '05-changelog.md': '记忆层变更日志，追加式 %d 段' % len(re.findall(r'^##\s+\d{4}-\d{2}-\d{2}', read(os.path.join(sub, '05-记忆变更日志.md')), re.M)),
        'ALL.md': '以上全部拼在一起，一次 fetch 版',
        '灵感来源台账.md': '她投喂过的外部素材 + 我提炼的可嫁接方向 + 落地状态（权威源 _系统/灵感来源台账.md）',
    }
    doc['load_order'] = [
        '1. 先读 MEMORY.md（%d 行，▇▇ 屏）——她是谁 / 协作铁律 / 决策习惯 / 项目状态 / 等她定的 / 红线' % memlines,
        '2. 按 MEMORY.md 第 ▇▇ 节的指针，只下钻这次任务需要的那一册',
        '▇▇. 动手改代码或下任何"策略/结论"前，必读 04-mistakes.md 的自检卡（最新 %s）' % last('04-常错清单.md', 'E'),
        '▇▇. 要用业务判断规则或口径：读工作台 data/rules.json（%d 条规则 / %d 条口径，从仓库导出），不要手抄数字' % (rc, tc),
        '▇▇. 需要一次拿全部：读 ALL.md',
    ]
    sc = doc.setdefault('scope', {})
    sc['shelves'] = [
        '她这个人：偏好 %d 条 / 决策习惯 %d 条' % (len(stat.get('01-个人偏好.md', {}).get('ids', [])), len(stat.get('02-决策习惯.md', {}).get('ids', []))),
        '我的教训：常错 %d 条 + 自检卡' % len(stat.get('04-常错清单.md', {}).get('ids', [])),
        '在跑的事：项目卡 %d 张 + 每日/每周节奏' % len(stat.get('03-项目细节.md', {}).get('ids', [])),
        '业务判断：判断规则 %d 条 + 口径 %d 条（已导出成 data/rules.json，页面直接读）+ 策略四层证据标准 L1~L4 与两条否决线' % (rc, tc),
        '数据与资料：▇▇个业务底仓 + 数据源权威表 + 工作台自身运行状态 + ▇▇个 Skill 手册摘要（只存判断与出处，不存明细金额与人名清单）',
    ]
    with open(ip, 'w', encoding='utf-8') as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
        f.write('\n')

    # ▇▇) 页面数据层：记忆库那一页的条数从此也不手抄（配合 cat.js）
    def cnt(fn):
        return len(stat.get(fn, {}).get('ids', []))
    log = read(os.path.join(sub, '05-记忆变更日志.md'))
    days = re.findall(r'^##\s+(\d{4}-\d{2}-\d{2})', log, re.M)
    md = {
        'stamp': stamp, 'ver': ver, 'mem': memlines, 'memMax': 140,
        'rules': stat.get('00-运行规则.md', {}).get('lines', 0),
        'pref': cnt('01-个人偏好.md'), 'dec': cnt('02-决策习惯.md'),
        'proj': cnt('03-项目细节.md'), 'mis': cnt('04-常错清单.md'),
        'logSegs': len(days),
        'logFrom': (days[-1][5:] if days else ''), 'logTo': (days[0][5:] if days else ''),
        'all': len('\n'.join(all_md).splitlines()),
        'ruleN': rc, 'termN': tc,
        'ruleLines': len(read(rulep).splitlines()) if os.path.exists(rulep) else 0,
        'termLines': len(read(termp).splitlines()) if os.path.exists(termp) else 0,
        'notes': 0, 'vaultLines': 0,
    }
    # 仓库体量：跟 export_rules.py 一个算法，避免两处口径不一致
    for root, ds, fs in os.walk(a.vault):
        ds[:] = [d for d in ds if not d.startswith('.')]
        for fn in fs:
            if fn.endswith('.md'):
                md['notes'] += 1
                md['vaultLines'] += len(read(os.path.join(root, fn)).splitlines())
    q = os.path.join(a.vault, '_系统', '待复核队列.md')
    md['queueN'] = len(set(re.findall(r'^#{2,4}\s*[^\n]*?(Q-\d+|待核-\d+)', read(q), re.M))) if os.path.exists(q) else 0
    with open(os.path.join(a.out, 'mem.data.js'), 'w', encoding='utf-8') as f:
        f.write('/* 自动生成，不要手改 —— 改本地 Obsidian，然后重跑 tools/sync_memory.py */\n')
        f.write('window.MEMDATA = ')
        json.dump(md, f, ensure_ascii=False, separators=(',', ':'))
        f.write(';\n')

    print('镜像已同步 → %s' % a.out)
    print('常驻记忆 %s / %d 行 ｜ 偏好 %d · 决策 %d · 项目 %d · 常错 %d ｜ 规则 %d / 口径 %d'
          % (ver, memlines, len(stat.get('01-个人偏好.md', {}).get('ids', [])),
             len(stat.get('02-决策习惯.md', {}).get('ids', [])),
             len(stat.get('03-项目细节.md', {}).get('ids', [])),
             len(stat.get('04-常错清单.md', {}).get('ids', [])), rc, tc))


if __name__ == '__main__':
    main()
