/* ═══════════════════════════════════════════════════════════
   交互层 · v4
   —— 把这一页从「能看能改」变成「能推演、能决策、能积攒」
   —— 六件东西：能力迭代时间线 / 主动建议采纳流 / 灵感捕捉 /
      归因推演器 / 模版生成器 / 行动队列
   —— 铁律：所有交互产物都只存 localStorage，最终只能通过
      「补丁」流回仓库。这一页永远不直接写你的磁盘。
   ═══════════════════════════════════════════════════════════ */
window.TOOLS = (function () {

  const KT = {
    adv:   'cec.t.advice',
    queue: 'cec.t.queue',
    idea:  'cec.t.ideas',
    attr:  'cec.t.attrib',
    tpl:   'cec.t.tplvars'
  };
  const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } };
  const save = (k, v) => localStorage.setItem(k, JSON.stringify(v));

  let ADV   = load(KT.adv, {});     // S-01 → { st:'take'|'tweak'|'deny', note }
  let QUEUE = load(KT.queue, []);   // [{ id, t, from, done }]
  let IDEAS = load(KT.idea, []);    // [{ id, t, tag, at }]
  let ATTR  = load(KT.attr, {});    // { cust, shape, signal:[], cause, move, note }
  let TVARS = load(KT.tpl, {});     // 'T-01.org' → value

  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const plain = s => String(s).replace(/<[^>]+>/g, '');

  /* ═══════════ OV · 三个新块 ═══════════ */
  function ovBlocks(d) {
    return blkEvo(d) + blkAdvice(d) + blkInbox(d);
  }

  /* ── 系统能力迭代 ── */
  function blkEvo() {
    const e = DATA2.evo;
    const body = `<div class="evo">${e.rows.map(r => `<div class="evo__i${r.now ? ' is-now' : ''}${r.hot ? ' is-dead' : ''}">
      <div class="evo__v">${r.v}</div>
      <div class="evo__d">${r.d}</div>
      <div class="evo__t">${r.t}</div>
      <div class="evo__w">${r.w}</div>
      <div class="evo__k">${r.hot ? '⊘ ' : '→ '}${r.k}</div>
    </div>`).join('')}</div>
    <p class="block__note" style="margin-top:18px;margin-bottom:▇▇">${e.next}</p>`;
    return block('m-evo', '系统能力迭代', '这套系统自己的产线', e.note, body);
  }

  /* ── 主动建议 ──
     2026-09-12：三条已被 ▇▇ 节裁决结案。本地没有改判记录时，显示预置结果（preset）；
     你点任意一个按钮就是改判，改判写进 localStorage 并盖掉预置值。 */
  function blkAdvice() {
    const a = DATA2.advice;
    const LBL = { take: '已采纳', deny: '已驳回', pull: '我已撤回', tweak: '待改' };
    const body = `<div class="advs">${a.items.map(x => {
      const local = ADV[x.id];
      const s = local || (x.settled ? { st: x.settled, preset: 1 } : {});
      const pre = !local && x.settled;
      return `<div class="adv" data-adv="${x.id}" data-st="${s.st || ''}"${pre ? ' data-preset="▇▇"' : ''}>
        <div class="adv__h">
          <span class="adv__id">${x.id}</span>
          <span class="tag${x.pri === '高' ? ' tag--signal' : ''}">${x.pri}优先</span>
          <h4>${x.t}</h4>
          <span class="adv__badge"></span>
        </div>
        <div class="adv__g">
          <div class="adv__col">
            <div class="adv__k">为什么现在值得做</div>
            <p>${x.why}</p>
          </div>
          <div class="adv__col">
            <div class="adv__k">执行成本</div><p class="adv__cost">${x.cost}</p>
            <div class="adv__k" style="margin-top:14px">完成后能解决什么</div><p>${x.fix}</p>
          </div>
          <div class="adv__col">
            <div class="adv__k">第一步怎么做</div><p>${x.how}</p>
          </div>
        </div>
        <div class="adv__f">
          <button class="btn advb advb--take" data-act="take">采纳，加入行动队列</button>
          <button class="btn advb advb--tweak" data-act="tweak">修改后再决定</button>
          <button class="btn advb advb--deny" data-act="deny">暂不执行</button>
          <span class="adv__hint"></span>
        </div>
        <div class="adv__note"><textarea rows="▇▇" placeholder="${'请写一句：为什么暂不执行，或希望改成什么。系统会记住这句话，避免下次重复提出同类建议'}">${esc(s.note || '')}</textarea></div>
      </div>`;
    }).join('')}</div>`;
    return block('m-advice', '本批建议', '▇▇条建议 · 逐条决策', a.note, body);
  }

  /* ── 灵感捕捉 ── */
  function blkInbox() {
    const b = DATA2.inbox;
    const body = `<div class="inbox">
      <div class="inbox__in">
        <input id="ideaIn" placeholder="随手记一句：看到什么现象 / 想到什么玩法 / 谁可能有需求…" autocomplete="off">
        <div class="inbox__tags">${b.tags.map((t, i) => `<button class="chip chip--tag${i === 0 ? ' is-on' : ''}" data-tag="${t.k}" title="落点：${t.land}">${t.n}</button>`).join('')}</div>
        <button class="btn btn--solid" id="ideaAdd">记下</button>
      </div>
      <div class="inbox__hint">${b.hint}　·　当前标签落点：<span class="pth" id="ideaLand">${b.tags[0].land}</span></div>
      <div class="inbox__list" id="ideaList"></div>
    </div>`;
    return block('m-inbox', '灵感捕捉', '入料口 · 落 Obsidian 前的暂存', b.note, body);
  }

  /* ═══════════ ▇▇ · 只剩外部生态一块 ═══════════
     2026-09-12 归口：aicap（业务动作 × AI 能力）讲的是业务盘，已移去 ▇▇。
     ▇▇ 不得再出现任何「我的机构 / 客户 / 名单 / 业绩」内容。 */
  function ecoBlocks() {
    return blkInsight();
  }

  function blkInsight() {
    const s = DATA2.insight;
    const body = cells(s.now.map(x => ({ k: x.k, v: x.v, u: x.u, d: x.d, st: x.st })), 'grid--▇▇')
      + `<div style="height:16px"></div>`
      + table([{ t: '该有什么', w: '150px' }, { t: '现在', w: '58px' }, { t: '落点', w: '190px' }, { t: '为什么它重要' }],
        s.rows.map(r => `<tr ${gapAttr(r.st)}>
          <td class="nm">${dot(r.st)}${r.n}</td><td class="dim">${r.have}</td>
          <td class="pth" style="white-space:normal">${r.land}</td><td>${r.d}</td></tr>`))
      + `<div class="tcard">
          <div class="tcard__h"><b>${s.tpl.t}</b><button class="btn btn--solid" id="tcardCopy">复制模板</button></div>
          <pre class="tcard__pre" id="tcardPre">${esc(s.tpl.body)}</pre>
          <div class="tcard__f">三行写完就行。<b>写第四行的那一刻，你就是在抄资讯而不是在做判断。</b></div>
        </div>`
      + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${s.warn}</p>`;
    return block('m-insight', '市场趋势与商业化洞察', '这一格现在是 ▇▇篇', s.note, body);
  }

  function blkAicap() {
    const a = DATA2.aicap;
    const body = table([{ t: '业务动作', w: '210px' }, { t: '靠什么跑', w: '210px' }, { t: '实况' }],
      a.rows.map(r => `<tr ${gapAttr(r.st)}>
        <td class="nm">${dot(r.st)}${r.n}</td>
        <td class="pth" style="white-space:normal;font-size:11.5px">${r.by}</td>
        <td>${r.d}</td></tr>`))
      + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${a.warn}</p>`;
    return block('m-aicap', '业务动作 × AI 能力对账', '六条业务动作', a.note, body);
  }

  /* ═══════════ ▇▇ · 业务基本盘（业务业绩全部归这里）═══════════ */
  function baseBlocks() {
    return blkAicap() + blkFrames() + blkAttrib() + blkTpl();
  }

  function blkFrames() {
    const f = DATA2.frames;
    const body = table(
      [{ t: '框架', w: '150px' }, { t: '周期', w: '62px' }, { t: '现在有什么' }, { t: '缺口' }, { t: '', w: '96px' }],
      f.rows.map(r => `<tr ${gapAttr(r.st)}>
        <td class="nm">${dot(r.st)}${r.n}</td>
        <td>${tag(r.cyc, r.cyc === '每日' ? 'signal' : '')}</td>
        <td style="font-size:12.5px">${r.have}</td>
        <td style="font-size:12.5px">${r.gap}</td>
        <td class="nowrap">${r.link && LINKS[r.link] ? `<a class="chip" href="${LINKS[r.link]}" target="_blank">打开 ↗</a>` : ''}
          <button class="chip" data-jump="${r.to}">细看 ↘</button></td></tr>`))
      + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${f.insight}</p>`;
    return block('m-frames', '业务框架总表 · 八条', '入口 / 现状 / 缺口', f.note, body);
  }

  function blkAttrib() {
    const a = DATA2.attrib;
    const stepHTML = a.steps.map((s, i) => `<div class="atv__step" data-step="${s.k}">
      <div class="atv__h"><span class="atv__n">${i + 1}</span><b>${s.t.replace(/^第.步 · /, '')}</b><span class="atv__hint">${s.hint}</span></div>
      <div class="atv__opts">${s.opts.map(o => `<button class="opt2${s.multi ? ' opt2--multi' : ''}" data-k="${s.k}" data-v="${esc(o.v)}">
        <b>${o.v}</b><span>${o.d}</span></button>`).join('')}</div>
    </div>`).join('');

    const body = `<div class="atv">
      <div class="atv__top">
        <label>客户 / 对象</label>
        <input id="atvCust" placeholder="填个名字或代号，只存在你本机（例：XX 品牌）" autocomplete="off">
        <button class="btn btn--ghost" id="atvReset">清空重来</button>
      </div>
      ${stepHTML}
      <div class="atv__out" id="atvOut">
        <div class="atv__outh"><b>${a.out.t}</b><span id="atvProg">还差 ▇▇步</span></div>
        <pre class="atv__pre" id="atvPre">五步选完，这里会出一份可以直接发我的归因草稿。</pre>
        <div class="atv__acts">
          <button class="btn btn--solid" id="atvCopy" disabled>复制草稿</button>
          <button class="btn" id="atvQueue" disabled>把动作加进行动队列</button>
        </div>
        <div class="atv__foot">${a.out.hint}</div>
      </div>
    </div>`;
    return block('m-attrib', '客户增减投归因推演器', '六问链 · ▇▇条待验证', a.note, body);
  }

  function blkTpl() {
    const t = DATA2.tpl;
    const body = `<div class="tpls">${t.items.map(x => `<div class="tpl" data-tpl="${x.id}">
      <div class="tpl__h">
        <span class="tpl__id">${x.id}</span>${dot(x.st)}<b>${x.n}</b>
        <span class="tpl__f">${x.freq}</span>
        <button class="chip tpl__x">展开填参数 ＋</button>
      </div>
      <div class="tpl__b">
        <div class="tpl__vars">${x.vars.map(v => `<label class="tpl__v">
          <span>${v.n}</span>
          <input data-tv="${x.id}.${v.k}" placeholder="${esc(v.ph)}" value="${esc(TVARS[x.id + '.' + v.k] || '')}" autocomplete="off">
        </label>`).join('')}</div>
        <pre class="tpl__pre" data-tpre="${x.id}"></pre>
        <div class="tpl__acts">
          <button class="btn btn--solid" data-tcopy="${x.id}">复制这条指令</button>
          <span class="tpl__note">没填的变量保留 <code>{{占位}}</code> 原样不动，我看到会回来问你</span>
        </div>
      </div>
    </div>`).join('')}</div>
    <p class="block__note" style="margin-top:18px;margin-bottom:▇▇">${t.spec}</p>`;
    return block('m-tpl', '可封装的 skill 模版 · 六个', '六段式结构化提示词', t.note, body);
  }

  /* ═══════════ ▇▇ · 知识库资产 ═══════════ */
  function secAssets() {
    const a = DATA2.assets;
    let out = block('m-assets', '四类知识库资产 · 逐个对账', '空的就写空', a.note,
      `<div class="asset">${a.groups.map(g => `<div class="asset__i" data-gap="${g.st === 'gap' ? 1 : 0}">
        <div class="asset__h">${dot(g.st)}<b>${g.n}</b><span class="asset__c">${g.c}<small>${g.n === '底仓数据' ? ' 个源' : ' 条'}</small></span></div>
        <div class="asset__k">现在真有什么</div><p>${g.have}</p>
        <div class="asset__k">缺什么</div><p>${g.need}</p>
        <div class="asset__v">${g.val}</div>
        <div class="asset__l pth">落点：${g.land}</div>
      </div>`).join('')}</div>
      <p class="block__note" style="margin-top:18px">${a.verdict}</p>
      <p class="block__note" style="margin-top:10px;margin-bottom:▇▇">${a.hint}</p>`);
    return out;
  }

  /* ═══════════ ▇▇ · 可做的动作 ═══════════ */
  function actBlock() {
    const a = DATA2.acts;
    return block('m-acts', '这一页你能做的八个动作', '五个会流回仓库', a.note,
      table([{ t: '', w: '64px' }, { t: '动作', w: '130px' }, { t: '怎么用' }, { t: '结果去哪', w: '96px' }],
        a.rows.map(r => `<tr><td><span class="kbd2">${r.k}</span></td>
          <td class="nm">${r.n}</td><td>${r.d}</td>
          <td>${tag(r.out, r.out === '直接提交给我' ? 'run' : (r.out === '直接改仓库' ? 'signal' : ''))}</td></tr>`))
      + `<p class="block__note" style="margin-top:16px;margin-bottom:▇▇">${a.warn}</p>`);
  }

  /* ═══════════════════════════════════════════════════════════
     交互
     ═══════════════════════════════════════════════════════════ */
  function wire() {
    /* ── 依据 / 细看 跳转 ── */
    document.addEventListener('click', e => {
      const j = e.target.closest('[data-jump]');
      if (!j) return;
      const el = document.querySelector(`[data-mod="${j.dataset.jump}"]`);
      if (!el) return;
      window.scrollTo({ top: Math.max(el.offsetTop - 70, 0), behavior: 'smooth' });
      el.classList.remove('is-flash'); void el.offsetWidth; el.classList.add('is-flash');
    });

    /* ── 建议采纳 ── */
    $$('.adv').forEach(card => {
      const id = card.dataset.adv;
      const ta = $('textarea', card);
      $$('[data-act]', card).forEach(b => b.addEventListener('click', () => {
        const act = b.dataset.act;
        const cur = ADV[id] || {};
        if (cur.st === act) { delete ADV[id]; }                 // 再点一次 = 撤销
        else ADV[id] = { st: act, note: ta.value || '' };
        save(KT.adv, ADV);
        syncAdv(card);
        if (ADV[id]?.st === 'take') {
          const item = DATA2.advice.items.find(x => x.id === id);
          addQ(`${item.t}`, id);
          toast(`${id} 已进行动队列 —— 右上角「队列」里能看到`);
        } else if (!ADV[id]) { rmQ(id); toast(`${id} 已撤销`); }
        else { rmQ(id); toast(act === 'deny' ? '写一句为什么，这句比"已驳回"有用' : '写一句要改成什么'); ta.focus(); }
        refresh();
      }));
      ta.addEventListener('input', () => {
        ADV[id] = Object.assign({ st: '' }, ADV[id], { note: ta.value });
        save(KT.adv, ADV); refresh();
      });
      syncAdv(card);
    });

    /* ── 灵感捕捉 ── */
    const iin = $('#ideaIn');
    if (iin) {
      $$('.chip--tag').forEach(c => c.addEventListener('click', () => {
        $$('.chip--tag').forEach(x => x.classList.remove('is-on'));
        c.classList.add('is-on');
        const t = DATA2.inbox.tags.find(x => x.k === c.dataset.tag);
        $('#ideaLand').textContent = t.land;
      }));
      const add = () => {
        const v = iin.value.trim();
        if (!v) return;
        const tag = $('.chip--tag.is-on')?.dataset.tag || 'trend';
        IDEAS.unshift({ id: uid(), t: v, tag, at: new Date().toLocaleDateString('zh-CN') });
        save(KT.idea, IDEAS); iin.value = ''; drawIdeas(); refresh();
        toast('记下了，我这边已经收到');
      };
      $('#ideaAdd').addEventListener('click', add);
      iin.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); add(); } });
      drawIdeas();
    }

    /* ── 归因推演器 ── */
    const atv = $('.atv');
    if (atv) {
      $('#atvCust').value = ATTR.cust || '';
      $('#atvCust').addEventListener('input', e => { ATTR.cust = e.target.value; save(KT.attr, ATTR); drawAttr(); });
      $$('.opt2', atv).forEach(b => b.addEventListener('click', () => {
        const k = b.dataset.k, v = b.dataset.v;
        const multi = b.classList.contains('opt2--multi');
        if (multi) {
          const arr = ATTR[k] = ATTR[k] || [];
          const i = arr.indexOf(v);
          if (i >= 0) arr.splice(i, 1); else arr.push(v);
        } else {
          ATTR[k] = ATTR[k] === v ? '' : v;
        }
        save(KT.attr, ATTR); drawAttr(); refresh();
      }));
      $('#atvReset').addEventListener('click', () => {
        ATTR = {}; save(KT.attr, ATTR); $('#atvCust').value = ''; drawAttr(); refresh(); toast('已清空，重来一遍');
      });
      $('#atvCopy').addEventListener('click', () => {
        navigator.clipboard?.writeText(attrDraft()).then(
          () => toast('归因草稿已复制'), () => toast('复制失败，手动选中 pre 里的文字'));
      });
      $('#atvQueue').addEventListener('click', () => {
        addQ(`${ATTR.cust || '某客户'} 归因动作：${ATTR.move}`, 'ATTR');
        toast('已加进行动队列'); refresh();
      });
      drawAttr();
    }

    /* ── 模版生成器 ── */
    $$('.tpl').forEach(card => {
      const id = card.dataset.tpl;
      $('.tpl__x', card).addEventListener('click', () => {
        const on = card.classList.toggle('is-open');
        $('.tpl__x', card).textContent = on ? '收起 −' : '展开填参数 ＋';
      });
      $$('[data-tv]', card).forEach(inp => inp.addEventListener('input', () => {
        TVARS[inp.dataset.tv] = inp.value; save(KT.tpl, TVARS); drawTpl(id);
      }));
      $(`[data-tcopy="${id}"]`, card).addEventListener('click', () => {
        navigator.clipboard?.writeText(tplText(id)).then(
          () => toast(`${id} 指令已复制，直接发我`), () => toast('复制失败，手动选中'));
      });
      drawTpl(id);
    });

    /* ── 趋势卡模板 ── */
    $('#tcardCopy')?.addEventListener('click', () => {
      navigator.clipboard?.writeText($('#tcardPre').textContent).then(
        () => toast('趋势卡模板已复制 —— 落 _系统/趋势观察.md'), () => toast('复制失败，手动选中'));
    });

    /* ── 行动队列抽屉 ── */
    $('#queueBtn')?.addEventListener('click', openQ);
    $('#qdrawerX')?.addEventListener('click', () => $('#qdrawer').classList.remove('is-open'));
    $('#qAdd')?.addEventListener('click', () => {
      const v = $('#qIn').value.trim(); if (!v) return;
      addQ(v, '手动'); $('#qIn').value = ''; drawQ(); refresh();
    });
    $('#qIn')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); $('#qAdd').click(); }
    });
    $('#qClear')?.addEventListener('click', () => {
      if (!QUEUE.length) return;
      if (!confirm('清空整个行动队列？')) return;
      QUEUE = []; save(KT.queue, QUEUE); drawQ(); refresh(); toast('队列已清空');
    });
    drawQ();
  }

  /* ── 建议卡片状态同步 ── */
  function syncAdv(card) {
    const id = card.dataset.adv, s = ADV[id] || {};
    card.dataset.st = s.st || '';
    const L = { take: '已采纳 · 在队列里', tweak: '要改 · 等你写一句', deny: '不做 · 等你写原因' };
    $('.adv__badge', card).textContent = L[s.st] || '';
    $('.adv__hint', card).textContent = s.st ? '再点一次同一个按钮 = 撤销' : '';
    $$('[data-act]', card).forEach(b => b.classList.toggle('is-on', b.dataset.act === s.st));
  }

  /* ── 灵感列表 ── */
  function drawIdeas() {
    const box = $('#ideaList'); if (!box) return;
    if (!IDEAS.length) { box.innerHTML = `<div class="inbox__empty">还没记过。<b>趋势沉淀这一格现在是 ▇▇篇</b>，第一条从这里开始。</div>`; return; }
    const NAME = Object.fromEntries(DATA2.inbox.tags.map(t => [t.k, t.n]));
    box.innerHTML = IDEAS.map(i => `<div class="idea">
      <span class="idea__t chip chip--tag is-on">${NAME[i.tag] || i.tag}</span>
      <span class="idea__x">${esc(i.t)}</span>
      <span class="idea__d">${i.at}</span>
      <button class="idea__del" data-del="${i.id}" title="删掉">✕</button></div>`).join('');
    $$('[data-del]', box).forEach(b => b.addEventListener('click', () => {
      IDEAS = IDEAS.filter(x => x.id !== b.dataset.del);
      save(KT.idea, IDEAS); drawIdeas(); refresh();
    }));
  }

  /* ── 归因推演 ── */
  function attrDone() {
    return !!(ATTR.scope && ATTR.shape && (ATTR.signal || []).length && ATTR.cause && ATTR.move);
  }
  function attrLeft() {
    let n = 0;
    if (!ATTR.scope) n++;
    if (!ATTR.shape) n++;
    if (!(ATTR.signal || []).length) n++;
    if (!ATTR.cause) n++;
    if (!ATTR.move) n++;
    return n;
  }
  function attrDraft() {
    const S = DATA2.attrib.steps;
    const dOf = (k, v) => (S.find(x => x.k === k)?.opts.find(o => o.v === v)?.d) || '';
    const sig = ATTR.signal || [];
    const L = [
      `# 客户增减投归因草稿 · ${ATTR.cust || '（未填对象）'}`, '',
      `生成：${new Date().toLocaleString('zh-CN')}　|　来源：系统控制台归因推演器（六问链）`, '',
      '> ⚠️ 规则库「客户增减投归因」R-3xx 共 ▇▇条，**全部标「待验证」**（2026-09-12 由 v0 五问链搬入，尚未在真实客户上跑过）。',
      '> 这份草稿请先进 `_系统/待复核队列.md`，被真实结果验证过再转「已验证」。', '',
      '## 一、总盘子（第 ▇▇ 问 · 不问清这一步，后面全是猜）',
      `**${ATTR.scope || '—'}** — ${dOf('scope', ATTR.scope)}`, ''
    ];
    if (ATTR.scope === '总盘子也在缩') {
      L.push('> 🟢 **这一问就可以结案了。** 它整体在缩，不是你丢了份额。',
        '> 这种情况动作是**守份额**，不是抢回量。下面几步的结论只作参考，不要据此做补救动作。', '');
    }
    if (ATTR.scope === '不知道') {
      L.push('> 🔴 **第 ▇▇ 问：不知道，缺客户全渠道投放数据。**',
        '> 缺了第 ▇▇ 问的归因**不叫归因，叫猜测——本草稿不得对外使用**。',
        '> 先去补这个数：问客户 / 查行业大盘 / 问同行，补完再回来走后面四步。', '');
    }
    L.push('## 二、形状', `**${ATTR.shape || '—'}** — ${dOf('shape', ATTR.shape)}`, '',
      '## 三、观察到的信号', '');
    if (!sig.length) L.push('（未选）', '');
    else sig.forEach(v => L.push(`- **${v}**：${dOf('signal', v)}`));
    if (sig.includes('完全没有信号')) {
      L.push('', '> 🔴 勾了「完全没有信号」：这条归因的可信度按最低算。**先去拿信号，再谈原因。**');
    }
    L.push('', '## 四、主判断', `**${ATTR.cause || '—'}** — ${dOf('cause', ATTR.cause)}`, '');
    if (ATTR.cause === '信息不足') {
      L.push('> 选了「信息不足」是对的处理。**不要为了填满这份草稿去编一个原因。**', '');
    }
    L.push('## 五、下一步动作', `**${ATTR.move || '—'}** — ${dOf('move', ATTR.move)}`, '',
      '两周内怎么验证：', '- 动作做了没：', '- 客户侧有没有回应：', '- 我的判断被证实还是被推翻：', '',
      '---', '', '## 给 Aime 的处理要求',
      '▇▇. 把这条写进 `_系统/待复核队列.md`，标「归因推断 · 未验证」',
      '▇▇. **不要**直接写进 `_系统/判断规则库.md` 的 R-3xx 类——那三条自己都还没验过',
      '▇▇. 两周后主动问我验证结果；被推翻就存成反面教材，别悄悄删掉');
    if (ATTR.note) L.push('', '## 我的补充', ATTR.note);
    return L.join('\n');
  }
  function drawAttr() {
    const box = $('.atv'); if (!box) return;
    $$('.opt2', box).forEach(b => {
      const k = b.dataset.k, v = b.dataset.v;
      const on = Array.isArray(ATTR[k]) ? ATTR[k].includes(v) : ATTR[k] === v;
      b.classList.toggle('is-on', !!on);
    });
    const left = attrLeft();
    $('#atvProg').textContent = left ? `还差 ${left} 步` : '五步齐了';
    $('#atvProg').classList.toggle('is-done', !left);
    $('#atvCopy').disabled = !attrDone();
    $('#atvQueue').disabled = !ATTR.move;
    const miss = [!ATTR.scope && '总盘子', !ATTR.shape && '形状', !(ATTR.signal || []).length && '信号',
                  !ATTR.cause && '主判断', !ATTR.move && '动作'].filter(Boolean);
    $('#atvPre').textContent = attrDone() ? attrDraft()
      : '五步选完，这里会出一份可以直接发我的归因草稿。\n第一步必须先问总盘子——不然容易把行业周期误判成竞争失利。' +
        (left < 5 ? `\n\n（还差 ${left} 步：${miss.join(' / ')}）` : '');
  }

  /* ── 模版 ──
     变量规范：模版正文一律用 {{key}}。填了就逐字替换，没填就保留 {{变量中文名}}，
     绝不静默塞一个猜测值进去 —— 占位符留在那儿，我看到才会回来问。 */
  function tplText(id) {
    const t = DATA2.tpl.items.find(x => x.id === id);
    let s = t.body;
    t.vars.forEach(v => {
      const val = (TVARS[id + '.' + v.k] || '').trim();
      s = s.split('{{' + v.k + '}}').join(val || '{{' + v.n + '}}');
    });
    return s;
  }
  function drawTpl(id) {
    const pre = $(`[data-tpre="${id}"]`); if (!pre) return;
    pre.textContent = tplText(id);
  }

  /* ── 行动队列 ── */
  function addQ(t, from) {
    if (QUEUE.some(x => x.from === from && x.t === t)) return;
    QUEUE.unshift({ id: uid(), t, from, done: false });
    save(KT.queue, QUEUE); drawQ();
  }
  function rmQ(from) {
    const n = QUEUE.length;
    QUEUE = QUEUE.filter(x => x.from !== from);
    if (QUEUE.length !== n) { save(KT.queue, QUEUE); drawQ(); }
  }
  function openQ() { $('#qdrawer').classList.add('is-open'); drawQ(); }
  function drawQ() {
    const box = $('#qList');
    const n = QUEUE.filter(x => !x.done).length;
    const btn = $('#queueBtn');
    if (btn) {
      btn.innerHTML = n ? `队列 <span class="tbtn__kbd">${n}</span>` : '队列';
      btn.classList.toggle('is-on', n > 0);
    }
    if (!box) return;
    if (!QUEUE.length) {
      box.innerHTML = `<div class="qempty">队列空的。<br><br>两个来源：<b>采纳一条建议</b>，或者在下面手动加一条。<br>加进来的我会直接收到，<b>不用你再复述一遍</b>。</div>`;
      return;
    }
    box.innerHTML = QUEUE.map(x => `<label class="qi${x.done ? ' is-done' : ''}">
      <input type="checkbox" ${x.done ? 'checked' : ''} data-qd="${x.id}">
      <span class="qi__t">${esc(x.t)}</span>
      <span class="qi__f">${esc(x.from)}</span>
      <button class="qi__x" data-qx="${x.id}" title="删掉">✕</button></label>`).join('');
    $$('[data-qd]', box).forEach(c => c.addEventListener('change', () => {
      const it = QUEUE.find(x => x.id === c.dataset.qd); if (!it) return;
      it.done = c.checked; save(KT.queue, QUEUE); drawQ(); refresh();
    }));
    $$('[data-qx]', box).forEach(b => b.addEventListener('click', e => {
      e.preventDefault();
      QUEUE = QUEUE.filter(x => x.id !== b.dataset.qx);
      save(KT.queue, QUEUE); drawQ(); refresh();
    }));
  }

  /* ═══════════ 补丁片段 ═══════════ */
  function count() {
    const adv = Object.keys(ADV).length;
    const q = QUEUE.length;
    const idea = IDEAS.length;
    const at = attrDone() ? 1 : 0;
    return { adv, q, idea, at, all: adv + q + idea + at };
  }

  function patch() {
    const L = [];
    const advs = Object.entries(ADV);
    L.push('---', '', `## 四、主动建议的处置（${advs.length}/▇▇）`, '');
    if (!advs.length) L.push('（未处置。三条建议都还挂着）', '');
    else {
      const NM = { take: '✅ 采纳', tweak: '✏️ 要改', deny: '⛔ 不做' };
      advs.forEach(([id, s]) => {
        const it = DATA2.advice.items.find(x => x.id === id) || {};
        L.push(`### ${id} ${plain(it.t || '')}`);
        L.push(`- 处置：**${NM[s.st] || '（未选）'}**`);
        if (s.note) L.push(`- 我的话：${s.note}`);
        if (s.st === 'deny' && !s.note) L.push('- ⚠️ 驳回没写原因，这条我没法存成反面教材');
        L.push('');
      });
    }

    L.push('---', '', `## 五、行动队列（${QUEUE.filter(x => !x.done).length} 条未完成 / 共 ${QUEUE.length}）`, '');
    if (!QUEUE.length) L.push('（空）', '');
    else {
      QUEUE.forEach(x => L.push(`- [${x.done ? 'x' : ' '}] ${x.t}　*（来源：${x.from}）*`));
      L.push('');
    }

    L.push('---', '', `## 六、灵感捕捉（${IDEAS.length} 条）`, '');
    if (!IDEAS.length) L.push('（空）', '');
    else {
      const T = Object.fromEntries(DATA2.inbox.tags.map(t => [t.k, t]));
      const by = {};
      IDEAS.forEach(i => (by[i.tag] = by[i.tag] || []).push(i));
      Object.entries(by).forEach(([k, list]) => {
        const t = T[k] || { n: k, land: '待定' };
        L.push(`### ${t.n} → \`${t.land}\``);
        list.forEach(i => L.push(`- ${i.t}　*(${i.at})*`));
        L.push('');
      });
    }

    L.push('---', '', '## 七、客户增减投归因草稿', '');
    if (!attrDone()) L.push('（未完成推演）', '');
    else L.push(attrDraft(), '');

    return L;
  }

  /* v8：驾驶舱拆成四个独立视图，这三块要单独被调用 */
  function addIdea(t, tag) {
    t = String(t || '').trim(); if (!t) return 0;
    IDEAS.unshift({ id: uid(), t, tag: tag || 'trend', at: new Date().toLocaleDateString('zh-CN') });
    save(KT.idea, IDEAS); drawIdeas(); refresh();
    return IDEAS.length;
  }

  return { ovBlocks, blkEvo, blkAdvice, blkInbox, ecoBlocks, baseBlocks, secAssets, actBlock,
           wire, patch, count, addQ, openQ, addIdea };
})();
