/* ═══════════════════════════════════════════════════════════
   sply.js —— 达人与机构供给 · 策略资料库（渲染层）

   数据在 sply.data.js / sply.data2.js。这一层只负责画，不存判断。
   挂载位置：#plays「策略资料库」→ 第三格「方法与打法」（grp.js MAP.plays.s3）。
   ⛔ 不出现业绩金额（供给页的铁律）；机构侧/平台侧数字一律带口径标注。

   ⚠️ 每个 section 都带 data-dw="▇▇" data-d2="▇▇"：
     dash.js 会按文字长度猜块宽（短块 span ▇▇），并把"三条以上同类条目"自动
     改成两栏条目墙。这两件事会把三阶段路线的三列正文挤成 123px、一行两个字。
     所以这里显式声明：整宽 + 内部排布我自己管，不要再二次改。
   ═══════════════════════════════════════════════════════════ */
window.SPLY = (function () {

  const D  = window.SPLYD  || {};
  const D2 = window.SPLYD2 || {};

  /* 政策表状态徽标：前缀 ok/warn/stop 决定颜色 */
  function badge(s) {
    const m = String(s).match(/^(ok|warn|stop)(.*)$/);
    if (!m) return '<span class="spam__b">' + s + '</span>';
    return '<span class="spam__b is-' + m[1] + '">' + m[2] + '</span>';
  }

  /* ── ① 今日策略收口 + 长期资料母本 ──────────────────────── */
  function libBox() {
    const L = D.LIB || [];
    const F = D.DAILY;
    if (!L.length && !F) return '';
    const fresh = F ? `<div class="splf">
      <div class="splf__src">
        ${(F.sources || []).map(x => `<div class="splf__s"><b>${x[0]}</b><em>${x[1]}</em><span>${x[2]}</span></div>`).join('')}
      </div>
      <div class="splf__label"><b>最近确认记录</b><span>${(F.records || []).length}/▇▇ · 新确认直接替换旧确认</span></div>
      <div class="splf__records">
        ${(F.records || []).slice(0, 3).map(x => `<article class="splf__r">
          <span>${x.tag}</span><b>${x.t}</b><p>${x.d}</p>
        </article>`).join('')}
      </div>
    </div>` : '';
    const library = L.length ? `<div class="spli__label"><b>长期资料母本 · 已入库 ${L.length} 份</b>
      <span>保留用于回溯与调用，不计入今日确认记录</span></div>
      <div class="spli">
        ${L.map(x => `<div class="spli__i">
          <div class="spli__t"><a href="${x.u}" target="_blank" rel="noopener">${x.k} ↗</a>
            <i class="spli__lv">${x.lv}</i></div>
          <div class="spli__w">${x.w}</div>
          <div class="spli__c"><span>什么时候调它</span>${x.call}</div>
        </div>`).join('')}
      </div>` : '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--lib" data-mod="spl-lib">
      <div class="spl__h"><span class="spl__k spl__k--go">策略资料库 · ${F ? F.date + ' 已核验' : '资料母本'}</span>
        <b>${F ? F.title : '长期策略资料已完成入库'}</b>
        <em>${F ? F.lead : '每份都写清什么时候调它：这里是可调用的判断库，不是资料堆。'}</em></div>
      ${fresh}${library}
    </section>`;
  }

  /* ── ② 内热资料索引（飞书多维表格快照） ─────────────────── */
  function hotBox() {
    const H = window.SPLYHOT || {};
    const groups = H.GROUPS || [];
    const src = H.SOURCE || {};
    if (!groups.length) return '';
    const recordCount = groups.reduce((n, g) => n + (g.rows || []).length, 0);
    const linkCount = groups.reduce((n, g) => n + (g.rows || []).reduce((m, r) => m + (r.docs || []).length, 0), 0);
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--hot" data-mod="spl-hot">
      <div class="spl__h"><span class="spl__k spl__k--hot">内热资料索引 · ${recordCount} 条资料</span>
        <b>按现场问题找资料，不按文档名翻目录</b>
        <em>已把飞书资料按 ▇▇个调用入口整理成 ${linkCount} 个直达链接。政策数字、适用范围与时效以原文最新版本为准；页面快照同步于 ${src.date || '—'}。</em></div>
      <div class="sph__bar"><div><b>${groups.length}</b><span>调用入口</span></div><div><b>${recordCount}</b><span>资料主题</span></div><div><b>${linkCount}</b><span>直达链接</span></div>
        <a href="${src.url || '#'}" target="_blank" rel="noopener">打开「${src.name || '源多维表格'}」↗</a></div>
      <div class="sph">
        ${groups.map((g, gi) => `<details class="sph__g"${gi < 2 ? ' open' : ''}>
          <summary><span>${String(gi + 1).padStart(2, '0')}</span><b>${g.k}</b><em>${(g.rows || []).length} 条</em></summary>
          <p class="sph__call"><span>调用时机</span>${g.call}</p>
          <div class="sph__rows">${(g.rows || []).map(r => `<article class="sph__r">
            <div class="sph__rk">${r.k}</div>
            <div class="sph__docs">${(r.docs || []).map(d => `<a href="${d[1]}" target="_blank" rel="noopener">${d[0]} ↗</a>`).join('')}</div>
            ${r.note ? `<p>${r.note}</p>` : ''}
          </article>`).join('')}</div>
        </details>`).join('')}
      </div>
    </section>`;
  }

  /* ── ③ 口径纪律（放最前，防混算） ───────────────────── */
  function discBox() {
    const X = D.DISC;
    if (!X) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--disc" data-mod="spl-disc">
      <div class="spl__h"><span class="spl__k spl__k--warn">口径纪律 · ▇▇条</span>
        <b>${X.t}</b>
        <em>这批资料里的数全是机构侧 / 平台侧 / 外部案例口径，跟我那四套业绩口径一律不相加</em></div>
      <ul class="spld">
        ${X.rows.map(r => `<li><div class="spld__k">${r[0]}</div>
          <div class="spld__v">${r[1]}</div></li>`).join('')}
      </ul>
    </section>`;
  }

  /* ── ③ 机构类型两型对照（最能改动作的一层） ───────────── */
  function orgBox() {
    const O = D.ORG;
    if (!O) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--org" data-mod="spl-org">
      <div class="spl__h"><span class="spl__k">机构类型 × 经营策略 · 两型对照</span>
        <b>${O.t}</b>
        <em>${O.lead}</em></div>
      <div class="spo">
        <div class="spo__hd">
          <div class="spo__c spo__c--k">${O.dim[0] || '对照维度'}</div>
          <div class="spo__c spo__c--a">${O.dim[1]}</div>
          <div class="spo__c spo__c--b">${O.dim[2]}</div>
        </div>
        ${O.rows.map(r => `<div class="spo__r">
          <div class="spo__c spo__c--k">${r.k}</div>
          <div class="spo__c spo__c--a">${r.a}</div>
          <div class="spo__c spo__c--b">${r.b}</div>
        </div>`).join('')}
      </div>
      <p class="spo__v">${O.verdict}</p>
    </section>`;
  }

  /* ── ④ 机构成长路线（客户A三阶段） ─────────────────── */
  function pathBox() {
    const P = D.PATH;
    if (!P) return '';
    const nums = `<div class="spp__nums">${(P.nums || []).map((n, i) => `<div class="spp__n" data-c="${i % 6}">
      <div class="spp__v">${n[0]}<i>${n[1]}</i></div>
      <div class="spp__t">${n[2]}</div>
      <div class="spp__d">${n[3] || ''}</div></div>`).join('')}</div>`;

    const stages = `<div class="spps">${(P.stages || []).map(s => `<div class="spps__i">
      <div class="spps__hd"><span class="spps__n">${s.n}</span>
        <div class="spps__tt">${s.t}<em>${s.bg}</em></div></div>
      <div class="spps__g">
        <div class="spps__col spps__col--pain"><span>当时卡在哪</span>
          <ul>${s.pain.map(x => '<li>' + x + '</li>').join('')}</ul></div>
        <div class="spps__col spps__col--act"><span>做了什么牵引</span>
          <ul>${s.act.map(x => '<li>' + x + '</li>').join('')}</ul></div>
        <div class="spps__col spps__col--res"><span>结果</span>
          <ul>${s.res.map(x => '<li>' + x + '</li>').join('')}</ul></div>
      </div></div>`).join('')}</div>`;

    const th = P.thick ? `<div class="sppt">
      <div class="sppt__h">${P.thick.t}</div>
      <div class="sppt__g">${P.thick.rows.map(r => `<div class="sppt__i">
        <b>${r[0]}</b><span>${r[1]}</span></div>`).join('')}</div>
      <p class="sppt__s">${P.thick.say}</p></div>` : '';

    const ai = P.ai ? `<div class="sppa">
      <div class="sppa__h">${P.ai.t}<em>${P.ai.lead}</em></div>
      <table class="sppa__t"><thead><tr>${P.ai.head.map(h => '<th>' + h + '</th>').join('')}</tr></thead>
      <tbody>${P.ai.rows.map(r => '<tr>' + r.map((c, i) =>
        '<td' + (i === 0 ? ' class="is-k"' : '') + '>' + c + '</td>').join('') + '</tr>').join('')}</tbody>
      </table></div>` : '';

    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--path" data-mod="spl-path">
      <div class="spl__h"><span class="spl__k">机构成长路线 · 三阶段样板</span>
        <b>${P.t}</b>
        <em>${P.lead}</em></div>
      ${nums}${stages}${th}${ai}
    </section>`;
  }

  /* ── ⑤ 专项业务 × 培育动作 ───────────────────────── */
  function specBox() {
    const S = D2.SPEC || [];
    if (!S.length) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--spec" data-mod="spl-spec">
      <div class="spl__h"><span class="spl__k">专项业务 × 培育动作 · ${S.length} 类</span>
        <b>不同类型的专项业务，分别能做什么培育</b>
        <em>每一类写清「平台侧现状 / 可做的培育 / 什么时候调它」，带 ⭐ 的是我读完认为最该先用的</em></div>
      <div class="spc">
        ${S.map(x => `<div class="spc__i">
          <div class="spc__hd"><b class="spc__k">${x.k}</b><i class="spc__st">${x.st}</i></div>
          <div class="spc__now"><span>现状</span>${x.now}</div>
          <ul class="spc__g">${x.grow.map(g => '<li>' + g + '</li>').join('')}</ul>
          <div class="spc__w"><span>调用时机</span>${x.when}</div>
        </div>`).join('')}
      </div>
    </section>`;
  }

  /* ── ⑥ 行业 × 现状与培育 ────────────────────────── */
  function indBox() {
    const I = D2.IND;
    if (!I) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--ind" data-mod="spl-ind">
      <div class="spl__h"><span class="spl__k">行业 × 现状与培育 · ${I.rows.length} 类</span>
        <b>不同的行业，分别适合什么达人、能做什么培育</b>
        <em>${I.lead}</em></div>
      <div class="spi__wrap"><table class="spi">
        <thead><tr>${I.head.map(h => '<th>' + h + '</th>').join('')}</tr></thead>
        <tbody>${I.rows.map(r => '<tr>' +
          '<td class="is-k">' + r[0] + '</td><td>' + r[1] + '</td><td>' + r[2] + '</td></tr>').join('')}
        </tbody></table></div>
    </section>`;
  }

  /* ── ⑦ 达人类型 × 培育路径（接身份标签框架） ─────────── */
  function talBox() {
    const T = D2.TAL;
    if (!T) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--tal" data-mod="spl-tal">
      <div class="spl__h"><span class="spl__k">达人类型 × 培育路径 · ${T.rows.length} 类</span>
        <b>不同的达人类型，分别走哪条变现路径</b>
        <em>${T.lead}</em></div>
      <div class="spt">
        ${T.rows.map(x => `<div class="spt__i">
          <div class="spt__hd"><b class="spt__k">${x.k}</b><i class="spt__tag">${x.tag}</i></div>
          <div class="spt__r"><span>现状</span>${x.now}</div>
          <div class="spt__r spt__r--p"><span>变现路径</span>${x.path}</div>
          <div class="spt__r spt__r--m"><span>我盘对应</span>${x.mine}</div>
        </div>`).join('')}
      </div>
      <p class="spt__go">这一层和「本周策略回顾 · 高变现能力拆解」是同一套判断
        —— 那边放已拆完的个案（明星B · 达人E），这边放可套用的类型路径。
        <button class="spt__b" data-jumpv="run">去本周策略回顾 →</button></p>
    </section>`;
  }

  /* ── ⑧ 政策弹药表 ─────────────────────────────── */
  function ammoBox() {
    const A = D2.AMMO;
    if (!A) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--ammo" data-mod="spl-ammo">
      <div class="spl__h"><span class="spl__k">政策与激励弹药表 · ${A.rows.length} 条</span>
        <b>机构问「现在有什么政策」时，能立刻报出数字和门槛</b>
        <em>${A.lead}</em></div>
      <div class="spam__wrap"><table class="spam">
        <thead><tr>${A.head.map(h => '<th>' + h + '</th>').join('')}</tr></thead>
        <tbody>${A.rows.map(r => '<tr>' +
          '<td class="is-k">' + r[0] + '</td>' +
          '<td class="is-n">' + r[1] + '</td>' +
          '<td class="is-s">' + badge(r[2]) + '</td>' +
          '<td>' + r[3] + '</td></tr>').join('')}
        </tbody></table></div>
    </section>`;
  }

  /* ── ⑨ 创意生态三率 ───────────────────────────── */
  function creaBox() {
    const C = D2.CREA;
    if (!C) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--crea" data-mod="spl-crea">
      <div class="spl__h"><span class="spl__k">创意生态 · 投前投中投后</span>
        <b>${C.t}</b>
        <em>${C.lead}</em></div>
      <div class="spcr">
        ${C.stage.map(s => `<div class="spcr__i">
          <div class="spcr__n">${s.n}</div>
          <div class="spcr__k">${s.k}</div>
          <ul>${s.it.map(x => '<li>' + x + '</li>').join('')}</ul>
        </div>`).join('')}
      </div>
      <p class="spcr__s">${C.say}</p>
    </section>`;
  }

  /* ── ⑩ 落到我盘（读完立刻改的动作） ────────────────── */
  function mineBox() {
    const M = D2.MINE;
    if (!M) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--mine" data-mod="spl-mine">
      <div class="spl__h"><span class="spl__k spl__k--go">落到我盘 · ${M.rows.length} 个改动</span>
        <b>${M.t}</b>
        <em>${M.lead}</em></div>
      <div class="spm">
        ${M.rows.map(r => `<div class="spm__i${r.cls ? ' is-' + r.cls : ''}">
          <div class="spm__n">${r.n}</div>
          <div class="spm__t">${r.t}</div>
          <div class="spm__b">${r.b}</div>
        </div>`).join('')}
      </div>
    </section>`;
  }

  /* ── ⑪ 高频调用场景索引 ──────────────────────────── */
  function sceneBox() {
    const S = D2.SCENE || [];
    if (!S.length) return '';
    return `<section data-dw="▇▇" data-d2="▇▇" class="spl spl--scene" data-mod="spl-scene">
      <div class="spl__h"><span class="spl__k">高频调用场景 · ${S.length} 个</span>
        <b>不用记上面那一堆 —— 记这 ${S.length} 句就够</b>
        <em>左边是会真实发生的一句话，右边是该翻这一页的哪一层</em></div>
      <div class="spsc">
        ${S.map((x, i) => `<div class="spsc__i">
          <em>${String(i + 1).padStart(2, '0')}</em>
          <b>${x[0]}</b><span>${x[1]}</span></div>`).join('')}
      </div>
    </section>`;
  }

  function render(id) {
    return libBox() + (id === 'plays' ? hotBox() : '') + discBox() + orgBox() + pathBox() + specBox() +
           indBox() + talBox() + ammoBox() + creaBox() + mineBox() + sceneBox();
  }

  return { render };
})();
