/* ═══════════════════════════════════════════════════════════
   shell.js —— 四栏工作台版式的两根新柱子 + 模块横幅
     ① 左侧图标轨（.dock）：常用模块与动作一键直达
     ② 右侧上下文栏（.side）：今天从哪儿开始 / 等你定的 / 随手记
     ③ 模块横幅（.mhero）：分区 + 标题 + 三格元信息
   —— 数据全部来自页面既有来源（OS.BY / UI.QUICK / window.ASKS / FB / DATA.meta），
      不新增任何数字，业绩数字一个都不搬（铁律：业绩只在业务基本盘）。
   —— 载入顺序：必须在 render.js 之后。
   —— 退回方式：Tweaks → 版式 → 单栏长页（body 去掉 .shell，本文件产物全部隐藏）。
   ═══════════════════════════════════════════════════════════ */
window.SHELL = (function () {

  const K = 'cec.sh.side';
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];

  /* ── 图标：▇▇ 描边，跟全站 svg.ic 一致 ── */
  const P = {
    home: '<path d="M3 10.2 12 3l9 7.2V21H3z"/><path d="M9.2 21v-6.2h5.6V21"/>',
    bars: '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.6 2.6 2.6 15.4 0 18-2.6-2.6-2.6-15.4 0-18z"/>',
    flag: '<path d="M5 21V4"/><path d="M5 4h11l-1.6 3.5L16 11H5"/>',
    spark: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/>',
    inf: '<path d="M7.5 9.5c2 0 2.5 5 4.5 5s2.5-5 4.5-5 3 1.1 3 2.5-1.4 2.5-3 2.5-2.5-5-4.5-5-2.5 5-4.5 5-3-1.1-3-2.5S5.9 9.5 7.5 9.5z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4.2-4.2"/>',
    chat: '<path d="M20 15.5A2.5 2.5 0 0 1 17.5 18H8l-4 3V6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5z"/>',
    link: '<path d="M10.5 13.5a4 4 0 0 0 5.7 0l2.3-2.3a4 4 0 0 0-5.7-5.7L11.6 6.7"/><path d="M13.5 10.5a4 4 0 0 0-5.7 0L5.5 12.8a4 4 0 0 0 5.7 5.7l1.2-1.2"/>',
    panel: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16"/>',
    side: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M15 4v16"/>',
    slider: '<path d="M4 7h10"/><path d="M18 7h2"/><path d="M4 17h4"/><path d="M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
    target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>'
  };
  const ic = n => `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
    stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n] || P.target}</svg>`;

  /* ── ① 图标轨 ─────────────────────────── */
  const DOCK = [
    { i: 'home',   t: '驾驶舱 · 今天该动哪几件', v: 'deck' },
    { i: 'bars',   t: '我的业务基本盘（业绩数字都在这）', v: 'base' },
    { i: 'globe',  t: '「外部大盘」 · 外部趋势与机会', v: 'eco' },
    { i: 'flag',   t: '重要事项确认', v: 'confirm', badge: 1 },
    { i: 'spark',  t: '自生长与高阶能力 · 「我能装的技能」', v: 'cap' },
    { i: 'inf',    t: '永久记忆库', v: 'memory' },
    { sep: 1 },
    { i: 'search', t: '搜索（⌘K）', click: '#palBtn' },
    { i: 'chat',   t: '我的反馈 / 收件箱', click: '#fbBtn' },
    { i: 'link',   t: '商机 × 达人 × 策划作战台（新窗口）', open: 'https://app.internal.example/' }
  ];
  const DOCK_FOOT = [
    { i: 'panel',  t: '收起 / 展开导航栏', act: 'nav' },
    { i: 'side',   t: '收起 / 展开上下文栏', act: 'side' },
    { i: 'slider', t: '版式与画风（Tweaks）', click: '#tweaksToggle' }
  ];

  function btn(d) {
    if (d.sep) return '<div class="dock__ln"></div>';
    const a = d.v ? `data-shv="${d.v}"` : d.click ? `data-shc="${d.click}"` : d.open ? `data-sho="${d.open}"` : `data-sha="${d.act}"`;
    return `<button class="dock__b" ${a} data-tip="${d.t}" aria-label="${d.t}">${ic(d.i)}${d.badge ? '<b class="dock__n" data-shn hidden></b>' : ''}</button>`;
  }

  function renderDock() {
    if ($('#dock')) return;
    const el = document.createElement('nav');
    el.className = 'dock'; el.id = 'dock'; el.setAttribute('aria-label', '快捷轨');
    el.innerHTML = `<button class="dock__av" data-shv="deck" title="达人生态 OS · 回驾驶舱">OS</button>
      <div class="dock__ln"></div>
      ${DOCK.map(btn).join('')}
      <div class="dock__sp"></div>
      ${DOCK_FOOT.map(btn).join('')}`;
    document.body.appendChild(el);

    el.addEventListener('click', e => {
      const b = e.target.closest('button');
      if (!b) return;
      if (b.dataset.shv) { OS.show(b.dataset.shv); return; }
      if (b.dataset.shc) { $(b.dataset.shc) && $(b.dataset.shc).click(); return; }
      if (b.dataset.sho) { window.open(b.dataset.sho, '_blank', 'noopener'); return; }
      if (b.dataset.sha === 'nav')  { $('#osFold') && $('#osFold').click(); return; }
      if (b.dataset.sha === 'side') { toggleSide(); return; }
    });
  }

  function paintDock() {
    const v = document.body.dataset.view;
    /* 驾驶舱本身就有「今天从哪儿开始」，右栏那一段就不重复第二遍 */
    const sd = $('#side'); if (sd) sd.dataset.view = v || '';
    $$('.dock__b[data-shv]').forEach(b => b.classList.toggle('is-on', b.dataset.shv === v));
    const dot = $('[data-shn]');
    if (dot) { const n = pendN(); dot.textContent = n; dot.hidden = !n; }
  }

  /* ── ② 上下文栏 ───────────────────────── */
  function pendAsks() {
    const all = window.ASKS || [];
    if (!window.FB || !FB.answerOf) return all;
    return all.filter(a => !FB.answerOf(a.id));
  }
  const pendN = () => pendAsks().length;
  /* 快捷入口跟驾驶舱共用同一份 QUICK（ui.js 里的 UIX），页面上只有一份口径 */
  const quick = () => (window.UIX && UIX.QUICK) || (window.UI && UI.QUICK) || [];

  function recent() {
    try { return (FB.list() || []).filter(i => i.kind === 'idea' || i.kind === 'todo').slice(0, 2); }
    catch (e) { return []; }
  }

  function renderSide() {
    let el = $('#side');
    if (!el) {
      el = document.createElement('aside');
      el.className = 'side'; el.id = 'side'; el.setAttribute('aria-label', '上下文栏');
      document.body.appendChild(el);
    }
    /* 她正在随手记里打字时不许重画，否则半句话被抹掉 */
    const draft = $('#shNote');
    if (draft && (document.activeElement === draft || draft.value.trim())) return;
    const asks = pendAsks();
    const stamp = (window.DATA && DATA.meta && DATA.meta.stamp) || '';
    const qi = q => ic(q.i === 'bars' ? 'bars' : q.i === 'flag' ? 'flag' : q.i === 'globe' ? 'globe' : 'link');

    el.innerHTML = `
      <div class="side__hd">
        <div>
          <div class="side__t">今天这一栏</div>
          <div class="side__s">入口 · 等你定的 · 随手记${stamp ? ' · 数据截止 ' + stamp : ''}</div>
        </div>
        <button class="side__x" id="sideX" title="收起上下文栏">›</button>
      </div>
      <div class="side__b">
        <section class="sblk sblk--q">
          <div class="sblk__h"><span class="sblk__t">今天从哪儿开始</span>
            <span class="sblk__n">${quick().length} 个入口</span>
            <button class="sblk__go" data-shv="deck">驾驶舱 →</button></div>
          <div class="sq">
            ${quick().map(q => `<button class="sq__i" ${q.v ? `data-shv="${q.v}"` : `data-sho="${q.u}"`}>
              <span class="sq__ic">${qi(q)}</span>
              <span class="sq__t">${q.t}</span>
              <span class="sq__d">${q.d}</span></button>`).join('')}
          </div>
        </section>

        <section class="sblk">
          <div class="sblk__h"><span class="sblk__t">等你定的</span>
            <span class="sblk__n">${asks.length} 件</span>
            <button class="sblk__go" data-shv="confirm">全部 →</button></div>
          <div class="sa">
            ${asks.length ? asks.slice(0, 3).map(a => `<button class="sa__i" data-shask="${a.id}">
                <span class="sa__id">${a.id}</span>
                <span class="sa__q">${a.q}</span>
                <span class="sa__w">${a.view || ''}${a.opts && a.opts.length ? ' · ' + a.opts.length + ' 个选项' : ''}</span>
              </button>`).join('')
              : '<div class="sa__none">没有卡着的事，都不用你现在决定。</div>'}
          </div>
        </section>

        <section class="sblk">
          <div class="sblk__h"><span class="sblk__t">随手记</span>
            <span class="sblk__n">回车就提交给我</span></div>
          <div class="sn__box">
            <textarea class="sn__in" id="shNote" rows="▇▇"
              placeholder="看到什么现象 / 想到什么玩法 / 谁可能有需求…"></textarea>
            <div class="sn__f"><span class="sn__k">进灵感库，我这边直接收到</span>
              <button class="sn__go" id="shNoteGo">记下</button></div>
          </div>
          <div class="sn__l">
            ${recent().map(r => `<div class="sn__i"><b>${r.ts || ''}</b>${(r.text || '').slice(0, 60)}</div>`).join('')}
          </div>
        </section>
      </div>`;

    $('#sideX').addEventListener('click', toggleSide);
    el.addEventListener('click', e => {
      const b = e.target.closest('[data-shv],[data-sho],[data-shask]');
      if (!b) return;
      if (b.dataset.shv) { OS.show(b.dataset.shv); return; }
      if (b.dataset.sho) { window.open(b.dataset.sho, '_blank', 'noopener'); return; }
      if (b.dataset.shask) gotoAsk(b.dataset.shask);
    });

    /* 提交复用底部指令栏那一套，不另写一份，避免两处口径分叉 */
    const send = () => {
      const t = $('#shNote'), v = (t.value || '').trim();
      if (!v) return;
      const cmd = $('#cmdIn'), go = $('#cmdGo');
      if (!cmd || !go) return;
      cmd.value = v; go.click();
      /* 本批满了的话指令栏那边会拦住并把这句话留在 cmdIn 里，这里就不清空 */
      if ((cmd.value || '').trim()) { t.focus(); return; }
      t.value = '';
      setTimeout(() => { renderSide(); paintDock(); }, 320);
    };
    $('#shNoteGo').addEventListener('click', send);
    $('#shNote').addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
    });
  }

  /* 待定项：先找到它挂在哪个模块，切过去再滚过去并闪一下 */
  function gotoAsk(id) {
    const card = $(`.ask[data-ask="${id}"]`);
    const sec = card && card.closest('.sec');
    if (sec && window.OS) OS.show(sec.id, { noscroll: 1 });
    setTimeout(() => {
      const t = $(`.sec.is-view .ask[data-ask="${id}"]`) || card;
      if (!t) return;
      const off = document.body.classList.contains('shell') ? 96 : 116;
      window.scrollTo({ top: Math.max(t.getBoundingClientRect().top + window.scrollY - off, 0), behavior: 'smooth' });
      t.classList.remove('is-flash'); void t.offsetWidth; t.classList.add('is-flash');
    }, 240);
  }

  function toggleSide() {
    const off = document.body.classList.toggle('side-off');
    localStorage.setItem(K, off ? 'off' : 'on');
    const b = $('#sideBtn'); if (b) b.classList.toggle('is-on', !off);
    setTimeout(() => window.CEC_CHARTS && CEC_CHARTS.resizeAll && CEC_CHARTS.resizeAll(), 300);
  }

  /* 顶栏也放一个开关，右栏收起后还能找回来 */
  function wireTopBtn() {
    if ($('#sideBtn')) return;
    const host = $('.topbar__right');
    if (!host) return;
    const b = document.createElement('button');
    b.className = 'tbtn'; b.id = 'sideBtn';
    b.title = '上下文栏：今天从哪儿开始 / 等你定的 / 随手记';
    b.style.padding = '0 9px';
    b.innerHTML = ic('side');
    b.addEventListener('click', toggleSide);
    host.insertBefore(b, host.firstChild);
    b.classList.toggle('is-on', !document.body.classList.contains('side-off'));
  }

  /* ── ③ 模块横幅：插在原标题前面，原标题保留（退回长页时它就回来） ── */
  function heroes() {
    const stamp = (window.DATA && DATA.meta && DATA.meta.stamp) || '';
    $$('.sec').forEach(sec => {
      const head = $('.sec__head', sec);
      if (!head) return;
      const s = (window.OS && OS.BY && OS.BY[sec.id]) || {};
      const title = (($('.sec__t h2', head) || {}).textContent) || s.t || '';
      const blocks = $$('.mnav__a', sec).length;
      const meta = [];
      if (blocks) meta.push(['本页板块', blocks + ' 块']);
      meta.push(['所属分区', s.gt || '—']);
      if (stamp) meta.push(['数据截止', stamp]);

      const html = `<div class="mhero">
          <div class="mhero__l">
            <div class="mhero__ic">${s.ic || '◎'}</div>
            <div>
              <div class="mhero__g">${s.gt || ''}</div>
              <h2>${title}</h2>
            </div>
          </div>
          <div class="mhero__meta">
            ${meta.map(m => `<div class="mh"><div class="mh__k">${m[0]}</div><div class="mh__v">${m[1]}</div></div>`).join('')}
          </div>
        </div>`;

      const old = $('.mhero', head);
      if (old) { old.outerHTML = html; return; }
      head.insertAdjacentHTML('afterbegin', html);
    });
  }

  /* ── 启动 ─────────────────────────────── */
  function boot() {
    if (localStorage.getItem(K) === 'off') document.body.classList.add('side-off');
    renderDock();
    renderSide();
    wireTopBtn();
    heroes();
    paintDock();

    /* 视图切换由 body[data-view] 反映，监听它比 hook OS.show 稳 */
    new MutationObserver(() => paintDock())
      .observe(document.body, { attributes: true, attributeFilter: ['data-view'] });

    /* 「等你定」提交后，右栏和图标轨角标要跟着掉 */
    document.addEventListener('click', e => {
      if (e.target.closest('.ask__go, .cmdbar__go')) setTimeout(() => { renderSide(); paintDock(); }, 320);
    });
  }

  return { boot, renderSide, paintDock, toggleSide, heroes };
})();

(function () {
  const go = () => { try { SHELL.boot(); } catch (e) { console.warn('shell', e); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go);
  else go();
})();
