/* ═══════════════════════════════════════════════════════════
   own.js —— 我主动领活（协作机制与调用思考）
   2026-09-14 11:19 她的原话：
     「你这里不要总是等我派活，你可以看一下整个工作台的运行情况，
       结合你的能力帮我看看哪些适合你直接去做的发过来问我，
       你也可以直接调用技能来实现」

   所以这一页的主语从"你"换成"我"：
     旧：你怎么派活 → ▇▇个入口 + 我的 ▇▇个硬停点（=一直是我等你）
     新：我看完全站运行情况之后，自己列出该谁干什么
       ① 我已经在做 / 马上就做的（.ownmine）——不用你点头，做完给你结果
       ② 我建议我做、但必须你一句话才敢动的（.ownask）——会动你的东西或要花你的资源
       ③ 我绝不自己决定的（.ownstop）——碰到就停，摆给你裁

   ⛔ 三条硬规矩：
     ▇▇. 每条活必须写清"我看到什么现象才领的"，不许凭空领活；
     ▇▇. 会往你仓库写文件、要你的登录态、要装新东西的，一律进第②类，不许我自己动；
     ▇▇. 领了就有交付形态和验收方式，不许写"我会持续关注"。
   ═══════════════════════════════════════════════════════════ */
window.OWN = (function () {

  /* ── ① 不用你点头，我自己做 ────────────────────────────
     see  = 我看到的现象（哪一页、哪个数，能被你核）
     job  = 我要做的那件事（具体到产出物）
     use  = 我会调用什么（已有能力，不装新东西）
     out  = 做完你会拿到什么
     when = 什么时候给你
     safe = 为什么这件不用问你（判定：不动你的文件、不花你的时间、不改口径） */
  const MINE = [
    { job: '把 ▇▇位无刊例达人按机构分组，出一张「按机构索刊例」清单',
      see: '刊例覆盖只有 ▇▇（▇▇），而"客户问价答不上"这件事每周都在发生。',
      use: '现有达人池数据 + 打标名单，不需要新能力',
      out: '一张按机构排的索取清单：这家有几位没报价、优先要哪几位、拜访时顺口就能要',
      when: '你说一声，当天出', safe: '只读现有数据，不改任何口径，不写你的仓库',
      her: '就这么做', herAt: '09-16',
      chg: '不用改，照原方案做。<b>唯一要你给一次的东西：刊例那张表我只能读到汇总，机构归属要从打标名单对</b>—— 对不上的那部分我会单列"归属不明"，不硬塞给某一家。' },
    { job: '点名商机里挑需求最多的前 ▇▇位，先做这 ▇▇位；同时排查是不是已经有对接同学',
      see: '▇▇条点名类商机里 ▇▇条点的人你手上没有。<b>但这 ▇▇条不等于 ▇▇个机会</b> —— 你 09-16 说了：很可能已经有对接同学了。',
      use: '商机作战台数据 + 现有分析能力',
      out: '前 ▇▇位一张表：谁被点了几次、来自哪些客户/行业、有没有同事已经在对 —— <b>没排查完的一律标"待排查"，不写成可签</b>',
      when: '你说一声，当天出前 ▇▇位', safe: '只读，不动名单也不动分层；不替你去问同事，排查口子留给你',
      her: '按我说的改', herAt: '09-16',
      herSaid: '「你可以点做，但很有可能是已经有对接同学了，这个后面还要再排查，你可以先拎需求最多的前▇▇位」',
      chg: '两处照你的话改了：① 范围从"▇▇条全量拓新优先级表"<b>收窄成需求最多的前 ▇▇位</b>；② 交付物里加一列<b>「是否已有对接同学 · 待排查」</b>，这一列没结论之前，这 ▇▇位一个都不算拓新机会，只算候选。' },
    { job: '按 Q3 收口底表持续刷新周度策略回顾，并在 Q4 首批数据入表后重算',
      see: '当前最新可确权底表截止 2026-09-30；Q3 已结算 ▇▇万、达成 ▇▇，Q4 记录尚未入表。旧 09-05 分层与专项只能作为历史快照。',
      use: '09-30 飞书底表 + 最新完整 ▇▇ 天窗口 + 业务底仓与外部大盘佐证',
      out: '当前版已输出 ▇▇~▇▇ 周度策略回顾；Q4 首批数据到位后自动切换到真实 Q4 MTD/QTD、机构结构、合作类型与行业四层下钻。',
      when: '✅ 当前版已于 2026-10-08 更新；下一次在 Q4 首批数据入表后', safe: '沿用已确定的结算口径，只更新数据窗口和当前策略，不篡改历史快照',
      her: '直接全量同步更新', herAt: '10-08',
      herSaid: '「业务工作区全部的数据及策略都要同步做更新迭代，包括不限于周度策略回顾等等的」',
      chg: '已把任务从“重跑旧周报”升级为<b>整个业务工作区的持续口径治理</b>：Q3 最终收口、Q4 接数状态、最新完整 ▇▇ 天、结构风险和下一步动作必须同步更新。' },
    { job: '待复核那 ▇▇条我自己去找证据，找到的进词典，找不到的老实降级，只端 ▇▇条给你',
      see: '▇▇条推断挂在队列里，清队列现在要占你的时间 —— 但其中大部分我自己能验。',
      use: '现有看板与数据源逐条回源',
      out: '你每次只需要答 ▇▇ 句"对/不对"，其余我处理完在变更日志里写清怎么处理的',
      when: '从下一次收尾开始', safe: '找不到证据的一律降级，绝不混进事实层（这条是你的红线）',
      her: '就这么做', herAt: '09-16',
      chg: '不用改。<b>只端 ▇▇条的标准我写死</b>：只有"你本人才知道答案"的那种才端给你（例：某位达人有没有隐性经纪约），凡是看板里能查的我不占你时间。' },
    { job: '把仓库里的判断规则和口径导成一份数据文件，让页面直接读',
      see: '页面上写的规则数与口径数原来是我一条条手抄进代码的 —— 仓库改了页面不会动。',
      use: '本地仓库只读 + 导出脚本 + 页面数据层',
      out: '仓库一改，我重跑一次导出，页面下次刷新就跟着变；你在页面上看到的条数永远是真的',
      when: '✅ 09-16 当天做完了', safe: '导出脚本只读你的仓库，一个字都不写',
      her: '就这么做', herAt: '09-16',
      done: '<b>已交付</b>：判断规则 <b>' + RC() + ' 条</b>、口径 <b>' + TC() + ' 条</b>已从你本地仓库导出成数据文件，页面直接读（见记忆库那一页的「规则与口径」）。<b>页面上这两个数字从此不是我手抄的。</b>一处实话：不是实时同步 —— 你改完仓库要我重跑一次导出，页面上标着"导出于什么时候、源文件已旧几天"。',
      goview: 'memory', gosel: 'rul' },
    { job: '给每条策略动作留一个"这条不实用"的入口，并把你的原话攒成改法',
      see: '你 11:17 说七条动作不够实用 —— 这一版已经加了入口，但"下次怎么改"要靠你的原话攒。',
      use: '页面反馈通道（已通）',
      out: '你点一下、写一句，下一版那条动作按你的话重写，不用你导出补丁',
      when: '今天这一版已经加上了', safe: '你的原话我一个字不改地存进学习日志' }
  ];

  /* ── ② 我建议我做，但要你一句话 ──────────────────────
     why  = 我为什么想做（现象）
     need = 为什么必须先问你（会动到什么）
     out  = 做完你会拿到什么
     lose = 你不点头会一直怎样 */
  const ASK = [
    { t: '用你的星图后台登录态，把达人A那两层缺的证据一次拉全', hot: 1,
      why: '案例二第二层（粉丝粘性）和第三层（转化价值）现在一个字都没有，我只能标"证不了"。',
      need: '要<b>你打开一次登录态</b>，我不碰你的账号，取完就写进达人档案。',
      out: '三层原因从推断变证据；模式库里卡住的 ▇▇套（矩阵测投 / 短直联动那类）同时解锁。',
      lose: '这个案例只能当单点讲，讲不成能搬给别人的模式。',
      her: '按我说的改', herAt: '▇▇-16 23:▇▇',
      herSaid: '「就这么做，需要登录的时候，你可以触发对话给我，我来授权」',
      chg: '你把这件从"等你哪天有空点头"改成了<b>按需授权</b> —— 这是这一版最大的一个解锁。我按它立了一条<b>登录授权请求</b>通道（主动私聊的第 ▇▇ 类，前三类是周二复盘 / 你点头的事有结果 / 红线级异常）：<b>我只在真要取数的那一刻找你</b>，固定说清五件事 —— 要登录哪个系统 · 为什么是现在 · 我要取哪几个字段 · 取完你拿到什么 · 大概占你几分钟。<br>⛔ 三条我不越的线：① <b>不存你的账号密码、不存 Cookie</b>，登录态由你在你自己电脑上开，取完即止；② 一次只取我说过的那几个字段，<b>不顺手多拉别的</b>；③ 同一件事我<b>只找你一次</b>，你没回我就等着，不追第二条。<br>⚠️ 一处实话：这条通道<b>今天刚立、还没跑过一次真实授权</b>；第一次跑就是拉达人A那两层。',
      settled: 1 },
    { t: '每天 10:00 我推 ▇▇行摘要，并把"今天的新变化"那一栏刷新',
      why: '现在「外部大盘」和各模块的最新变化都是我手动补写的，不是自动的 —— 会慢慢变成旧闻。',
      need: '⚠️ <b>实话</b>：我不是常驻进程，真定时我做不到。要你每天说一句"整理一下"，我 ▇▇ 分钟内给你。',
      out: '▇▇行摘要 + 那一栏当天刷新 + 昨天到今天真变了的事。',
      lose: '那一栏越来越旧，你就不看了，等于白做。' },
    { t: '接商机数据管道，让作战台每天自己重跑',
      why: '作战台是静态站，站里是 09-12 快照 —— 那 ▇▇条今天能提报的，可能已经被别人提掉了。',
      need: '这件是我的活，但要动作战台的部署，<b>改完是新地址</b>，你的书签要换一次。',
      out: '你进去看到的条数就是当天的，不用再问我"这个数是几号的"。',
      lose: '每次用作战台都得先问一句数据是哪天的。',
      her: '就这么做', herAt: '▇▇-16 23:▇▇',
      chg: '照做，不改方案。<b>但我必须先说清"每天自己重跑"这句话我能做到哪一半</b>：取数、重算、重新生成页面这三步我都能做，<b>卡的是"每天自己"</b> —— 我不是常驻进程，没人触发我不会醒。<br>所以落法拆成两级：<b>① 立刻能给你的</b>：管道接通 + 页面上写死"数据截止到哪天、旧了几天"，旧了就自己变红，你一眼知道能不能用；<b>② 真正的每天</b>：挂在每天那一次整理动作上（跟记忆库整理、规则导出同一趟），哪天没跑页面上就写"沿用某天"。<br>⚠️ 一处代价你要知道：<b>重新部署之后是新地址，你的书签要换一次</b>（旧的还能开，但不再更新）。换地址那一下我会在私聊里把新链接直接给你。',
      settled: 1 },
    { t: '七条策略动作怎么重写 —— ⚠️ 我原来那个提法已经被你 21:40 那句话推翻了',
      why: '我原来的判断是"问题不在结论对不对，在没写今天下班前该完成什么"，所以想改成三段式。<b>你 21:40 的回答是「结论本身我不认，重做证据链」—— 我判错了方向</b>：不是排版问题，是我下判断的方式太薄。',
      need: '所以这一行现在等的不是"要不要改版式"，而是<b>四层证据标准你认不认</b>（在业务基本盘那一页，四层每层都能点"我认 / 要改"）。标准不点头，我重写出来的还是我一个人的理解。',
      out: '标准定了之后我按它重写：<b>条数大概率会变少</b>（原七条里够格当结论的只有 ▇▇条），但每条都带得出四层出处。',
      lose: '那七条会一直挂着"待验证"的牌子 —— 挂着不算错，但你也用不上。',
      go: 'base', gosel: 'ownask' }
  ];

  /* ── ②之一 已经放行的（原来在 ASK 里，你 09-16 定掉了）──────
     规矩：定了的事不许再问第二遍，但也不许悄悄消失 ——
     它从"要你点头"挪到这里，落法写清楚，你随时能回头核。 */
  const SETTLED = [
    { t: '自动写一篇本周复盘存进你的仓库', when: '2026-09-16（23:05 你又确认了一次「就这么做」）',
      re: '你 23:05 在等你拍板的事项上把这一行也点成了<b>「就这么做」</b> —— 等于把整件事从"机制放行"确认到了"内容也照这个写法出"。合起来现在的落法是：<b>每周二 · 先读 ▇▇个底仓 · 七段结构（含近 ▇▇ 天两个案例）· 写完存进你仓库 · 飞书私聊推 ▇▇行 + 链接</b>；而 <b>09-22 那篇按你 22:27 的话当草稿</b>，你改完才定稿入档。',
      said: '「我需要你每周二写一篇本周复盘汇总，你可以读取业务盘里的底仓链接，拿到最新数据反馈，并提醒我查阅」',
      did: '原来我提的是每周五，<b>按你的话改成每周二</b>；不只写结论，要先去读业务盘那 ▇▇个底仓拿最新数，写完提醒你查阅。<b>▇▇-16 21:▇▇ 你又把最后一个卡点定了：提醒方式＝我直接飞书私聊推给你（▇▇行摘要 + 链接），这等于你允许我主动发消息。</b>落法全部写在下面「每周二复盘」那一块里。',
      go: '@.wk' }
  ];

  /* ── ③ 我绝不自己决定的 ────────────────────────────── */
  const STOP = [
    ['涉及口径、分母、分层判定的', '换一次口径，后面所有结论的参照都变了 —— 这类我一律停下来问你'],
    ['我做了推断但没有证据的', '一律进待复核队列，标清缺哪个字段，绝不排版成结论摆给你'],
    ['你立过的规矩和新要求打架的', '不替你选，两条一起摆出来让你裁（例：solution-deck-builder 装不装 —— 09-13 你说"策划工作台已有、不装"，09-25 你又明确说"装"，我把两条都摆出来后按你 09-25 的确认装上）'],
    ['要往你本地仓库写新文件的', '写之前先说要写哪一篇、写什么，你说行我才写']
  ];

  function mineBox() {
    const land = MINE.filter(m => m.her).length;
    return `<div class="ownmine" data-mod="m-ownmine" id="ownmine">
      <div class="own__hd">
        <span class="own__tag">自行推进事项</span>
        <em>${MINE.length} 件。都是我看完全站运行情况自己挑的，<b>不用你点头</b> —— 判定标准：不动你的文件、不花你的时间、不改口径。
        <b>你 09-16 已经对其中 ${land} 件给了落法</b>，下面每件都带一行「你怎么说的 / 我改了什么」。</em>
      </div>
      <div class="ownmine__l">${MINE.map((m, i) => `<div class="ownmine__i${m.done ? ' is-done' : ''}${m.her ? ' is-land' : ''}">
        <div class="ownmine__h"><i>${String(i + 1).padStart(2, '0')}</i><b>${m.job}</b></div>
        ${m.her ? `<div class="ownlnd">
          <div class="ownlnd__h"><span>你 ${m.herAt} 的落法</span><b>${m.her}</b></div>
          ${m.herSaid ? `<p class="ownlnd__q">${m.herSaid}</p>` : ''}
          ${m.chg ? `<p class="ownlnd__c"><span>我照这个改了什么</span>${m.chg}</p>` : ''}
          ${m.done ? `<p class="ownlnd__d"><span>已经做完了</span>${m.done}
            ${m.goview ? `<a class="ownlnd__go" data-goview="${m.goview}" data-gosel="${m.gosel}" href="javascript:void 0">去看这件的产物 ↗</a>`
              : (m.goblk ? `<a class="ownlnd__go" data-goblk="${m.goblk}" href="javascript:void 0">去看这件的产物 ↗</a>` : '')}</p>` : ''}
        </div>` : ''}
        <p><span>我看到什么才领的</span>${m.see}</p>
        <p><span>我会用什么</span>${m.use}</p>
        <p class="ownmine__out"><span>做完你拿到什么</span>${m.out}</p>
        <div class="ownmine__f">
          <span class="ownmine__w">${m.when}</span>
          <span class="ownmine__s">这件不用问你：${m.safe}</span>
        </div>
      </div>`).join('')}</div>
      <p class="own__ft">这几件你都可以否 —— 说"这件别做"，我就撤，不解释也不追问。</p>
    </div>`;
  }

  function askBox() {
    const gone = ASK.filter(a => a.settled).length;
    const left = ASK.filter(a => !a.settled).length;
    return `<div class="ownask" data-mod="m-ownask" id="ownask">
      <div class="own__hd">
        <span class="own__tag">待授权后执行</span>
        <em>${ASK.length} 件。这几件<b>会动你的东西或要花你的资源</b>（用你登录态 / 改你定过的板块 / 换地址），所以我不自己动。
        <b>你 ▇▇-16 23:▇▇ 又解开了 ${gone} 件</b>（星图授权改成"需要时找你" · 数据管道照做），
        <b>真正还卡着的只剩 ${left} 件</b> —— 下面每件都标了状态，已解开的不再问你第二遍。</em>
      </div>
      <div class="ownask__l">${ASK.map(a => `<div class="ownask__i${a.hot ? ' is-hot' : ''}${a.settled ? ' is-gone' : ''}">
        <div class="ownask__t">${a.settled ? '<i class="ownask__ok">你已放行</i>' : (a.hot ? '<i>最值得先点头</i>' : '')}${a.t}</div>
        ${a.her ? `<div class="ownlnd">
          <div class="ownlnd__h"><span>你 ${a.herAt} 的落法</span><b>${a.her}</b></div>
          ${a.herSaid ? `<p class="ownlnd__q">${a.herSaid}</p>` : ''}
          ${a.chg ? `<p class="ownlnd__c"><span>我照这个改了什么</span>${a.chg}</p>` : ''}
        </div>` : ''}
        <p><span>我为什么想做</span>${a.why}</p>
        <p><span>${a.settled ? '原来为什么要先问你' : '为什么先问你'}</span>${a.need}</p>
        <p class="ownask__out"><span>做完你拿到什么</span>${a.out}</p>
        ${a.settled ? '' : `<p class="ownask__lose"><span>不点头会一直怎样</span>${a.lose}</p>`}
      </div>`).join('')}</div>
      ${SETTLED.map(s => `<div class="ownset">
        <div class="ownset__h"><span>你已经放行了</span><b>${s.t}</b><em>${s.when}</em></div>
        <p class="ownset__s"><span>你的原话</span>${s.said}</p>
        <p class="ownset__d"><span>我按这个落的</span>${s.did}</p>
        ${s.re ? `<p class="ownset__re"><span>你 23:05 又确认了一次</span>${s.re}</p>` : ''}
        <a class="ownset__go" data-goblk=".wk" href="javascript:void 0">看这件的完整落法 ↓</a>
      </div>`).join('')}
      <p class="own__ft">下面那张<b>等你逐条拍板的事项</b>就是给这 ▇▇件用的：一条一条给我落法，写完一次性发我。<b>现在 ▇▇ 有落法，还空着 ▇▇行</b>（▇▇ 那条不实用入口 · ▇▇ 每天 10:00 推送 · ▇▇ 七条策略怎么改 —— 其中 ▇▇ 的前提已经被你 21:40 那句话推翻了，我在那一行写了实话）。</p>
    </div>`;
  }

  function stopBox() {
    return `<div class="ownstop" data-mod="m-ownstop" id="ownstop">
      <div class="own__hd">
        <span class="own__tag">禁止自决事项</span>
        <em>${STOP.length} 类。这几类碰到就停 —— <b>我主动领活，不等于我可以替你拍板</b>。</em>
      </div>
      <ul class="ownstop__l">${STOP.map(s => `<li><b>${s[0]}</b><span>${s[1]}</span></li>`).join('')}</ul>
    </div>`;
  }

  /* ═══════════════════════════════════════════════════════
     等你逐条拍板的事项（2026-09-16 她的原话）
       「我逐条给反馈并确认动作，你给我一个可以反馈的窗口，我告诉你怎么落」

     所以这一块不是选择题，是**窗口**：
       · ▇▇件活一条一行，每行三个动作 + 一个"怎么落"的输入框；
       · 你写的字我一个不改地原样带走，落法按你的话走，不按我的默认；
       · 全部攒成**一条**反馈发出（同一个 topic 会覆盖，永远只占收件箱 ▇▇），
         所以你可以改主意、可以只填两条先发、回头再补。
     ⛔ 不做的事：不预设默认答案、不替你勾选、不因为你没填就当成同意。
     ═══════════════════════════════════════════════════════ */
  const GKEY = 'cec.gate.v1';
  const ACT = {
    go:   ['就这么做',   '按我写的落法直接开工'],
    hold: ['先别做',     '这件撤掉，我不做，也不再问你第二遍'],
    fix:  ['按我说的改', '思路对但落法要改 —— 你写的那句就是新落法']
  };

  const gEsc = s => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  /* ── 她 09-16 21:23 在对话里逐条给过的落法（▇▇）──
     规矩：定了的事不许再问第二遍。所以这 ▇▇行**默认就是已填状态**，
     她的原话原样带进输入框，她还能改（改了以本地记录为准）。
     ⛔ 不许把这 ▇▇行当成"我自己勾的" —— 每行都标"你 09-16 给的"。 */
  const LAND = {
    m0: { act: 'go',  txt: '', at: '▇▇-16 21:▇▇' },
    m1: { act: 'fix', txt: '你可以点做，但很有可能是已经有对接同学了，这个后面还要再排查，你可以先拎需求最多的前▇▇位', at: '▇▇-16 21:▇▇' },
    m2: { act: '',    txt: '周报的策略你需要调动业务底仓跟附带链接的资料进行分析交叉总结，同时结合本工作台已经调用的能力资料，进行业务的理解和商业模式拆解', at: '▇▇-16 21:▇▇' },
    m3: { act: 'go',  txt: '', at: '▇▇-16 21:▇▇' },
    m4: { act: 'go',  txt: '', at: '▇▇-16 21:▇▇' },
    /* ↓ 她 09-16 23:05 又给了 ▇▇条（▇▇ / ▇▇），这一批把"要你一句话"那栏解开了两件 */
    a0: { act: 'fix', txt: '就这么做，需要登录的时候，你可以触发对话给我，我来授权', at: '▇▇-16 23:▇▇' },
    a2: { act: 'go',  txt: '', at: '▇▇-16 23:▇▇' },
    s0: { act: 'go',  txt: '', at: '▇▇-16 23:▇▇' }
  };
  const LANDAT = '▇▇-16 21:▇▇ / 23:05';

  /* ▇▇行 = ▇▇件我自己领的 + ▇▇件要你点头 + ▇▇件你已放行（只读，不占你动作） */
  function rows() {
    const r = [];
    /* 每一行的提示都用这条活自己的话，不用套话 ——
       我自己领的那 ▇▇行写"做完你拿到什么 + 什么时候"，
       要你点头的那 ▇▇行写"你不点头会一直怎样 + 会动到你什么"。 */
    MINE.forEach((m, i) => r.push({
      k: 'm' + i, bucket: 'mine', tag: '我自己领的', t: m.job,
      hint: `<b>做完你拿到</b>：${m.out}　<b>什么时候</b>：${m.when}。默认我已经在做了，这一行你只在想撤或想改的时候才动。`
    }));
    ASK.forEach((a, i) => r.push({
      k: 'a' + i, bucket: 'ask', tag: a.settled ? '你已放行' : '要你一句话', t: a.t, hot: a.hot && !a.settled,
      hint: a.settled
        ? `<b>你 ${a.herAt} 已经放行了</b>（${a.her}）。这一行留在台上只为一件事：<b>你随时能改口径或撤回</b>；不改就不用动它。`
        : `<b>你不点头会一直这样</b>：${a.lose}　<b>要动到你什么</b>：${a.need}`
    }));
    SETTLED.forEach((s, i) => r.push({
      k: 's' + i, bucket: 'done', tag: '你已放行', t: s.t, lock: 1,
      hint: '09-16 你已经定了两件：① 改成每周二、先读底仓、写完提醒你；② <b>提醒方式＝我直接飞书私聊推给你（▇▇行摘要 + 链接）</b>。想改口径或改推送时间，直接在这一行写。'
    }));
    return r;
  }

  function gLoad() {
    try { return JSON.parse(localStorage.getItem(GKEY) || '{}') || {}; } catch (e) { return {}; }
  }
  function gSave(v) { try { localStorage.setItem(GKEY, JSON.stringify(v)); } catch (e) {} }

  /* 生效状态 = 她 09-16 给过的落法（底） + 她在页面上改过的（覆盖） */
  function gEff() {
    const st = gLoad(), out = {};
    Object.keys(LAND).forEach(k => { out[k] = { act: LAND[k].act, txt: LAND[k].txt, at: LAND[k].at, land: 1 }; });
    Object.keys(st).forEach(k => {
      out[k] = Object.assign({}, out[k], st[k]);
      if (st[k] && (st[k].act !== undefined || st[k].txt !== undefined)) out[k].edited = 1;
    });
    return out;
  }

  function gateBox() {
    const R = rows(), st = gEff();
    const has = x => st[x.k] && (st[x.k].act || (st[x.k].txt || '').trim());
    const filled = R.filter(has).length;
    const stuck  = R.filter(x => x.bucket === 'ask' && !(st[x.k] && st[x.k].act)).length;
    const noAct  = R.filter(x => st[x.k] && !st[x.k].act && (st[x.k].txt || '').trim()).length;
    return `<div class="gate" data-mod="m-gate" id="gate">
      <div class="own__hd">
        <span class="own__tag own__tag--act">等你逐条拍板的事项</span>
        <em>你说「我逐条给反馈并确认动作，给我一个可以反馈的窗口」—— 就是这里。
        <b>你 ${LANDAT} 已经给了 ${Object.keys(LAND).length} 条落法，我原样填在下面了</b>，不用你重填一遍；
        剩下的写多少条都行，最后<b>攒成一条发给我</b>（只占收件箱 ▇▇ 格，改主意会覆盖）。</em>
      </div>
      <div class="gate__bar">
        <span class="gate__cnt">已经给了落法 <b>${filled}</b> / ${R.length}</span>
        ${stuck ? `<span class="gate__stuck">还有 <b>${stuck}</b> 件真卡着不动（要你一句话那几件）</span>`
                : `<span class="gate__ok">要你点头那几件都有落法了</span>`}
        ${noAct ? `<span class="gate__half">有 <b>${noAct}</b> 件你只写了落法没选动作 —— 我按落法做，但没当成放行</span>` : ''}
        <button class="gate__quick" data-gq="mine">▇▇件我领的：全部照常做</button>
        <button class="gate__clr" data-gclr="▇▇">回到你原来给的落法</button>
      </div>
      <div class="gate__l">${R.map((x, i) => {
        const s = st[x.k] || {};
        const isLand = s.land && !s.edited;
        return `<div class="gate__i${s.act ? ' is-set is-' + s.act : ''}${x.hot ? ' is-hot' : ''}${x.lock ? ' is-lock' : ''}${isLand ? ' is-land' : ''}" data-gk="${x.k}">
          <div class="gate__h">
            <i class="gate__no">${String(i + 1).padStart(2, '0')}</i>
            <span class="gate__bk gate__bk--${x.bucket}">${x.tag}</span>
            <b class="gate__t">${x.t}</b>
            ${isLand ? `<span class="gate__lm">你 ${s.at || LANDAT} 给过</span>` : ''}
            ${s.edited ? '<span class="gate__lm gate__lm--e">你在这一页改过</span>' : ''}
          </div>
          <p class="gate__hint">${x.hint}</p>
          ${isLand && !s.act && (s.txt || '').trim()
            ? '<p class="gate__half1">⚠️ 这一行你<b>只写了落法、没选动作</b>：我按你写的落法执行，但不当成"放行"，动作那一格给你留白。</p>' : ''}
          <div class="gate__acts">${Object.keys(ACT).map(a => `<button class="gate__a${s.act === a ? ' is-on' : ''}"
            data-ga="${a}" data-gk="${x.k}" title="${ACT[a][1]}">${ACT[a][0]}</button>`).join('')}</div>
          <div class="gate__in">
            <textarea class="gate__tx" data-gk="${x.k}" rows="▇▇"
              placeholder="怎么落，写一句（例：这件先只跑机构那一半 / 换成先给我看再动 / 这件交给我自己来）">${gEsc(s.txt || '')}</textarea>
          </div>
        </div>`;
      }).join('')}</div>
      <div class="gate__ft">
        <button class="gate__send" data-gsend="▇▇">把这 ${R.length} 条的落法发给我</button>
        <span class="gate__note">发出去之后我按你写的字开工；<b>没填的那几行我一律当成"还没定"，不会擅自开始</b>。</span>
      </div>
    </div>`;
  }

  /* 攒成一条：topic 固定 gate-11，同 topic 覆盖不新增 → 永远只占收件箱 ▇▇ */
  function gSync(silent) {
    if (!(window.FB && FB.submit)) return;
    const R = rows(), st = gEff();
    const lines = R.map((x, i) => {
      const s = st[x.k] || {};
      if (!s.act && !(s.txt || '').trim()) return null;
      return `${String(i + 1).padStart(2, '0')} [${x.tag}] ${x.t}` +
             (s.edited ? '（你在页面上改过）' : (s.land ? `（你 ${s.at || LANDAT} 给过）` : '')) +
             `\n    → ${s.act ? ACT[s.act][0] : '（只写了落法，没选动作）'}` +
             ((s.txt || '').trim() ? `\n    → 她的落法：${s.txt.trim()}` : '');
    }).filter(Boolean);
    if (!lines.length) return;
    const it = FB.submit({
      kind: 'add', view: '协作机制与调用思考',
      topic: 'gate-11', topicName: `▇▇件活的逐条落法（${lines.length}/${R.length}）`,
      text: lines.join('\n')
    });
    if (!silent && it && FB.toast) FB.toast(`已收到 ${lines.length} 条落法（这一条会一直覆盖更新，不占新格子）`);
  }

  function gRepaint() {
    document.querySelectorAll('.gate').forEach(box => {
      const holder = box.parentElement; if (!holder) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = gateBox();
      holder.replaceChild(tmp.firstElementChild, box);
    });
  }

  function wire() {
    /* 跨页跳产物：先切到那一页，再滚到那一块（同页跳转仍走 sub.js 的 data-goblk）*/
    document.addEventListener('click', e => {
      const g = e.target.closest('.ownlnd__go[data-goview]');
      if (!g) return;
      e.preventDefault();
      const v = g.dataset.goview, sel = g.dataset.gosel;
      try { if (window.OS && OS.show) OS.show(v); } catch (err) {}
      setTimeout(() => {
        const t = document.getElementById(sel);
        if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 160);
    });

    /* 选动作 */
    document.addEventListener('click', e => {
      const a = e.target.closest('.gate__a');
      if (a) {
        const st = gLoad(), k = a.dataset.gk, cur = (gEff()[k] || {}).act;
        st[k] = st[k] || {};
        if (st[k].txt === undefined && LAND[k]) st[k].txt = LAND[k].txt;   /* 保住她原来那句话 */
        st[k].act = (cur === a.dataset.ga) ? '' : a.dataset.ga;   /* 再点一次 = 取消，含默认亮着的那几行 */
        gSave(st); gSync(1); gRepaint();
        return;
      }
      const q = e.target.closest('.gate__quick');
      if (q) {
        const st = gLoad();
        rows().filter(x => x.bucket === 'mine').forEach(x => {
          st[x.k] = Object.assign({}, st[x.k], { act: 'go' });
        });
        gSave(st); gSync(1); gRepaint();
        if (FB && FB.toast) FB.toast('▇▇件我领的都标成照常做了 —— 要撤哪件，把那一行改成「先别做」');
        return;
      }
      const c = e.target.closest('.gate__clr');
      if (c) { gSave({}); gRepaint(); if (FB && FB.toast) FB.toast('已回到你 09-16 给过的那 ▇▇条落法（你在这一页改的都撤了）'); return; }
      const s = e.target.closest('.gate__send');
      if (s) {
        const st = gEff(), R = rows();
        const n = R.filter(x => st[x.k] && (st[x.k].act || (st[x.k].txt || '').trim())).length;
        if (!n) { if (FB && FB.toast) FB.toast('还一条都没填 —— 先选个动作或写一句落法'); return; }
        gSync();
        if (FB && FB.open) FB.open();      /* 直接把收件箱掀开，她可以一键交办 */
        return;
      }
    });
    /* 写落法：只存不重绘（重绘会把光标弄丢，E 系列踩过这个坑） */
    document.addEventListener('input', e => {
      const tx = e.target.closest('.gate__tx');
      if (!tx) return;
      const st = gLoad(), k = tx.dataset.gk;
      st[k] = st[k] || {};
      if (st[k].act === undefined && LAND[k]) st[k].act = LAND[k].act;
      st[k].txt = tx.value;
      gSave(st);
      tx.style.height = 'auto'; tx.style.height = Math.min(tx.scrollHeight, 160) + 'px';
    });
    document.addEventListener('change', e => {
      if (e.target.closest('.gate__tx')) gSync(1);
    });
  }

  function render() { return mineBox() + askBox() + gateBox() + stopBox(); }

  /* mineBox / askBox / stopBox 也导出：09-16 23:32 之后这一页由 coop.js 按三段装配，
     这四块不再各自散着 —— stopBox 归段①（刹车），mine/ask/gate 归段②（运行明细）。 */
  return { render, wire, gateBox, mineBox, askBox, stopBox, MINE, ASK, SETTLED, STOP };
})();

(function () {
  const go = () => { try { OWN.wire(); } catch (e) { console.warn('own', e); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go);
  else go();
})();
