/* ═══════════════════════════════════════════════════════════
   os.js —— v8 外壳：四分区侧栏 + 视图路由 + Hero + 指令栏
   —— 参考你给的 TianyuOS 截图：左侧分组导航、主区顶部胶囊工具条、
      居中 wordmark + 三条认知主张 + 建议问句 + 状态条、底部指令输入。
   —— 铁律不变：
      ▇▇. 业务 / 业绩数字只出现在「业务工作区」这一组，其余三组一个数都不许沿用。
      ▇▇. 这一页永远不直接写磁盘，所有产物走「补丁」。
   —— 载入顺序：data → data2 → mind → tools → biz → charts → os → render
      （render.js 直接读 OS.SECS 来铺章节，所以 os.js 必须在它之前）
   ═══════════════════════════════════════════════════════════ */
window.OS = (function () {

  /* ── 四区 × ▇▇个二级模块（信息架构 v6，2026-09-24 本人放行）───────
     四区锁死定位（区级铁律，落地不许违反）：
       Ⅰ 驾驶舱全景 = 工作台运行状态与反馈  → ⛔ 不放具体业务数字
       Ⅱ 认知与学习 = 运行大脑与迭代能力源泉 → ⛔ 不复述具体业务信息，只放外部学习+思维迭代
       Ⅲ 高阶交互系统 = 「模块之间怎么协作 · 已定过的决策与待你拍板的事 · 系统自查」       → ⛔ 不呈现具体业务内容，只放调度/技能/自运行
       Ⅳ 业务工作区 = 具体业务信息与落地反馈 → 业绩金额只在此区，且必须体现自主判断+进阶思考
     旧 ▇▇ 模块中 ▇▇个保留 id（更换标题与定位），▇▇个「rules / supply」在此版下架于侧栏，
     其能力块由 v6.js 迁到新宿主（rules→premise / supply→plays），保底 ALIAS 兜死链。
     规范全文：/creator-ecosystem-console/memory/工作台模块规范.md */
  const NAV = [
    {
      k: 'ov', g: '驾驶舱全景', ic: '◎',
      d: '工作台运行状态与反馈；⛔ 不出现业务数字',
      items: [
        { id: 'm_over',   n: '▇▇', ic: '◉', t: '工作台业务模块总览',
          lbl: '模块健康度', q: '一屏看清 ▇▇ 区 ▇▇ 模块的健康度：每模块最近更新、五张固定信息卡（本页结论 / 数据来源 / 能力清单 / 可执行动作 / 待你拍板）是否填满、是否阻塞。<b>⛔ 不出现业务数字</b>。', ask: '' },
        { id: 'm_notice', n: '▇▇', ic: '★', t: '重要信息同步',
          lbl: '结论汇总', q: '全站最高置顶结论与警示（跨模块聚合的一句话陈述）。<b>数字替换成"变了 / 推翻 / 已旧"这类事件描述</b>。', ask: '' },
        { id: 'alert',    n: '▇▇', ic: '△', t: '今日更新动态总览',
          lbl: '系统本身动了什么', q: '跟昨天比系统本身动了哪里：记忆库变更 · 数据源新鲜度 · 模块动作足迹。<b>⛔ 不放业务数字</b>。', ask: '' },
        { id: 'deck',     n: '▇▇', ic: '▦', t: '自运行工作流进展',
          lbl: '任务在跑', q: '系统自动跑的东西现在到哪：11:00 刷新是否跑过 · 自巡访 · 待办工作流。<b>⛔ 不再显示今天/本周/本季业务数字</b>。', ask: '' },
        { id: 'm_pend',   n: '▇▇', ic: '⚑', t: '待反馈确认信息同步',
          lbl: '等你一句', q: '全站需要她一句话就能处理的事的镜像入口：等定 · 待补料 · 可采纳 · 可驳回。', ask: '' },
        { id: 'advice',   n: '▇▇', ic: '✦', t: '系统自运行优化建议',
          lbl: '驾驶舱层建议', q: '系统自查后推出的<b>驾驶舱层</b>建议（讲的是系统运行本身，不讲业务）。业务建议去外部大盘信息。', ask: '' },
        { id: 'fb_ov',    n: '▇▇', ic: '✎', t: '此模块优化反馈',
          lbl: '本区反馈入口', q: '「工作台运行状态」这一区专属反馈入口，反馈会自动进本区队列。', ask: '' }
      ]
    },
    {
      k: 'mind', g: '认知与学习', ic: '◐',
      d: '运行大脑与迭代能力源泉；⛔ 不复述具体业务信息',
      items: [
        { id: 'memory',   n: '▇▇', ic: '∞', t: '记忆库总目录总览',
          lbl: '记忆分册', q: '五册记忆 + 系统运作规则 + 模块协作规则 + 业务模块的分层总目录；每册最近版本、行数、云端镜像状态。<b>⛔ 不复述规则条文</b>。', ask: '' },
        { id: 'm_ext',    n: '▇▇', ic: '⇢', t: '外部思维原料与采纳建议',
          lbl: '向外看', q: '本区核心增量：外部书籍摘要 · 媒体资料 · 白皮书 · 跨业务案例，每条附"我学到什么、建议采纳为哪类规则/打法"。', ask: '' },
        { id: 'm_chg',    n: '▇▇', ic: '⧖', t: '今日记忆库更新动态',
          lbl: '今天记了什么', q: '今天记忆库改了哪条：新增 · 修订 · 降级 · 归档。<b>只做流水，不做推翻</b>。', ask: '' },
        { id: 'pattern',  n: '▇▇', ic: '◇', t: '用户每日思维模式动态',
          lbl: '你今天怎么想', q: '她今天的思维模式提示：最近决策风格 + 偏好漂移 + 今日易犯错提醒。<b>⛔ 不出现业务结论</b>。', ask: '' },
        { id: 'premise',  n: '▇▇', ic: '⟲', t: '待反馈确认信息及纠错同步',
          lbl: '哪条前提可能错', q: '被推翻的前提、降级为待验证的判断、她认下的判错；等她二次拍板的规则条。也承接原来「判断依据与业务口径」的内容。', ask: '' },
        { id: 'm_lrn',    n: '▇▇', ic: '⚙', t: '学习认知自运行优化建议',
          lbl: '规则与口径的漏洞', q: '系统自查判断规则与口径这一层的短板：哪条规则可能过期 · 概念定义不一致 · 哪些结论缺市场佐证。<b>⛔ 不给业务改法</b>。', ask: '' },
        { id: 'quick',    n: '▇▇', ic: '⚡', t: '新灵感捕捉与可采纳方向',
          lbl: '速记 · 采纳', q: '她的速记 → 系统归类 → 给可采纳方向。<b>⛔ 常用数据入口已经搬到「底仓数据能力」（编号 ▇▇）</b>。', ask: '' },
        { id: 'fb_mind',  n: '▇▇', ic: '✎', t: '此模块优化反馈',
          lbl: '本区反馈入口', q: '「认知与学习」这一区专属反馈入口，反馈会自动进本区队列。', ask: '' }
      ]
    },
    {
      k: 'sys', g: '高阶交互系统', ic: '◈',
      d: '模块之间怎么协作 · 已定过的决策与待你拍板的事 · 系统自查；⛔ 不呈现具体业务内容',
      items: [
        { id: 'state',    n: '▇▇', ic: '▤', t: '模块之间怎么协作总览',
          lbl: '模块之间怎么协作', q: '「输入 → 判断 → 调用 → 落地 → 回写」这 ▇▇步流转、模块之间实际的连接情况、数据从哪进来又回到哪、每个模块能干什么和不能干什么。<b>⛔ 不出现业务名词（客户/达人/机构）</b>。', ask: '' },
        { id: 'confirm',  n: '▇▇', ic: '⚑', t: '已定过的决策 · 待你拍板的事',
          lbl: '决策记录 · 等你拍板', q: '系统自己在跑什么、跑成什么样、跑完谁看：已定 · 正在跑 · 等你拍板 · 没照字面执行的说明。<b>⛔ 不放决策原文</b>。', ask: '' },
        { id: 'call',     n: '▇▇', ic: '⌗', t: '我能装的技能清单 · 常用指令模板',
          lbl: '可装技能 · 常用指令', q: '可装的技能清单（▇▇ 装/▇▇ 停/▇▇ 精选/▇▇ 高热）+ 常用指令模板 + 「还能怎么优化的建议清单」。<b>⛔ 不放业务结论</b>。', ask: '' },
        { id: 'cap',      n: '▇▇', ic: '⚙', t: '系统自查发现的问题 · 建议做法',
          lbl: '自查问题 · 建议做法', q: '系统自查发现的具体问题 + 建议做法 + 不建议引入的清单 + 前置追问。<b>可装技能清单已 ▇▇-23 22:▇▇ 搬到编号 ▇▇</b>。', ask: '' },
        { id: 'fb_sys',   n: '▇▇', ic: '✎', t: '此模块优化反馈',
          lbl: '本区反馈入口', q: '「高阶交互系统」这一区专属反馈入口，反馈会自动进本区队列。', ask: '' }
      ]
    },
    {
      k: 'biz', g: '业务工作区', ic: '▲',
      d: '业绩金额只在此区；必须体现自主判断+进阶思考',
      items: [
        { id: 'eco',     n: '▇▇', ic: '◉', t: '外部大盘信息',
          lbl: '外面在发生什么', q: '外部动态 · <b>跨部门资料获取渠道</b> · 机会挖掘 · 可拓机会 · <b>四赛道固定模块</b>（电商产业带/本地团购/渠道代理/短剧明星）· 主动建议 · 暂不可执行 · 数据截止。', ask: '' },
        { id: 'base',    n: '▇▇', ic: '▣', t: '目标与业绩达成',
          lbl: '业务助力自主判断', q: '季度业绩 · 分层专项 · 经营总判断 · 策略动作 · 缺口 · 待结算池。<b>先给判断再列数字</b>；业绩金额只在这一页。', ask: '' },
        { id: 'cust',    n: '▇▇', ic: '◍', t: '客户与商机需求',
          lbl: '外面要什么', q: '开放商机 · 可提报与缺表 · 点名 · 明星 · 客户诉求变化 · 授权类。<b>先给"今天先做哪几件、为什么"</b>。', ask: '' },
        { id: 'run',     n: '▇▇', ic: '➤', t: '周度策略回顾',
          lbl: '本周怎么打', q: '本周策略回顾五板块 · 每周二复盘 · 拜访快记 · 已入档纪要 · Q4 短剧名单等专项。含作战执行与节奏。', ask: '' },
        { id: 'plays',   n: '▇▇', ic: '◆', t: '策略资料库',
          lbl: '拿什么打', q: '可复用打法 · 高变现能力拆解 · 案例分析工作台 · <b>机构策略资料库 ▇▇块</b>（也承接原来「达人与机构供给」的内容）· 策略证据链。', ask: '' },
        { id: 'm_data',  n: '▇▇', ic: '▥', t: '底仓数据能力',
          lbl: '数据入口', q: '常用看板 · 每日更新时钟 · 业绩看板总览 · 数据底仓 · 数据口径 · 11:00 刷新规则 · IDA 日报看板。<b>⛔ 页面不呈现业绩数字</b>。', ask: '' },
        { id: 'm_brun',  n: '▇▇', ic: '➜', t: '自运行工作处理情况与反馈',
          lbl: '今天替她跑了什么', q: '业务助力今天替她跑了哪几件业务动作 + 每件的思考反馈与优化建议。<b>本区核心增量</b>。', ask: '' },
        { id: 'fb_biz',  n: '▇▇', ic: '✎', t: '此模块优化反馈',
          lbl: '本区反馈入口', q: '「业务工作区」这一区专属反馈入口，反馈会自动进本区队列。', ask: '' }
      ]
    }
  ];

  /* ── 遗留章节：v6 侧栏不显示，但 DOM 保留（能力块仍能渲染进旧宿主） ─────
     等 P2 迁移完成即可整体删除；参见 memory/工作台模块规范.md 附录 C。 */
  const LEGACY = [
    { id: 'rules',  t: '判断依据与业务口径（正在搬家，内容并入编号 ▇▇）',
      grp: 'mind', gt: '认知与学习', hidden: true,
      n: '·', ic: '⚖', d: '这一页正在搬家', q: '' },
    { id: 'supply', t: '达人与机构供给（正在搬家，内容并入编号 ▇▇）',
      grp: 'biz',  gt: '业务工作区', hidden: true,
      n: '·', ic: '☰', d: '这一页正在搬家', q: '' }
  ];

  /* 旧入口保留跳转，不留死链：老 id 一律映射到 v6 的新归属 */
  const ALIAS = {
    /* v5 → v5 老映射保留（rul 是老 id，与 rules 不同） */
    evo: 'cap', mech: 'state', spark: 'eco',
    cust0: 'cust', hqn: 'supply', mind: 'pattern', rul: 'rules',
    /* v6 新映射：老 nav 侧栏 id 或旧 URL fragment 兜死链 */
    hub: 'call', cmds: 'call', run5: 'run', plays5: 'plays'
  };

  const SECS = NAV.flatMap(g => g.items.map(i => Object.assign({ grp: g.k, gt: g.g }, i)))
    .concat(LEGACY);
  const BY = Object.fromEntries(SECS.map(s => [s.id, s]));
  const KV = 'cec.os.view', KG = 'cec.os.folded';

  let cur = 'deck';
  let folded = {};
  try { folded = JSON.parse(localStorage.getItem(KG) || '{}'); } catch (e) { folded = {}; }

  /* ── 侧栏 ───────────────────────────── */
  function renderNav() {
    const host = document.getElementById('osnav');
    if (!host) return;
    host.innerHTML = NAV.map(g => `
      <div class="osg${folded[g.k] ? ' is-fold' : ''}" data-grp="${g.k}">
        <button class="osg__h" data-gtog="${g.k}">
          <span class="osg__t">${g.g}</span>
          <span class="osg__c">${g.items.length}</span>
          <i class="osg__x">⌄</i>
        </button>
        <div class="osg__d">${g.d}</div>
        <ul class="osg__l">
          ${g.items.map(i => `<li>
            <a class="osi" href="#${i.id}" data-view="${i.id}">
              <span class="osi__ic">${i.ic}</span>
              <span class="osi__t">${i.t}</span>
              <span class="osi__b" data-badge="${i.id}"></span>
            </a></li>`).join('')}
        </ul>
      </div>`).join('');

    host.addEventListener('click', e => {
      const tog = e.target.closest('[data-gtog]');
      if (tog) {
        const k = tog.dataset.gtog;
        folded[k] = !folded[k];
        localStorage.setItem(KG, JSON.stringify(folded));
        tog.closest('.osg').classList.toggle('is-fold', !!folded[k]);
        return;
      }
      const a = e.target.closest('[data-view]');
      if (!a) return;
      e.preventDefault();
      show(a.dataset.view);
    });
  }

  /* ── 视图切换 ───────────────────────── */
  function show(id, opt) {
    id = ALIAS[id] || id;
    if (!BY[id]) return;
    cur = id;
    const g = BY[id];
    document.body.dataset.view = id;
    document.body.dataset.grp = g.grp;

    /* 全局「一句话让 Aime 帮忙」只在工作台模块总览出现；
       进入具体模块后直接看该模块内容，避免每页都被同一个搜索框占满首屏。 */
    const askbox = document.getElementById('askbox');
    if (askbox) askbox.hidden = id !== 'm_over';

    document.querySelectorAll('.sec').forEach(s => s.classList.toggle('is-view', s.id === id));
    document.querySelectorAll('.osi').forEach(a => a.classList.toggle('is-on', a.dataset.view === id));
    document.querySelectorAll('.osg').forEach(x =>
      x.classList.toggle('is-here', x.dataset.grp === g.grp));

    const w = document.getElementById('where');
    if (w) w.innerHTML = `<span class="where__g">${g.gt}</span><b>${g.t}</b>`;

    /* Hero 只在驾驶舱首页露脸，其余视图让位给内容 */
    document.body.classList.toggle('hero-on', id === 'deck');

    localStorage.setItem(KV, id);
    if (!opt || !opt.silent) history.replaceState(null, '', '#' + id);
    if (!opt || !opt.noscroll) window.scrollTo({ top: 0, behavior: opt && opt.instant ? 'auto' : 'smooth' });

    /* 隐藏容器宽高为 ▇▇，图必须切过来之后再画 / 再 resize */
    setTimeout(() => {
      window.CEC_CHARTS && CEC_CHARTS.resizeAll && CEC_CHARTS.resizeAll();
      window.MIND && MIND.chart && MIND.chart();
    }, 90);
  }

  /* 给任意元素 id 找到它所在的视图，用于命令面板 / 依据跳转 */
  function viewOf(el) {
    const sec = el && el.closest ? el.closest('.sec') : null;
    return sec ? sec.id : null;
  }
  function reveal(id) {
    if (ALIAS[id] && !document.getElementById(id)) { show(ALIAS[id], { noscroll: 1 }); return null; }
    const el = document.getElementById(id);
    if (!el) return null;
    const v = viewOf(el) || (BY[id] ? id : null);
    if (v && v !== cur) show(v, { noscroll: 1 });
    return el;
  }

  /* ── Hero ──────────────────────────── */
  const CLAIMS = [
    { ic: '◇', t: '发现你的思维模式', to: 'pattern' },
    { ic: '∞', t: '构建长期记忆',     to: 'memory' },
    { ic: '⟲', t: '寻找问题背后的前提', to: 'premise' }
  ];
  const ASKS = [
    { t: '我最近的主要思维模式是什么？', to: 'pattern' },
    { t: '帮我分析这个问题的根本原因',   to: 'premise' },
    { t: '现在最该先处理哪件事？',       to: 'confirm' }
  ];

  /* 页面上真正等她拍板的条数 = ASKS 里还没答过的（和右上角反馈抽屉口径一致） */
  function pendAsk() {
    const all = window.ASKS || [];
    if (!all.length) return 0;
    if (!window.FB || !FB.answerOf) return all.length;
    return all.filter(a => !FB.answerOf(a.id)).length;
  }

  function renderHero() {
    const box = document.getElementById('hero');
    if (!box || typeof DATA === 'undefined') return;
    const F = (window.MIND && MIND.FACT) || {};
    const q = DATA.queue || {};
    const stats = [
      { c: 'a', k: '当前主题',   v: '经营判断',                 s: '' },
      { c: 'b', k: '等你定',     v: pendAsk() + ' 件', s: (q.hot || 0) + ' 件卡着别的事 · 仓库里另挂 ' + (q.open != null ? q.open : '—') + ' 条低优先' },
      { c: 'c', k: '长期记忆',   v: (F.rules || 62) + ' 条规则',  s: (F.cal || 35) + ' 条口径' },
      { c: 'd', k: '仓库体量',   v: VN() + ' 篇笔记',  s: VL() + ' 行 / ' + VD() + ' 个目录' },
      { c: 'e', k: '数据截止',   v: DATA.meta.stamp,             s: '本地实测' }
    ];
    box.innerHTML = `
      <div class="hero__mark">达人生态 <span>OS</span></div>
      <div class="hero__sub">认 知 操 作 系 统</div>
      <div class="hero__claims">
        ${CLAIMS.map(c => `<button class="hclaim" data-jumpv="${c.to}">
          <i class="hclaim__ic">${c.ic}</i><span>${c.t}</span></button>`).join('')}
      </div>
      <div class="hero__asks">
        ${ASKS.map(a => `<button class="hask" data-jumpv="${a.to}">
          <i class="hask__ic">♡</i><span>${a.t}</span><b class="hask__go">→</b></button>`).join('')}
      </div>
      <div class="hero__stats">
        ${stats.map(s => `<div class="hstat">
          <i class="hstat__ic hstat__ic--${s.c}"></i>
          <div><div class="hstat__k">${s.k}</div>
          <div class="hstat__v">${s.v}${s.s ? `<small>${s.s}</small>` : ''}</div></div>
        </div>`).join('')}
      </div>
      <div class="hero__blk" id="mastBlock"></div>`;
  }

  /* ── 底部指令栏 ─────────────────────── */
  function wireCmd() {
    const inp = document.getElementById('cmdIn');
    if (!inp) return;
    let mode = 'idea';   // idea | todo
    document.querySelectorAll('[data-cmode]').forEach(b => b.addEventListener('click', () => {
      mode = b.dataset.cmode;
      document.querySelectorAll('[data-cmode]').forEach(x => x.classList.toggle('is-on', x === b));
      inp.placeholder = mode === 'idea'
        ? '随手记一句：看到什么现象 / 想到什么玩法 / 谁可能有需求…（Enter 进灵感库）'
        : '写一件要做的事…（Enter 进行动队列）';
      inp.focus();
    }));

    const send = () => {
      const v = inp.value.trim();
      if (!v) return;
      if (v[0] === '/' || v[0] === '？' || v[0] === '?') {
        inp.value = '';
        const pal = document.getElementById('palIn');
        document.getElementById('palBtn').click();
        if (pal) { pal.value = v.slice(1); pal.dispatchEvent(new Event('input')); }
        return;
      }
      /* 本批满 ▇▇条会被拦下：拦下就不清空输入框，她的这句话不能丢 */
      const ok = mode === 'idea'
        ? FB.submit({ kind: 'idea', view: (BY[cur] || {}).t || '', topic: '随手记 · ' + v.slice(0, 12), topicName: '随手记一句', text: v })
        : FB.submit({ kind: 'todo', view: (BY[cur] || {}).t || '', topic: '派个活 · ' + v.slice(0, 12), topicName: '你派给我的活', text: v });
      if (!ok) return;
      if (mode === 'idea') TOOLS.addIdea(v, 'trend'); else TOOLS.addQ(v, '指令栏');
      inp.value = '';
    };
    document.getElementById('cmdGo').addEventListener('click', send);
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
    });
  }

  /* ── 侧栏角标：哪个视图里还有没裁的闸门 / 空缺 ── */
  function badges() {
    SECS.forEach(s => {
      const sec = document.getElementById(s.id);
      const b = document.querySelector(`[data-badge="${s.id}"]`);
      if (!sec || !b) return;
      const gates = [...sec.querySelectorAll('.gate')].filter(g => !g.querySelector('.opt.is-on')).length;
      const gaps = sec.querySelectorAll('[data-gap="▇▇"]').length;
      if (gates) { b.textContent = gates; b.className = 'osi__b is-hot'; }
      else if (gaps) { b.textContent = gaps; b.className = 'osi__b is-gap'; }
      else { b.textContent = ''; b.className = 'osi__b'; }
    });
    /* 「重要事项确认」这一格由反馈系统接管：显示还剩几件没定 */
    if (window.FB) FB.paint();
  }

  function boot() {
    renderNav();
    renderHero();
    wireCmd();

    /* 任意地方的 data-jumpv 都能切视图 */
    document.addEventListener('click', e => {
      const b = e.target.closest('[data-jumpv]');
      if (!b) return;
      e.preventDefault();
      show(b.dataset.jumpv);
    });

    if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
    const h0 = (location.hash || '').replace('#', '');
    const h = ALIAS[h0] || h0;
    const kv0 = localStorage.getItem(KV);
    const kv = ALIAS[kv0] || kv0;
    const start = BY[h] ? h : (BY[kv] ? kv : 'deck');
    show(start, { instant: 1, noscroll: 1 });
    /* 章节先插进 DOM、Hero 后插在它上面，浏览器的 scroll anchoring 会把视口往下顶，
       这里强制回到顶部，否则一进来就是半截 */
    window.scrollTo(0, 0);
    requestAnimationFrame(() => window.scrollTo(0, 0));
    badges();

    /* 侧栏折叠 / 展开 */
    const t = document.getElementById('osFold');
    if (t) t.addEventListener('click', () => {
      document.body.classList.toggle('nav-off');
      setTimeout(() => window.CEC_CHARTS && CEC_CHARTS.resizeAll && CEC_CHARTS.resizeAll(), 240);
    });

    /* 数字键 1-9 直接跳视图（不在输入框里时） */
    document.addEventListener('keydown', e => {
      if (/^(INPUT|TEXTAREA)$/.test(e.target.tagName) || e.target.isContentEditable) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const i = '▇▇'.indexOf(e.key);
      if (i >= 0 && SECS[i]) show(SECS[i].id);
    });
  }

  return { NAV, SECS, BY, ALIAS, show, reveal, viewOf, boot, badges, renderHero, cur: () => cur };
})();
