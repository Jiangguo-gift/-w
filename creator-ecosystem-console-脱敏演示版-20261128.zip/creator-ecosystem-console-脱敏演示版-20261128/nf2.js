/* ═══════════════════════════════════════════════════════════
   nf2.js —— 全景动态看板渲染引擎（HTML+CSS 复刻 + SVG 动态连线）
   依赖：nf2.data.js（window.NF2 数据常量）
   ═══════════════════════════════════════════════════════════ */
(function () {
  const D = window.NF2;
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  /* ---------- 片段渲染 ---------- */
  function cardHTML(c) {
    const z = D.ZONES.find(z => z.id === c.zone);
    const v21 = c.v21.map(t => `<li>${esc(t)}</li>`).join('');
    const v2 = c.bullets.map(t => `<li>${esc(t)}</li>`).join('');
    return `
    <div class="nf2-card nf2-card--${c.zone}" data-node="${c.node}" style="--zc:${z.main};--zd:${z.deep};--zbox:${z.boxFill};--zstroke:${z.boxStroke}">
      <div class="nf2-card__head">
        <span class="nf2-card__no">${c.no}</span>
        <span class="nf2-card__title">${esc(c.title)}</span>
        <span class="nf2-card__badge nf2-card__badge--${c.badgeKind}">${esc(c.badge)}</span>
      </div>
      <div class="nf2-card__panel nf2-card__panel--v21">
        <div class="nf2-card__ptag">v2.1 核心业务</div>
        <ul>${v21}</ul>
      </div>
      <div class="nf2-card__panel nf2-card__panel--v2">
        <div class="nf2-card__ptag">v2 职责说明</div>
        <ul>${v2}</ul>
      </div>
      <div class="nf2-card__landing">${esc(c.landing)}${c.landing2 ? `<br>${esc(c.landing2)}` : ''}</div>
      <div class="nf2-card__principle">💡 ${esc(c.principle)}</div>
      <div class="nf2-card__chips" data-chips="${c.node}"></div>
    </div>`;
  }

  function columnHTML(z) {
    const cards = D.CARDS.filter(c => c.zone === z.id).map(cardHTML).join('');
    const asset = D.ASSETS.find(a => a.zone === z.id);
    const assetItems = asset.items.map(t => `<li>${esc(t)}</li>`).join('');
    return `
    <section class="nf2-col" style="--zc:${z.main};--zd:${z.deep};--zhf:${z.headFill};--zhs:${z.headStroke};--zht:${z.headTxt};--zsf:${z.subFill};--zss:${z.subStroke};--zst:${z.subTxt};--zbox:${z.boxFill};--zstroke:${z.boxStroke}">
      <header class="nf2-col__head">
        <h4>${esc(z.title)}</h4>
        <div class="nf2-col__redline">${esc(z.redline)}</div>
      </header>
      <div class="nf2-col__cards">${cards}</div>
      <div class="nf2-asset" data-node="a-${z.id}">
        <div class="nf2-asset__title">${esc(asset.title)}</div>
        <ul>${assetItems}</ul>
      </div>
    </section>`;
  }

  function boardHTML() {
    const cockpitCards = D.COCKPIT.cards.map(k =>
      `<div class="nf2-cockpit__card"><b>${esc(k.name)}</b><span>${esc(k.desc)}</span></div>`).join('');
    const pills = D.PILLS.map(p =>
      `<button class="nf2-pill" data-flow="${p.flow}" style="--pc:${D.COLOR_OF[p.flow]}">${p.flow} ${esc(p.label)}</button>`).join('');
    const filterBtns = D.TYPES.map(t =>
      `<button class="nf2-filter" data-type="${t.id}" style="--tc:${t.color}">${esc(t.name)}<i>${t.flows.join(' / ')}</i></button>`).join('');
    const rows = Object.keys(D.FLOWS).map(f => {
      const t = D.TYPES.find(t => t.flows.includes(f));
      return `<tr class="nf2-frow" data-flow="${f}" style="--rc:${t.color}">
        <td><span class="nf2-frow__id">${f}</span></td><td>${esc(D.FLOWS[f])}</td></tr>`;
    }).join('');
    const legend = D.LEGEND.map(([c, t]) => `<span><i style="background:${c}"></i>${esc(t)}</span>`).join('');
    const roles = D.ROLES.map(([c, t]) => `<span><i style="background:${c}"></i>${esc(t)}</span>`).join('');
    const channels = D.CHANNELS.map(ch =>
      `<div class="nf2-channel" style="--cc:${ch.color};--cbg:${ch.bg}">
        <span class="nf2-channel__tag">${ch.flows.join(' / ')}</span>${esc(ch.text)}</div>`).join('');
    const loopLabels = D.LOOP_LABELS.map(t => `<span class="nf2-looplabel">${esc(t)}</span>`).join('');
    const notes = D.FOOT_NOTES.map(t => `<li>${esc(t)}</li>`).join('');

    return `
<div class="nfb nf2" id="netflow-board" data-ver="${D.SYNC.ver}">
  <div class="nf2-sync">
    <div class="nf2-sync__meta">
      <b>模块协作全景动态看板 · ${D.SYNC.ver}</b>
      <span>数据源：${esc(D.SYNC.source)}｜更新：${D.SYNC.date}</span>
    </div>
    <div class="nf2-sync__rule">🔄 ${esc(D.SYNC.rule)}</div>
    <div class="nf2-toolbar">
      <div class="nf2-filters">${filterBtns}<button class="nf2-filter nf2-filter--all" data-type="__all">全部 ▇▇ 流</button></div>
      <div class="nf2-toolbar__btns">
        <button class="nf2-btn" id="nf2-tour">▶ 脉冲巡览</button>
        <button class="nf2-btn" id="nf2-reset">重置高亮</button>
      </div>
    </div>
  </div>

  <div class="nf2-stage" id="nf2-stage">
    <h2 class="nf2-title">销售第二大脑 · 跨区协同调用全景图（v2.1）</h2>
    <p class="nf2-subtitle">▇▇条跨区调用流：大脑输出判断能力 · 业务反哺学习原料 · 血管全链调度 · 总台只收系统元信息　|　模块卡双层：v2.1 核心业务原文保留 + v2 职责说明融合</p>

    <div class="nf2-pills">${pills}</div>

    <div class="nf2-cockpit" data-node="cockpit">
      <div class="nf2-cockpit__head">
        <h3>${esc(D.COCKPIT.title)}</h3>
        <div class="nf2-cockpit__desc">${esc(D.COCKPIT.desc)}</div>
        <div class="nf2-cockpit__redline">${esc(D.COCKPIT.redline)}</div>
      </div>
      <div class="nf2-cockpit__cards">${cockpitCards}</div>
    </div>

    <div class="nf2-cols">
      ${D.ZONES.map(columnHTML).join('')}
    </div>

    <svg class="nf2-svg" id="nf2-svg" viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-hidden="true"></svg>
    <div class="nf2-badges" id="nf2-badges"></div>

    <div class="nf2-loop">${loopLabels}</div>
    <div class="nf2-channels">${channels}</div>
  </div>

  <div class="nf2-legend">
    <div class="nf2-legend__group">${legend}</div>
    <div class="nf2-legend__group">${roles}</div>
  </div>

  <div class="nf2-flowtable">
    <h4>▇▇条跨区调用流编号对照（点击任一行联动高亮图中连线）</h4>
    <table><tbody>${rows}</tbody></table>
  </div>

  <ul class="nf2-footnotes">${notes}</ul>
</div>`;
  }

  /* ---------- SVG 动态连线引擎 ---------- */
  let state = { flow: null, type: null, touring: false, tourTimer: null, tourIdx: 0 };

  function isFlowVisible(f) {
    if (state.type) return D.TYPES.find(t => t.id === state.type).flows.includes(f);
    return true;
  }

  function draw(svg, stage) {
    const sr = stage.getBoundingClientRect();
    /* 隐藏视图（display:none）下宽高为 ▇▇，坐标会算出 NaN；跳过，等 ResizeObserver 在显示时重绘 */
    if (!sr.width || !sr.height) return;
    const pos = id => {
      const el = stage.querySelector(`[data-node="${id}"]`);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return {
        l: (r.left - sr.left) / sr.width * 1000,
        r: (r.right - sr.left) / sr.width * 1000,
        t: (r.top - sr.top) / sr.height * 1000,
        b: (r.bottom - sr.top) / sr.height * 1000,
        cx: (r.left + r.width / 2 - sr.left) / sr.width * 1000,
        cy: (r.top + r.height / 2 - sr.top) / sr.height * 1000,
        w: r.width / sr.width * 1000, h: r.height / sr.height * 1000
      };
    };

    /* 列间隙：顶部上报/回喂线的垂直通道，避免压住分区头文字 */
    const colEls = stage.querySelectorAll('.nf2-col');
    const colRects = [...colEls].map(el => {
      const r = el.getBoundingClientRect();
      return { l: (r.left - sr.left) / sr.width * 1000, r: (r.right - sr.left) / sr.width * 1000 };
    });
    const gapL = colRects.length >= 2 ? (colRects[0].r + colRects[1].l) / 2 : 333;
    const gapR = colRects.length >= 3 ? (colRects[1].r + colRects[2].l) / 2 : 666;
    const cockpit = pos('cockpit');
    const yChannel = cockpit ? cockpit.b + 7 : 200;
    const chanEl = stage.querySelector('.nf2-channels');
    const chanTop = chanEl ? (chanEl.getBoundingClientRect().top - sr.top) / sr.height * 1000 : 900;

    const paths = [], badgeHTML = [];
    D.LINKS.forEach((lk, i) => {
      const color = D.COLOR_OF[lk.flow];
      const a = pos(lk.from), b = pos(lk.to);
      if (!a || !b) return;
      let d = '', mx = 0, my = 0, withBadge = true;
      const laneOff = (lk.lane === 2 ? 26 : lk.lane === 1 ? -26 : 0);

      if (lk.kind === 'card') {
        if (lk.dir === 'right') {
          const y1 = a.cy + laneOff, y2 = b.cy + laneOff;
          const dx = Math.max(40, (b.l - a.r) * 0.5);
          d = `M ${a.r} ${y1} C ${a.r + dx} ${y1}, ${b.l - dx} ${y2}, ${b.l} ${y2}`;
          mx = (a.r + b.l) / 2; my = (y1 + y2) / 2;
        } else {
          const y1 = a.cy + laneOff, y2 = b.cy + laneOff;
          const dx = Math.max(40, (a.l - b.r) * 0.5);
          d = `M ${a.l} ${y1} C ${a.l - dx} ${y1}, ${b.r + dx} ${y2}, ${b.r} ${y2}`;
          mx = (a.l + b.r) / 2; my = (y1 + y2) / 2;
        }
      } else if (lk.kind === 'top') {
        /* 折线路由：卡顶 → 水平贴卡顶进列间隙 → 垂直穿列头区 → 驾驶舱下水平通道 → 入舱 */
        let channelX, x1, y1, x2, y2;
        if (lk.flow === 'C12') {
          channelX = gapL + 7;
          x1 = cockpit.l + 40; y1 = cockpit.b; x2 = b.cx; y2 = b.t;
          d = `M ${x1} ${y1} V ${yChannel} H ${channelX} V ${y2} H ${x2}`;
        } else if (lk.flow === 'C13') {
          channelX = gapR + 7;
          x1 = cockpit.cx; y1 = cockpit.b; x2 = b.cx; y2 = b.t;
          d = `M ${x1} ${y1} V ${yChannel} H ${channelX} V ${y2} H ${x2}`;
        } else {
          if (lk.from === 'n02') channelX = gapL - 7;
          else if (lk.from === 'n03') channelX = gapR - 7;
          else channelX = 952;
          x1 = a.cx; y1 = a.t;
          x2 = lk.from === 'n02' ? cockpit.l + 70 : lk.from === 'n05' ? cockpit.r - 70 : cockpit.cx;
          y2 = cockpit.b;
          d = `M ${x1} ${y1} H ${channelX} V ${yChannel} H ${x2} V ${y2}`;
        }
        mx = channelX; my = (yChannel + (lk.from === 'cockpit' ? y2 : y1)) / 2;
      } else {
        /* 底部：资产盒 → 下方双通道条的垂直短桩（流向由通道条颜色与编号表达） */
        const off = lk.flow === 'C01' || lk.flow === 'C03' ? -18 : 18;
        const x = a.cx + off;
        d = `M ${x} ${a.b} V ${chanTop + 3}`;
        withBadge = false;
      }

      const visible = isFlowVisible(lk.flow);
      const active = !state.flow || state.flow === lk.flow;
      const cls = `nf2-edge${visible ? '' : ' is-hide'}${active ? '' : ' is-dim'}${state.flow === lk.flow ? ' is-on' : ''}`;
      paths.push(`<path class="${cls}" data-flow="${lk.flow}" d="${d}" fill="none" stroke="${color}"
         stroke-width="${state.flow === lk.flow ? 3.2 : 2}" vector-effect="non-scaling-stroke"
         stroke-dasharray="${lk.kind === 'top' ? '7 6' : lk.kind === 'bottom' ? '2 0' : '8 6'}"
         marker-end="url(#nf2-arrow-${lk.flow}-${i})"/>`);
      paths.push(`<defs><marker id="nf2-arrow-${lk.flow}-${i}" markerWidth="9" markerHeight="9" refX="7" refY="4.5" orient="auto">
         <path d="M0,0 L9,4.5 L0,9 Z" fill="${color}"/></marker></defs>`);
      if (visible && withBadge) {
        badgeHTML.push(`<button type="button" class="nf2-ebadge${state.flow === lk.flow ? ' is-on' : ''}"
          data-flow="${lk.flow}" style="left:${mx / 10}%;top:${my / 10}%;--bc:${color}" title="${lk.flow}">
          <span>${lk.flow.slice(1)}</span></button>`);
      }
    });
    svg.innerHTML = paths.join('');
    const badgeLayer = stage.querySelector('#nf2-badges');
    if (badgeLayer) badgeLayer.innerHTML = badgeHTML.join('');
  }

  /* ---------- 高亮联动 ---------- */
  function relatedNodes(flow) {
    const s = new Set();
    D.LINKS.filter(l => l.flow === flow).forEach(l => { s.add(l.from); s.add(l.to); });
    return s;
  }

  function apply() {
    const root = document.getElementById('netflow-board');
    if (!root) return;
    root.querySelectorAll('.nf2-edge').forEach(el => {
      el.classList.toggle('is-hide', !isFlowVisible(el.dataset.flow));
      el.classList.toggle('is-dim', !!state.flow && el.dataset.flow !== state.flow);
      el.classList.toggle('is-on', state.flow === el.dataset.flow);
    });
    root.querySelectorAll('.nf2-ebadge').forEach(el => {
      el.classList.toggle('is-on', state.flow === el.dataset.flow);
      el.style.display = isFlowVisible(el.dataset.flow) ? '' : 'none';
    });
    root.querySelectorAll('.nf2-frow').forEach(el =>
      el.classList.toggle('is-active', state.flow === el.dataset.flow));
    root.querySelectorAll('.nf2-pill').forEach(el =>
      el.classList.toggle('is-on', state.flow === el.dataset.flow));
    root.querySelectorAll('.nf2-card').forEach(el => {
      const on = state.flow ? relatedNodes(state.flow).has(el.dataset.node) : true;
      el.classList.toggle('is-dim', !!state.flow && !on);
      el.classList.toggle('is-related', !!state.flow && on);
    });
    root.querySelectorAll('.nf2-cockpit').forEach(el => {
      const on = state.flow ? relatedNodes(state.flow).has('cockpit') : true;
      el.classList.toggle('is-dim', !!state.flow && !on);
    });
    root.querySelectorAll('.nf2-filter').forEach(el =>
      el.classList.toggle('is-on', state.type === el.dataset.type));
  }

  function setFlow(flow) {
    stopTour();
    state.flow = state.flow === flow ? null : flow;
    apply();
  }
  function setType(type) {
    stopTour();
    state.type = state.type === type ? null : type;
    state.flow = null;
    const svg = document.getElementById('nf2-svg');
    const stage = document.getElementById('nf2-stage');
    if (svg && stage) draw(svg, stage);
    apply();
  }
  function stopTour() {
    state.touring = false;
    if (state.tourTimer) { clearInterval(state.tourTimer); state.tourTimer = null; }
    const btn = document.getElementById('nf2-tour');
    if (btn) btn.textContent = '▶ 脉冲巡览';
  }
  function startTour() {
    if (state.touring) { stopTour(); return; }
    state.touring = true;
    state.type = null;
    state.tourIdx = 0;
    const order = Object.keys(D.FLOWS);
    const btn = document.getElementById('nf2-tour');
    btn.textContent = '⏸ 停止巡览';
    const step = () => {
      state.flow = order[state.tourIdx % order.length];
      state.tourIdx++;
      const svg = document.getElementById('nf2-svg');
      const stage = document.getElementById('nf2-stage');
      if (svg && stage) draw(svg, stage);
      apply();
    };
    step();
    state.tourTimer = setInterval(step, 1400);
  }

  /* ---------- 窄屏卡片 chips（无 SVG 时仍可点编号） ---------- */
  function fillChips() {
    D.CARDS.forEach(c => {
      const box = document.querySelector(`[data-chips="${c.node}"]`);
      if (!box || box.dataset.done) return;
      const ins = D.LINKS.filter(l => l.to === c.node).map(l => l.flow);
      const outs = D.LINKS.filter(l => l.from === c.node).map(l => l.flow);
      const chip = f => `<button class="nf2-chip" data-flow="${f}" style="--cc:${D.COLOR_OF[f]}">${f}</button>`;
      box.innerHTML = (ins.length ? `<span class="nf2-chip__lab">入 ${[...new Set(ins)].map(chip).join('')}</span>` : '')
        + (outs.length ? `<span class="nf2-chip__lab">出 ${[...new Set(outs)].map(chip).join('')}</span>` : '');
      box.dataset.done = '1';
    });
  }

  /* ---------- 挂载 ---------- */
  function mount() {
    const root = document.getElementById('netflow-board');
    if (!root) return;
    const stage = document.getElementById('nf2-stage');
    const svg = document.getElementById('nf2-svg');

    /* 每次挂载自检：视图从 display:none 恢复后，若连线层为空则补绘（net.js ▇▇s 长检会持续调用） */
    if (root.dataset.nf2ready) {
      if (stage && svg && stage.offsetWidth && stage.offsetHeight &&
          !window.matchMedia('(max-width: 960px)').matches && !svg.innerHTML.trim()) {
        draw(svg, stage);
      }
      return;
    }
    root.dataset.nf2ready = '1';

    fillChips();
    const redraw = () => {
      if (window.matchMedia('(max-width: 960px)').matches) {
        stage.classList.add('is-stack');
        svg.style.display = 'none';
      } else {
        stage.classList.remove('is-stack');
        svg.style.display = '';
        if (stage.offsetWidth && stage.offsetHeight) draw(svg, stage);
      }
    };
    redraw();
    if (window.ResizeObserver) new ResizeObserver(redraw).observe(stage);
    window.addEventListener('resize', redraw);

    root.addEventListener('click', e => {
      const flowEl = e.target.closest('[data-flow]');
      if (flowEl && flowEl.dataset.flow) { setFlow(flowEl.dataset.flow); return; }
      const typeEl = e.target.closest('[data-type]');
      if (typeEl) { if (typeEl.dataset.type !== '__all') setType(typeEl.dataset.type); return; }
      if (e.target.closest('#nf2-tour')) { startTour(); return; }
      if (e.target.closest('#nf2-reset')) {
        stopTour(); state.flow = null; state.type = null;
        draw(svg, stage); apply();
      }
    });
    // __all 与 null 等价
    const origSetType = setType;
    root.__setType = t => origSetType(t === '__all' ? null : t);
  }

  // 拦截 __all：在事件层转义
  document.addEventListener('click', e => {
    const b = e.target.closest('.nf2-filter[data-type="__all"]');
    if (b && document.getElementById('netflow-board')) {
      stopTour();
      state.type = null; state.flow = null;
      const svg = document.getElementById('nf2-svg');
      const stage = document.getElementById('nf2-stage');
      if (svg && stage) { draw(svg, stage); apply(); }
    }
  }, true);

  window.NF2_ENGINE = { boardHTML, mount, redraw: () => {
    const stage = document.getElementById('nf2-stage');
    const svg = document.getElementById('nf2-svg');
    if (stage && svg) { draw(svg, stage); apply(); }
  } };
})();
