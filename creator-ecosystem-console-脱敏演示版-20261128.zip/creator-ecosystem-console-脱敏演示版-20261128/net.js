/* ═══════════════════════════════════════════════════════════
   net.js —— 模块协作关系（系统底盘与自生长）
   2026-09-14 11:23 她的原话：
     「你这里给到的内容跟建议我看不懂，你的目的是看看我整个系统上
       相互之间的协作关系，为我呈现的内容要看到：现在哪些模块之间是
       可以直接链接的，如何实现，哪些结论是可以互通的，
       以及你可以学习一下还有什么能力是可以让整个系统更加完善的」

   她这句话把这一页的题目重新定了。旧版讲的是"仓库有几层、几个目录、
   填充度多少"——那是我自己的体检报告，对她零信息量，所以她说看不懂。
   新版只回答她点的四个问题，一问一块：
     ① 已经连通的链路（.netnow）  哪些模块现在真的是连着的，凭什么说它通了
     ② 能连但还没连（.netcan）    怎么连、缺什么、连上之后她少做什么动作
     ③ 结论互通清单（.netsame）   一个结论在哪产生、还能喂给谁、现在有没有真喂过去
     ④ 还缺什么能力（.netgap）    补了之后哪条链会通，谁来补，现在卡在谁

   ⛔ 三条硬规矩：
     ▇▇. 每条"通了"必须给凭证 —— 说得出具体哪个数、哪条规则是这么流过来的，
        说不出的一律算"没连"，不许拿设计意图当现状。
     ▇▇. "没互通"要写清差什么，不许只写"待打通"。
     ▇▇. 不写业绩金额（这一页归系统底盘，金额只在业务基本盘）。
   ═══════════════════════════════════════════════════════════ */
window.NET = (function () {

  /* ── ① 已经连通的链路 ──────────────────────────────────
     a → b：从哪流到哪；pass：传的是什么；lv：现在能用到什么程度
     pf：凭证（必须是她能自己去核的具体一件事） */
  const NOW = [
    { a: '你的裁决', b: '判断规则 → 我下次的默认动作', pass: '一句话结论',
      lv: '全通，且当场生效',
      pf: '你 09-13 那三句纠正（无刊例不等于效果结算池 / 分层是结果标签不是能力标签 / 短直不是分层杠杆），当天就变成三条规则，现在我不再按机构档位派打法了。' },
    { a: '页面反馈框', b: '我的收件箱 → 下一版页面', pass: '你圈的、你写的那一句',
      lv: '全通，不用导出补丁',
      pf: '你今天上午那 ▇▇条反馈，就是这一版全部改动的唯一来源 —— 驾驶舱重做、七条动作加反馈入口、这一页整块换题，全是从那 ▇▇条来的。' },
    { a: '记忆库', b: '每一个新会话的我', pass: '你是谁 / 项目到哪 / 红线',
      lv: '全通（本地为准，云端镜像兜底）',
      pf: '这次开工我先读的就是常驻记忆那一屏，全程没让你重讲一遍你是谁、项目卡在谁。' },
    { a: '周报口径', b: '本周策略回顾 → 经营总判断 → 策略动作', pass: '分层达成与专项进度',
      lv: '全通，但源已经 ▇▇ 天没更新',
      pf: '腰部 ▇▇ 这个数从周报进来，一路推到"本周发单优先压腰部"那条动作 —— 你能从动作反查回它是哪张看板的哪个数。' },
    { a: '商机作战台', b: '业务基本盘 → 驾驶舱各板块要点', pass: '今天真能提报的条数',
      lv: '通，但是手动搬的快照',
      pf: '作战台改成"可提报优先"之后，业务基本盘和驾驶舱那两条"今天动"同步换成了 ▇▇条可提报 + ▇▇条只缺表。' },
    { a: '达人刊例表', b: '商机人选推荐 → 提案报价', pass: '谁有报价、谁没有',
      lv: '通，但只覆盖 ▇▇',
      pf: '▇▇位无刊例这个名单，直接决定了"客户当场问价我答不上"的范围 —— 这条链是通的，是源本身有洞。' }
  ];

  /* ── ② 能连但还没连 ────────────────────────────────────
     how：具体怎么连（要能立刻照做，不许写"打通"）
     need：缺什么；side：现在卡在谁；win：连上之后她少做什么动作 */
  const CAN = [
    { a: '拜访纪要', b: '机构档案 → 下次拜访前「拜访前的机构情报清单」', hot: 1,
      why: '这是整套系统唯一只有你能供料的一段，也是现在最疼的断点：40-拜访与会议 ▇▇篇、▇▇家打标机构档案 ▇▇篇。',
      how: '你拜访完扔三句话（见了谁 / 聊了什么 / 答应了什么）→ 我用拜访军师补成正式纪要 → 自动回写机构档案 → 下次见同一家我先给你「拜访前的机构情报清单」。',
      need: '三句话。不用整理、不用格式。', side: 'you',
      win: '下次见同一家机构，你不用回想上次说了什么 —— 我直接给"上次答应了什么、哪几件还没做"。', to: 'state' },
    { a: '本周策略回顾结论', b: '业绩与复盘存档 → 下周对照', hot: 1,
      why: '现在每周现算一次，算完只留在页面上，等于这套系统只有当下、没有账。',
      how: '你 09-16 已经定了：<b>每周二一篇复盘，先读业务盘那 ▇▇个底仓拿最新数据，写完提醒你查阅</b>，并在下一篇第①段回看"上周判断后来对不对"。现在只差你选一种触发我的方式。',
      need: '一句话授权。之后你不用点。', side: 'you',
      win: '你能随时回答"上周那个判断后来对不对"，而不是每周从零重算一遍。', to: 'memory' },
    { a: '星图后台', b: '达人档案 → 案例可迁移条件', hot: 1,
      why: '达人A那三层高变现原因里，第二层（粉丝粘性）和第三层（转化价值）现在一个字都没有 —— 不是我懒，是取不到。',
      how: '你打开一次星图后台登录态 → 我一次把商单明细 + 粉丝画像 + 内容表现拉全 → 三层从推断变证据 → 五条借鉴条件才能真的当筛选条件用。',
      need: '一次登录态。', side: 'you',
      win: '模式库里卡住的 ▇▇套（矩阵测投 / 短直联动等）同时解锁 —— 它们卡的都是同一个洞。', to: 'base' },
    { a: '商机数据管道', b: '作战台 → 驾驶舱', hot: 0,
      why: '作战台是静态站，站里是 09-12 的快照；那 ▇▇条可提报可能已经被别人提掉了。',
      how: '我把取数接上，每天重跑一次商机与人选，页面上标真实数据截止日。',
      need: '不需要你做什么，这条是我的活。', side: 'me',
      win: '你进作战台看到的条数就是当天的，不用再问我"这个数是几号的"。', to: 'mech' },
    { a: '待复核队列', b: '口径词典 / 判断规则', hot: 0,
      why: '现在 ▇▇条推断挂在队列里，一条都没混进事实层（这是对的），但清队列要占你的时间。',
      how: '我按"卡不卡你产出"排序，一次只端 ▇▇条给你，其余我自己去找证据；找到证据的直接进词典，找不到的老实降级。',
      need: '不需要你做什么，我改成主动端菜。', side: 'me',
      win: '你从"清 ▇▇条"变成"每次答 ▇▇ 句对/不对"。', to: 'memory' },
    { a: '灵感库', b: '各业务目录', hot: 0,
      why: '入口通了、标签路由也写好了，但现在 ▇▇条 —— 缺的不是技术，是还没形成随手扔的习惯。',
      how: '页面最底下那个输入框，回车即到我这边；写标签我就不猜落点，不写我按内容判。',
      need: '第一条。最容易有货的两个场景：拜访路上、提案被否之后。', side: 'you',
      win: '你想到的东西不会烂在聊天记录里，我整理时会把它变成一条规则或一个机会。', to: 'spark' }
  ];

  /* ── ③ 结论互通清单 ────────────────────────────────────
     一个结论产生之后，它本该影响哪几处。已喂 = 真的改了那处；没喂 = 那处还按旧的算。 */
  const SAME = [
    { c: '客户要的是投产比和后链路，不是我们服务出问题',
      from: '前提审查（你 09-13 推翻我的减投归因）',
      to: [
        ['客户减投六问链', 1, '第二问已改成"它要的东西变了吗"'],
        ['提案结构', 1, '已改成双证明（内容力 + 转化证据）'],
        ['模式与玩法库的优先级', 0, '▇▇套还按老顺序排，素材授权型没被提到前面 —— 差我把这条结论写进模式库的排序规则'],
        ['「外部大盘」的机会研判', 0, '机会还是按"我有什么牌"排，没按"客户的钱在往哪挪"排 —— 差一次重排']
      ]},
    { c: '腰部是蓄水池，继续救',
      from: '你的裁决（我拿"本季跃迁 ▇▇家"质疑，被驳回）',
      to: [
        ['七条策略动作', 1, 'P1 第一条就是腰部 + 停滞机构本周必须出发单'],
        ['机构拜访优先级', 0, '拜访顺序还没按这条排 —— 差一张"该先见谁"的排序表，我可以出，但要先有机构档案']
      ]},
    { c: '没收到报价 ≠ 不能做效果结算',
      from: '你 09-13 当场纠的推理跳步',
      to: [
        ['达人池判断', 1, '▇▇位无刊例已经改成"未开通报价"，不再当能力缺失'],
        ['商机人选推荐逻辑', 0, '作战台还在用"有无刊例"当过滤条件 —— 差改一次筛选口径，这条我可以自己改']
      ]},
    { c: '达人A单均是全盘指派单均的 ▇▇倍，是定价能力不是偶然',
      from: '案例二拆解（你 ▇▇-13 22:▇▇ 要的底层原因）',
      to: [
        ['五条可查借鉴条件', 1, '已经写成能拿去筛人的条件'],
        ['Q4 个体高溢价达人名单', 0, '要不要立这条线还等你裁 —— 不立就还是偶发接单'],
        ['达人分层打标', 0, '打标表里没有"高溢价"这一类 —— 差一个标签维度']
      ]},
    { c: '9 月单月同比转负，累计 ▇▇ 会把它盖住',
      from: '业务基本盘（日报 09-11）',
      to: [
        ['业务基本盘风险提示', 1, '已经写在最上面，不藏在累计数后面'],
        ['Q4 目标测算', 0, '还没做 —— 这条结论真正的用处是定 Q4 起跑线，现在它只是个警告']
      ]}
  ];

  /* ── ④ 还缺什么能力 ────────────────────────────────────
     每条：缺口现象 / 补了之后哪条链通 / 谁来补 / 现在卡在谁
     ⛔ 做不到的必须当面说做不到，不许含糊（例如定时唤醒）。 */
  const GAP = [
    { n: '仓库里的规则和口径自动喂到页面上', side: 'me', st: 'can',
      see: '现在页面上的规则数、口径数、案例结论，是我一条条手写进代码的。',
      bad: '仓库改了页面不会动，两边会慢慢漂 —— 你在页面上看到的"▇▇条规则"总有一天会是旧的。',
      fix: '我把仓库的规则与口径导成一份数据文件放云端镜像，页面开屏读它。这样仓库一改，页面下次刷新就变。',
      win: '记忆库 → 页面这条链从"我手抄"变成"自动流"。' },
    { n: '每周结论自动存档', side: 'you', st: 'ask',
      see: '本周策略回顾算完只留在页面上，业绩与复盘目录只有 ▇▇篇。',
      bad: '下周从零重算，且没法回答"上周那个判断后来对不对"。',
      fix: '已定（09-16）：每周二一篇复盘，先读底仓再写、写完提醒你。剩下只差你选触发方式。',
      win: '结论出不去这个堵点直接消掉。' },
    { n: '能自己查明细的取数能力', side: 'me', st: 'test',
      see: '很多问题我只能读看板已经算好的数，比如"达人A那 ▇▇单集中在几个客户"。',
      bad: '案例二只能当单点讲，讲不成可复制的模式。',
      fix: '⚠️ 先验证再装：我先用现有的直连明细能力试一次（上次那 ▇▇家停滞机构重算成 ▇▇家就是这么跑的），<b>跑通就不用装新东西</b>；跑不通我再带着失败记录来找你要新能力。',
      win: '案例二第三层从零字段变成有证据；「我能装的技能」里那个数据分析技能也就不用装了。' },
    { n: '内容真实表现数据', side: 'you', st: 'ask',
      see: '看不到播放、完播、互动、转化 —— ▇▇套模式里有 ▇▇套卡在这。',
      bad: '矩阵测投、短直联动这类要看效果的玩法，我只能讲思路，给不了判断。',
      fix: '你开一次星图后台登录态，我一次拉全。',
      win: '达人档案、案例可迁移条件、模式库解锁，三处同时受益。' },
    { n: '定时唤醒（这条我做不到）', side: 'none', st: 'no',
      see: '每天 10:00 整理这件事，技能装好了，但一直没形成每天的产出。',
      bad: '"每日新变化"那一栏就会慢慢变成旧闻，你就不看了。',
      fix: '<b>实话</b>：我不是常驻进程，没人叫我不会自己醒，真定时我做不到。<br>能做到的极限是：你每天说一句"整理一下"，我 ▇▇ 分钟内给你 ▇▇行摘要 + 更新驾驶舱那一栏。',
      win: '不吹这个功能，比假装有它更有用 —— 你至少知道该指望什么。' }
  ];

  /* ═══════════════════════════════════════════════════════════
     ⑤ 模块协作全景动态看板（2026-11-13 纳入，源头：闭环总览图 v2.1 双层卡片版）
     ─────────────────────────────────────────────────────────────
     后续新链路怎么更新（她 11-13 原话：后续工作台如有新链路变化及时检索更新）：
       ▇▇. 新链路先在 FLOW_LINKS 里加一条 {flow:'C14', from, to, curve}，
          并在 FLOW_DEFS 补编号定义、FLOW_TYPES 归类；
       ▇▇. 未被她确认的新链路一律先挂 FLOW_PENDING（待验证候选），不许直接编号入图；
       ▇▇. 静态站没有运行时抓取，更新 = 改本文件常量 + 重新部署，SYNC.meta 改同步日期。
     ═══════════════════════════════════════════════════════════ */
  const SYNC = {
    ver: 'v2.1', date: '2026-11-13',
    source: '闭环总览图 v2.1 双层卡片版（飞书 PRD/画板）',
    rule: '静态站无运行时抓取：新链路由 Aime 在每次刷新/你发话时检索 PRD、学习日志与 Obsidian 规则库，确认后更新本看板并重新部署；未确认的只进「待验证候选」，不混入正式编号。'
  };

  /* 节点：▇▇ 驾驶舱置顶，01-06 按 Ⅱ / Ⅲ / Ⅳ 三列两行；short 供窄屏收窄显示 */
  const FLOW_NODES = [
    { id: 'n07', no: '▇▇', zone: 'O', title: '驾驶舱全景', short: '驾驶舱',
      v21: ['全系统运行状态 · 信息调度 · 结果梳理 · 反馈总览', '只收系统元信息，零业务数字'] },
    { id: 'n01', no: '▇▇', zone: 'II', title: '外部学习接入', short: '外部学习',
      v21: ['市场分析与行业研究 · 平台新能力 · 外部玩法', '思维模型原料 · 人工投喂通道', '事实/观点分离标注，逐条带来源与时效'] },
    { id: 'n02', no: '▇▇', zone: 'II', title: '认知加工与判断进化', short: '认知加工',
      v21: ['理解框架 · 信息处理方式 · 判断规则升级', '证据标准 · 口径词典 · 失效前提重算'] },
    { id: 'n03', no: '▇▇', zone: 'III', title: '体系化资源调度', short: '资源调度',
      v21: ['任务拆解 · 跨模块编排数据/档案/技能/模板', '按 v5 唯一正文位流通 · 调度台账留痕'] },
    { id: 'n04', no: '▇▇', zone: 'III', title: '技能自运行与放行门', short: '技能放行',
      v21: ['定时触发器 · 六大技能按节拍自发运行', '四类禁止自决走放行门 · 授权按需发起', '运行回执与失败原因全量回传'] },
    { id: 'n05', no: '▇▇', zone: 'IV', title: '自主研判与落地推进', short: '研判落地',
      v21: ['进展/缺口/风险自主研判 · 写作矩阵执行', '验收点：真样张先看、口径锁复核'] },
    { id: 'n06', no: '▇▇', zone: 'IV', title: '进阶反推与优化建议', short: '反推优化',
      v21: ['机会空间与漏损反推 · 建议带真去处', '证据闸门：缺市场佐证降级待验证线索', '▇▇ 类写作产物唯一出口（人工验收后回写）'] }
  ];

  /* ▇▇条协同流的编号定义（逐字对齐 v2.1 流程图 FLOWS） */
  const FLOW_DEFS = {
    C01: '外部学习赋能：市场研究/平台能力/思维模型 → Ⅳ-A 情报与 Ⅳ-F 打法，辅助决策建议',
    C02: '判断能力赋能：升级后的规则/口径/证据标准 → Ⅳ 全部研判与写作的口径锁',
    C03: '业务灵感反哺：日常业务信息（客户信号/拜访/盘面/商单）→ ▇▇ 的学习原料与灵感源',
    C04: '纠错回流：验收错误/待验证线索/前提坍塌 → Ⅱ-D，驱动规则重算与判断进化',
    C05: '能力注册：新规则/新框架/新技能 → Ⅲ-A 可触发任务清单，纳入自运行编排',
    C06: '认知资源调取：▇▇ 按任务反向调用规则库、口径库、偏好库（Ⅱ-A/Ⅱ-B）',
    C07: '任务资源派发：▇▇ 拆解派工，数据/档案/样板/模板/技能送达 Ⅳ 六个业务模块',
    C08: '技能产出直供：▇▇ 六大技能定时产出（供料/取数/诊断/分析）→ Ⅳ 对应模块',
    C09: '业务请求上行：Ⅳ 发起任务/登录授权/放行请求 → ▇▇ 放行门与 Ⅲ-B 裁决台账',
    C10: '验收回执回流：交付验收结论与承诺跟踪 → Ⅲ-B/Ⅲ-C 运行台账',
    C11: '三线状态上报：Ⅱ/Ⅲ/Ⅳ 只上报系统元信息 → ▇▇ 四类总览（零业务数字）',
    C12: '缺口回喂：▇▇/Ⅲ-D 体检发现能力缺口 → ▇▇ 学习队列优先补位',
    C13: '采纳派单：驾驶舱建议采纳 → ▇▇ 放行 → ▇▇ 派发'
  };

  /* 六类分色（明/暗两套，颜色对齐 v2.1 画板原色，亮色模式做加深保证可读） */
  const FLOW_TYPES = [
    { id: 'empower',  name: '认知赋能',     dark: '#A78BFA', light: '#7C5CD6', flows: ['C01', 'C02', 'C05'] },
    { id: 'feedback', name: '业务反哺',     dark: '#4ADE80', light: '#2E9E52', flows: ['C03', 'C04'] },
    { id: 'dispatch', name: '调度派发',     dark: '#60A5FA', light: '#2F72D6', flows: ['C06', 'C07', 'C08'] },
    { id: 'request',  name: '请求回执',     dark: '#34D399', light: '#0F8F73', flows: ['C09', 'C10'] },
    { id: 'cockpit',  name: '驾驶舱上下行', dark: '#94A3B8', light: '#64748B', flows: ['C11', 'C13'] },
    { id: 'gapfeed',  name: '缺口回喂',     dark: '#FBBF24', light: '#B7791F', flows: ['C12'] }
  ];
  const TYPE_OF = Object.keys(FLOW_DEFS).reduce((m, c) => {
    const t = FLOW_TYPES.find(t => t.flows.includes(c));
    m[c] = t ? t.id : 'dispatch';
    return m;
  }, {});

  /* 边：C11 一条逻辑流拆三条实际上报边；curve 区分同端点并行边 */
  const FLOW_LINKS = [
    { flow: 'C01', from: 'n01', to: 'n06', curve: 0.14 },
    { flow: 'C02', from: 'n02', to: 'n05', curve: 0.14 },
    { flow: 'C03', from: 'n05', to: 'n02', curve: 0.16 },
    { flow: 'C04', from: 'n05', to: 'n02', curve: 0.34 },
    { flow: 'C05', from: 'n02', to: 'n03', curve: 0.12 },
    { flow: 'C06', from: 'n03', to: 'n02', curve: 0.30 },
    { flow: 'C07', from: 'n03', to: 'n05', curve: 0.12 },
    { flow: 'C08', from: 'n04', to: 'n05', curve: 0.16 },
    { flow: 'C09', from: 'n05', to: 'n04', curve: 0.14 },
    { flow: 'C10', from: 'n05', to: 'n04', curve: 0.32 },
    { flow: 'C11', from: 'n02', to: 'n07', curve: 0.10, via: 'Ⅱ 认知与学习上报' },
    { flow: 'C11', from: 'n03', to: 'n07', curve: 0.06, via: 'Ⅲ 高阶交互上报' },
    { flow: 'C11', from: 'n05', to: 'n07', curve: 0.12, via: 'Ⅳ 业务工作区上报' },
    { flow: 'C12', from: 'n07', to: 'n01', curve: 0.12 },
    { flow: 'C13', from: 'n07', to: 'n03', curve: 0.08 }
  ];

  /* 待验证候选：未确认的新链路先挂这里，确认后才编号入图（首批为空，保留机制） */
  const FLOW_PENDING = [];

  const SIDE = { you: '等你一句话', me: '我的活', none: '做不到' };
  const GST = {
    can:  ['我可以直接做', 'is-can'],
    ask:  ['等你一句话', 'is-ask'],
    test: ['先验证再决定', 'is-test'],
    no:   ['我做不到，说清楚', 'is-no']
  };

  /* ── 渲染 ───────────────────────────────────────────── */
  function nowBox() {
    return `<div class="netnow" data-mod="m-netnow" id="netnow">
      <div class="net__hd">
        <span class="net__tag">已经连通的链路</span>
        <em>${NOW.length} 条。<b>每条都给了凭证</b> —— 说不出具体哪个数是这么流过来的，我就当它没连。</em>
      </div>
      <div class="netnow__l">${NOW.map(x => `<div class="netnow__i">
        <div class="netnow__ch">
          <b>${x.a}</b><i>→</i><b>${x.b}</b>
        </div>
        <div class="netnow__m">
          <span class="netnow__p">传的是${x.pass}</span>
          <span class="netnow__lv">${x.lv}</span>
        </div>
        <p class="netnow__pf"><span>凭什么说它通了</span>${x.pf}</p>
      </div>`).join('')}</div>
    </div>`;
  }

  function canBox() {
    const you = CAN.filter(x => x.side === 'you').length;
    return `<div class="netcan" data-mod="m-netcan" id="netcan">
      <div class="net__hd">
        <span class="net__tag">能连但还没连</span>
        <em>${CAN.length} 条，其中 <b>${you} 条只差你一句话或一个动作</b>，剩下的是我的活。每条都写清连上之后你少做什么。</em>
      </div>
      <div class="netcan__l">${CAN.map(x => `<div class="netcan__i${x.hot ? ' is-hot' : ''}" data-side="${x.side}">
        <div class="netcan__ch">
          <b>${x.a}</b><i>⇢</i><b>${x.b}</b>
          <span class="netcan__side" data-s="${x.side}">${x.side === 'you' ? '差你一步' : '我的活'}</span>
        </div>
        <p><span>为什么值得连</span>${x.why}</p>
        <p><span>怎么连</span>${x.how}</p>
        <p><span>缺什么</span>${x.need}</p>
        <p class="netcan__win"><span>连上之后你少做什么</span>${x.win}</p>
        <button class="netcan__go" data-jumpv="${x.to}">去这一页 →</button>
      </div>`).join('')}</div>
    </div>`;
  }

  function sameBox() {
    const all = SAME.reduce((a, c) => a + c.to.length, 0);
    const done = SAME.reduce((a, c) => a + c.to.filter(t => t[1]).length, 0);
    return `<div class="netsame" data-mod="m-netsame" id="netsame">
      <div class="net__hd">
        <span class="net__tag">结论互通清单</span>
        <em>一个结论定下来之后，它本该影响 ${all} 处，<b>现在真的改到位的是 ${done} 处</b>。没改的都写清差什么。</em>
      </div>
      <div class="netsame__l">${SAME.map(c => {
        const miss = c.to.filter(t => !t[1]).length;
        return `<div class="netsame__i">
          <div class="netsame__c">${c.c}</div>
          <div class="netsame__f">这条结论从哪来：${c.from}${miss ? `　·　<b>还有 ${miss} 处没跟上</b>` : '　·　已全部跟上'}</div>
          <div class="netsame__t">${c.to.map(t => `<div class="netsame__x${t[1] ? ' is-on' : ' is-off'}">
            <span class="netsame__st">${t[1] ? '已互通' : '没互通'}</span>
            <b>${t[0]}</b>
            <em>${t[2]}</em>
          </div>`).join('')}</div>
        </div>`;
      }).join('')}</div>
    </div>`;
  }

  function gapBox() {
    return `<div class="netgap" data-mod="m-netgap" id="netgap">
      <div class="net__hd">
        <span class="net__tag">能力缺口</span>
        <em>${GAP.length} 项。<b>包括一项我明确做不到的</b> —— 写清做不到比假装有它有用。</em>
      </div>
      <div class="netgap__l">${GAP.map(g => {
        const s = GST[g.st] || GST.can;
        return `<div class="netgap__i ${s[1]}">
          <div class="netgap__h">
            <b>${g.n}</b>
            <span class="netgap__st">${s[0]}</span>
            <span class="netgap__side">${SIDE[g.side]}</span>
          </div>
          <p><span>现在的现象</span>${g.see}</p>
          <p><span>不补的后果</span>${g.bad}</p>
          <p><span>怎么补</span>${g.fix}</p>
          <p class="netgap__win"><span>补了之后哪条链通</span>${g.win}</p>
        </div>`;
      }).join('')}</div>
      <p class="net__ft">这四问是你 11:23 点的题：哪些连着了 · 怎么连没连的 · 哪些结论能互通 · 还缺什么能力。
      上面每一条都能被你一句话推翻 —— 说"这条其实通了"或"这条不用连"，我当场改。</p>
    </div>`;
  }

  /* ══════════ ⑤ 全景动态看板 v2.1：全量保真版由 nf2.data.js + nf2.js 提供 ══════════ */
  function flowBoard() {
    /* 2026-11-13 她要求完全保留 v2.1 画板文字与呈现样式：
       旧 ECharts 简化关系图退役，改由 NF2_ENGINE 输出 HTML+SVG 动态全景，
       旧 F 引擎代码保留在本文件但不再挂载（#netflow 容器已不存在，init 自然短路）。 */
    return window.NF2_ENGINE ? window.NF2_ENGINE.boardHTML() : '';
  }

  /* ══════════ ⑤ 全景动态看板：ECharts 引擎（自管理，不依赖 charts.js 注册表） ══════════ */
  const F = { inst: null, timer: null, activeFlow: null, activeType: null, playing: false, idx: 0, bound: false };
  const ZONE_NAME = { O: 'Ⅰ 驾驶舱全景', II: 'Ⅱ 认知与学习', III: 'Ⅲ 高阶交互系统', IV: 'Ⅳ 业务工作区' };
  const ZONE_COLOR = {
    O:   { dark: ['#FBBF24', 'rgba(251,191,36,.16)'],  light: ['#B7791F', 'rgba(183,121,31,.12)'] },
    II:  { dark: ['#A78BFA', 'rgba(167,139,250,.16)'], light: ['#7C5CD6', 'rgba(124,92,214,.10)'] },
    III: { dark: ['#60A5FA', 'rgba(96,165,250,.16)'],  light: ['#2F72D6', 'rgba(47,114,214,.10)'] },
    IV:  { dark: ['#4ADE80', 'rgba(74,222,128,.16)'],  light: ['#2E9E52', 'rgba(46,158,82,.10)'] }
  };
  /* 逻辑布局：宽 ▇▇ / 高 ▇▇，▇▇ 置顶，01-06 三列两行 */
  const POS = {
    n07: [480, 52],
    n01: [132, 212], n03: [480, 212], n05: [828, 212],
    n02: [132, 404], n04: [480, 404], n06: [828, 404]
  };
  const isDark = () => !document.body.classList.contains('candy-light');
  const typeColor = c => {
    const t = FLOW_TYPES.find(t => t.flows.includes(c)) || FLOW_TYPES[2];
    return isDark() ? t.dark : t.light;
  };

  function buildOption() {
    const dark = isDark();
    const el = document.getElementById('netflow');
    const w = (el && el.clientWidth) || 960;
    const scale = Math.max(0.5, Math.min(1.08, w / 960));
    const ink = getComputedStyle(document.body).getPropertyValue('--ink-2').trim() || (dark ? '#B4AEA2' : '#57534C');
    const rule = getComputedStyle(document.body).getPropertyValue('--rule-2').trim() || (dark ? '#413E37' : '#C6C0B3');
    const motionOff = document.body.classList.contains('motion-off');
    const nodeW = 164 * scale, nodeH = 60 * scale;
    const fontSize = scale < 0.62 ? 9.5 : (scale < 0.78 ? 10.5 : 12);

    const nodes = FLOW_NODES.map(n => {
      const zc = ZONE_COLOR[n.zone][dark ? 'dark' : 'light'];
      const labelName = scale < 0.62 ? `${n.no}\n${n.short}` : `${n.no}\n${n.title}`;
      return {
        id: n.id, name: labelName, _raw: n,
        x: POS[n.id][0] * scale, y: POS[n.id][1] * scale,
        symbol: 'roundRect', symbolSize: [nodeW, nodeH],
        itemStyle: { color: zc[1], borderColor: zc[0], borderWidth: 2, radius: 14 },
        label: {
          show: true, color: ink, fontSize, fontWeight: 700, lineHeight: fontSize + 5,
          fontFamily: 'inherit', width: nodeW - 12, overflow: 'truncate', ellipsis: '…'
        }
      };
    });

    const links = FLOW_LINKS.map(l => {
      const hot = F.activeFlow === l.flow;
      const typeDim = F.activeType && TYPE_OF[l.flow] !== F.activeType;
      const flowDim = F.activeFlow && !hot;
      const dim = typeDim || flowDim;
      const col = typeColor(l.flow);
      return {
        source: l.from, target: l.to, _raw: l,
        curveness: l.curve,
        symbol: ['none', 'arrow'], symbolSize: hot ? 11 : 8,
        lineStyle: {
          color: col, width: hot ? 3.6 : 1.8,
          opacity: dim ? 0.07 : (hot ? 1 : 0.72),
          curveness: l.curve, type: hot ? 'solid' : 'solid'
        },
        label: {
          show: hot, formatter: l.flow, position: 'middle',
          color: '#fff', fontSize: 11, fontWeight: 800,
          backgroundColor: col, borderRadius: 6, padding: [3, 7]
        },
        emphasis: { label: { show: true, formatter: l.flow, position: 'middle', color: '#fff', fontSize: 11, fontWeight: 800, backgroundColor: col, borderRadius: 6, padding: [3, 7] } }
      };
    });

    return {
      animationDuration: motionOff ? 0 : 720,
      animationEasing: 'cubicOut',
      tooltip: {
        backgroundColor: 'rgba(18,18,24,.94)', borderWidth: 0, padding: [10, 14],
        textStyle: { color: '#fff', fontSize: 12 },
        extraCssText: 'border-radius:14px;box-shadow:0 18px 44px rgba(0,0,0,.5);max-width:340px;',
        formatter: p => {
          if (p.dataType === 'node') {
            const n = p.data._raw;
            return `<b style="font-size:13px">${n.no} ${n.title}</b><br>` +
              `<span style="color:#9aa0aa;font-size:11px">${ZONE_NAME[n.zone]}</span><br>` +
              n.v21.map(s => `<span style="color:#d7d9de">· ${s}</span>`).join('<br>');
          }
          const l = p.data._raw;
          return `<b style="color:${typeColor(l.flow)}">${l.flow}</b>　${FLOW_DEFS[l.flow]}` +
            (l.via ? `<br><span style="color:#9aa0aa;font-size:11px">${l.via}</span>` : '');
        }
      },
      series: [{
        type: 'graph', layout: 'none', roam: true, draggable: false,
        edgeSymbol: ['none', 'arrow'],
        emphasis: { focus: 'adjacency', lineStyle: { width: 3.6, opacity: 1 } },
        data: nodes, links,
        lineStyle: { color: rule },
        z: 2
      }]
    };
  }

  function paint() {
    if (!F.inst || F.inst.isDisposed()) return;
    F.inst.setOption(buildOption(), true);
  }

  function stopPlay() {
    F.playing = false;
    if (F.timer) { clearInterval(F.timer); F.timer = null; }
    const btn = document.querySelector('.nfb__play');
    if (btn) { btn.classList.remove('is-on'); btn.querySelector('.nfb__plyic').textContent = '▶'; btn.querySelector('b').textContent = '脉冲巡览'; }
  }
  function startPlay() {
    stopPlay();
    F.playing = true;
    const btn = document.querySelector('.nfb__play');
    if (btn) { btn.classList.add('is-on'); btn.querySelector('.nfb__plyic').textContent = '❚❚'; btn.querySelector('b').textContent = '暂停巡览'; }
    const order = Object.keys(FLOW_DEFS);
    F.activeType = null;
    F.timer = setInterval(() => {
      F.activeFlow = order[F.idx % order.length];
      F.idx++;
      syncChips(); paint();
    }, 1800);
  }
  function syncChips() {
    document.querySelectorAll('.nfb__chip').forEach(c =>
      c.classList.toggle('is-on', c.dataset.flow === F.activeFlow));
    document.querySelectorAll('.nfb__type').forEach(c =>
      c.classList.toggle('is-on', c.dataset.type === F.activeType));
  }
  function resetAll() {
    stopPlay();
    F.activeFlow = null; F.activeType = null; F.idx = 0;
    syncChips(); paint();
    if (F.inst && !F.inst.isDisposed()) F.inst.dispatchAction({ type: 'restore' });
  }

  function init() {
    const el = document.getElementById('netflow');
    if (!el || !window.echarts || !el.clientHeight) return;
    if (F.inst && !F.inst.isDisposed()) {
      if (F.inst.getDom() === el) { F.inst.resize(); return; }
      F.inst.dispose();
    }
    F.inst = echarts.init(el, null, { renderer: 'svg' });
    paint();
    if (!F.bound) {
      F.bound = true;
      /* 容器尺寸变化（shell 视图切换 / 窄屏 / 密度）→ 重算缩放与短名后 resize */
      let rzT = null;
      new ResizeObserver(() => {
        if (!F.inst || F.inst.isDisposed()) return;
        clearTimeout(rzT);
        rzT = setTimeout(() => { paint(); F.inst.resize(); }, 120);
      }).observe(el);
      /* 主题切换（明/暗、动效开关）→ 整体重画，颜色全部重新取 */
      new MutationObserver(() => paint()).observe(document.body, { attributes: true, attributeFilter: ['class'] });
      /* 事件委托：innerHTML 重建也不丢 */
      document.addEventListener('click', e => {
        const typeBtn = e.target.closest('.nfb__type');
        const chipBtn = e.target.closest('.nfb__chip');
        const actBtn = e.target.closest('[data-act]');
        if (typeBtn) {
          stopPlay();
          const t = typeBtn.dataset.type;
          F.activeType = F.activeType === t ? null : t;
          F.activeFlow = null;
          syncChips(); paint();
        } else if (chipBtn) {
          stopPlay();
          const c = chipBtn.dataset.flow;
          F.activeFlow = F.activeFlow === c ? null : c;
          F.activeType = null;
          syncChips(); paint();
        } else if (actBtn) {
          if (actBtn.dataset.act === 'play') { F.playing ? stopPlay() : startPlay(); }
          if (actBtn.dataset.act === 'reset') resetAll();
        }
      });
    }
  }

  /* 位置校正：grp 收编 + dash 的 kpiFirst 会把 sysrun 提到槽位首位，
     看板必须稳在「本页结论」之后第一块（她 11-13 要求进模块首屏可见）。
     dash 的 kpiFirst 有 dkpi 一次性保护，校正后不会再被挤走；本函数幂等。 */
  function ensurePosition() {
    const nfb = document.getElementById('netflow-board');
    if (!nfb) return;
    const box = nfb.closest('.cgrp__b');
    if (!box) return;                       // grp 尚未分组，下一轮定时器再试
    const mx = box.querySelector(':scope > .mxsum');
    /* ▇▇) 本页结论条置顶（全站惯例），把 dash 前置的 sysrun 让位 */
    if (mx && box.firstElementChild !== mx) box.insertBefore(mx, box.firstChild);
    /* ▇▇) 看板紧随结论条；无结论条则看板首位 */
    const anchor = mx ? mx.nextSibling : box.firstChild;
    const cur = mx ? mx.nextElementSibling : box.firstElementChild;
    if (cur !== nfb) box.insertBefore(nfb, anchor);
  }

  /* 快速首轮：sections 注入后 ▇▇ 秒内每 250ms 试挂，保证首屏尽快出图（NF2 全景引擎） */
  let fastTries = 0;
  const fastTimer = setInterval(() => {
    ensurePosition();
    const board = document.getElementById('netflow-board');
    if (board && window.NF2_ENGINE) {
      window.NF2_ENGINE.mount();
      if (board.dataset.nf2ready === '1') clearInterval(fastTimer);
    }
    if (++fastTries > 20) clearInterval(fastTimer);
  }, 250);

  /* 长期自检：DOM 被整体重建后自动重挂（视图切换只隐藏不重建，由 ResizeObserver 兜 resize） */
  setInterval(() => {
    if (!document.getElementById('netflow-board')) return;
    ensurePosition();
    if (window.NF2_ENGINE) window.NF2_ENGINE.mount();
  }, 1500);

  function render() { return flowBoard() + nowBox() + canBox() + sameBox() + gapBox(); }

  return { render, NOW, CAN, SAME, GAP, FLOW_DEFS, FLOW_LINKS, SYNC };
})();
